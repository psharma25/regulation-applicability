"""
agent.py — agentic, retrieval-grounded analysis of a medical-device corpus.

Two jobs:
  1) analyze(): a multi-step extraction agent that pulls a structured dossier
     from the device white paper — summary, cyber risks, cyber (security)
     features, and where the device is deployed.
  2) ask(): grounded Q&A over a retrieval index, returning an answer + the
     source chunks it used.

Both run on a local Ollama model when available, and fall back to a fully
deterministic (no-LLM) path so the tool works offline with zero setup.
"""
from __future__ import annotations
import os, re, json
from typing import List, Dict, Optional

import requests

from rag import Index, split_sentences, tokenize

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")
GEN_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.1:8b")

# aspect seed queries drive retrieval for each section of the dossier
ASPECTS = {
    "summary":    "overview purpose function of the medical device and how it works",
    "risks":      "security vulnerabilities risks threats weaknesses attack exposure of the device",
    "features":   "built-in security and privacy features controls protections safeguards encryption authentication",
    "deployment": "where the device is deployed used clinical environment",
    "data":       "what data the device processes stores transmits patient data PHI privacy",
    "interfaces": "other devices systems networks the device connects to interfaces integrates with",
}

# ---- lexicons for the deterministic extractor -----------------------------
RISK_TERMS = ["vulnerab", "exploit", "unauthorized", "unauthenticated", "hardcoded",
    "hard-coded", "default credential", "default password", "unencrypted", "cleartext",
    "plaintext", "buffer overflow", "injection", "cross-site", "csrf", "xss",
    "denial of service", "ransomware", "malware", "backdoor", "privilege escalation",
    "authentication bypass", "man-in-the-middle", "mitm", "tamper", "spoof",
    "replay attack", "weak encryption", "outdated", "unpatched", "legacy",
    "open port", "remote code", "eavesdrop", "insecure", "misconfigur", "exposure",
    "data breach", "phishing", "lateral movement", "firmware modification", "threat"]

FEATURE_TERMS = ["encryption", "encrypt", "aes", "tls", "ssl", "https", "authentication",
    "multi-factor", "mfa", "two-factor", "rbac", "role-based", "access control",
    "audit log", "logging", "secure boot", "signed firmware", "code signing",
    "certificate", "pki", "whitelisting", "allowlist", "segmentation", "vlan",
    "firewall", "vpn", "hardening", "least privilege", "session timeout",
    "data integrity", "hashing", "sha-256", "key management", "hsm", "tpm",
    "intrusion detection", "anomaly detection", "patch management", "sbom",
    "penetration test", "vulnerability scan", "zero trust", "endpoint protection",
    "authorization", "credential"]

DEPLOY_TERMS = ["hospital", "icu", "intensive care", "operating room", "emergency",
    "clinic", "ambulatory", "home", "homecare", "home use", "bedside",
    "point of care", "nursing", "pharmacy", "radiology", "laboratory", "network",
    "wireless", "wi-fi", "wifi", "bluetooth", "cellular", "ethernet", "cloud",
    "on-premise", "on premises", "data center", "ehr", "emr", "hl7", "dicom",
    "gateway", "server", "mobile app", "usb", "serial", "remote monitoring",
    "telehealth", "infusion", "patient"]

# what data the device processes/handles (privacy-relevant)
DATA_TERMS = ["phi", "protected health information", "pii", "personal data",
    "personally identifiable", "patient data", "demographics", "date of birth",
    "medical record", "mrn", "health record", "vital signs", "vitals", "ecg", "ekg",
    "glucose", "blood glucose", "dose", "dosing", "medication", "insulin",
    "cardiac", "heart rate", "imaging", "images", "ct", "telemetry", "location",
    "credentials", "password", "audit log", "logs", "identifiers", "biometric",
    "therapy data", "configuration", "drug library"]

# other devices / systems the device interfaces with
INTERFACE_TERMS = ["ehr", "emr", "cgm", "continuous glucose monitor", "dexcom",
    "smartphone", "mobile app", "controller", "server", "gateway", "cloud",
    "programmer", "central station", "pharmacy", "imaging", "ct", "hl7", "dicom",
    "bluetooth", "ble", "wi-fi", "wifi", "cellular", "ethernet", "usb",
    "merlin", "merlin.net", "monitor", "pump module", "robotic arm",
    "management server", "network", "portal", "informatics"]


# ---- ollama -----------------------------------------------------------------
def ollama_up() -> bool:
    try:
        requests.get(f"{OLLAMA_URL}/api/tags", timeout=2).raise_for_status()
        return True
    except Exception:
        return False


def _gen(prompt: str, fmt_json: bool = False) -> Optional[str]:
    try:
        body = {"model": GEN_MODEL, "prompt": prompt, "stream": False,
                "options": {"temperature": 0.1}}
        if fmt_json:
            body["format"] = "json"
        r = requests.post(f"{OLLAMA_URL}/api/generate", json=body, timeout=120)
        r.raise_for_status()
        return (r.json().get("response") or "").strip()
    except Exception:
        return None


def _parse_json(s: str) -> Optional[dict]:
    if not s:
        return None
    try:
        return json.loads(s)
    except Exception:
        m = re.search(r"\{.*\}", s, re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                return None
    return None


# ---- deterministic helpers --------------------------------------------------
def _match_sentences(sents: List[str], terms: List[str], cap: int = 12) -> List[Dict]:
    out, seen = [], set()
    for s in sents:
        low = s.lower()
        hit = sorted({t for t in terms if t in low})
        if hit:
            key = s[:80]
            if key in seen:
                continue
            seen.add(key)
            out.append({"text": s.strip(), "tags": hit[:6]})
        if len(out) >= cap:
            break
    return out


def _extractive_summary(text: str, n: int = 6) -> str:
    sents = split_sentences(text)
    if len(sents) <= n:
        return " ".join(sents)
    # score by term frequency weight + position
    df: Dict[str, int] = {}
    toks = [tokenize(s) for s in sents]
    for t in toks:
        for w in set(t):
            df[w] = df.get(w, 0) + 1
    scores = []
    for i, t in enumerate(toks):
        freq = sum(df.get(w, 0) for w in t) / (len(t) + 1)
        pos = 1.25 if i < 3 else 1.0
        scores.append((i, freq * pos))
    top = sorted(scores, key=lambda x: -x[1])[:n]
    keep = sorted(i for i, _ in top)
    return " ".join(sents[i] for i in keep)


# ---- public: analyze --------------------------------------------------------
def analyze(full_text: str, index: Index, use_ollama: bool = True) -> Dict:
    """Agentic dossier extraction. Returns structured fields + engine used."""
    sents = split_sentences(full_text)
    deterministic = {
        "summary": _extractive_summary(full_text),
        "cyber_risks": _match_sentences(sents, RISK_TERMS),
        "cyber_features": _match_sentences(sents, FEATURE_TERMS),
        "data_processed": _match_sentences(sents, DATA_TERMS),
        "deployment": _match_sentences(sents, DEPLOY_TERMS),
        "interfaces": _match_sentences(sents, INTERFACE_TERMS),
        "engine": "deterministic",
    }
    if not (use_ollama and ollama_up()):
        return deterministic

    # agentic loop: retrieve per aspect, then ask the model to extract JSON
    ctx = {a: "\n".join(c["text"] for c in index.retrieve(q, 6))
           for a, q in ASPECTS.items()}
    prompt = f"""You are a medical-device product-security analyst. Using ONLY the context
excerpts below, extract a structured cybersecurity & privacy dossier for the device.

Return STRICT JSON with exactly these keys:
- "summary": 3-5 sentence plain-language overview of the device and what it does.
- "cyber_risks": array of {{"text": short risk statement, "tags": [keywords]}}.
- "cyber_features": array of {{"text": a built-in security OR privacy feature/control, "tags": [keywords]}}.
- "data_processed": array of {{"text": a type of data the device processes/stores/transmits, "tags": [keywords]}}.
- "deployment": array of {{"text": where/how it is deployed (environment), "tags": [keywords]}}.
- "interfaces": array of {{"text": another device/system/network it interfaces with, "tags": [keywords]}}.
Do not invent facts not supported by the context. Keep each item to one sentence.

[SUMMARY CONTEXT]
{ctx['summary'][:3000]}
[RISK CONTEXT]
{ctx['risks'][:3000]}
[SECURITY & PRIVACY FEATURE CONTEXT]
{ctx['features'][:3000]}
[DATA CONTEXT]
{ctx['data'][:3000]}
[DEPLOYMENT / ENVIRONMENT CONTEXT]
{ctx['deployment'][:3000]}
[INTERFACES CONTEXT]
{ctx['interfaces'][:3000]}
"""
    raw = _gen(prompt, fmt_json=True)
    data = _parse_json(raw or "")
    if not data or "summary" not in data:
        return deterministic

    def norm(key):
        items = data.get(key) or []
        out = []
        for it in items:
            if isinstance(it, str):
                out.append({"text": it, "tags": []})
            elif isinstance(it, dict) and it.get("text"):
                out.append({"text": str(it["text"]), "tags": it.get("tags") or []})
        return out or deterministic[key]

    return {
        "summary": str(data.get("summary") or deterministic["summary"]),
        "cyber_risks": norm("cyber_risks"),
        "cyber_features": norm("cyber_features"),
        "data_processed": norm("data_processed"),
        "deployment": norm("deployment"),
        "interfaces": norm("interfaces"),
        "engine": f"ollama:{GEN_MODEL}",
    }


# ---- public: ask ------------------------------------------------------------
def ask(question: str, index: Index, use_ollama: bool = True) -> Dict:
    hits = index.retrieve(question, 6)
    if not hits:
        return {"answer": "No relevant content was found in this corpus. Try ingesting a "
                          "white paper or fetching CVEs first.", "sources": [], "engine": "none"}
    context = "\n\n".join(f"[{i+1}] {h['text']}" for i, h in enumerate(hits))
    if use_ollama and ollama_up():
        prompt = f"""Answer the question using ONLY the numbered context passages. Cite the
passages you use like [1], [2]. If the answer is not in the context, say so plainly.

Context:
{context[:6000]}

Question: {question}
Answer:"""
        ans = _gen(prompt)
        if ans:
            return {"answer": ans, "sources": hits, "engine": f"ollama:{GEN_MODEL}"}
    # deterministic: stitch the most relevant sentences from top chunks
    q_terms = set(tokenize(question))
    scored = []
    for h in hits:
        for s in split_sentences(h["text"]):
            overlap = len(q_terms & set(tokenize(s)))
            if overlap:
                scored.append((overlap, s))
    scored.sort(key=lambda x: -x[0])
    picked = [s for _, s in scored[:4]]
    answer = " ".join(picked)
    # if the stitched answer is too thin, return the most relevant passage(s) verbatim
    if len(answer) < 160 or len(picked) < 2:
        answer = "\n\n".join(h["text"] for h in hits[:2])
    return {"answer": answer, "sources": hits, "engine": "deterministic"}
