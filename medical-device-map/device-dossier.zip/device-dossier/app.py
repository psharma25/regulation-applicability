"""
app.py — MedDevice RAG / agentic analysis API.

Per device we keep two corpora (RAG indices):
  * paper  — the device white paper you ingest
  * cve    — published CVEs/advisories pulled from NVD / CISA (+ HHS note)

You can summarize, extract a structured cyber dossier (risks, security
features, deployment), and ask grounded questions against either corpus or
both. Everything re-runs on demand. Ollama is used when present; otherwise a
deterministic engine keeps the app fully functional offline.
"""
from __future__ import annotations
import os, io, json, uuid, time
from typing import List, Optional

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Body
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

import rag, agent, sources, bom

DATA = os.environ.get("MEDRAG_DATA", os.path.join(os.path.dirname(__file__), "data"))
STATIC = os.path.join(os.path.dirname(__file__), "static")
os.makedirs(DATA, exist_ok=True)
REG = os.path.join(DATA, "registry.json")

app = FastAPI(title="MedDevice RAG", version="1.0")


# --------------------------------------------------------------- storage
def _load_reg() -> dict:
    if os.path.exists(REG):
        try:
            return json.load(open(REG))
        except Exception:
            pass
    return {}


def _save_reg(reg: dict):
    json.dump(reg, open(REG, "w"), indent=2)


def _ddir(did: str) -> str:
    d = os.path.join(DATA, did)
    os.makedirs(d, exist_ok=True)
    return d


def _read(did: str, name: str):
    p = os.path.join(_ddir(did), name)
    return json.load(open(p)) if os.path.exists(p) else None


def _write(did: str, name: str, obj):
    json.dump(obj, open(os.path.join(_ddir(did), name), "w"))


def _device_or_404(did: str) -> dict:
    reg = _load_reg()
    if did not in reg:
        raise HTTPException(404, "Device not found")
    return reg[did]


def _keywords(dev: dict) -> str:
    return (dev.get("keywords") or " ".join(
        x for x in [dev.get("manufacturer"), dev.get("model"), dev.get("name")] if x)).strip()


def _index(did: str, corpus: str) -> Optional[rag.Index]:
    d = _read(did, f"index_{corpus}.json")
    return rag.Index.from_dict(d) if d else None


# --------------------------------------------------------------- status
@app.get("/api/status")
def status():
    up = agent.ollama_up()
    return {"ollama": up, "model": agent.GEN_MODEL, "embed_model": rag.EMBED_MODEL,
            "engine": f"ollama:{agent.GEN_MODEL}" if up else "deterministic"}


# --------------------------------------------------------------- devices
@app.get("/api/devices")
def list_devices():
    reg = _load_reg()
    out = []
    for did, d in reg.items():
        out.append({**d, "id": did,
                    "has_paper": os.path.exists(os.path.join(_ddir(did), "index_paper.json")),
                    "has_cves": os.path.exists(os.path.join(_ddir(did), "index_cve.json")),
                    "analyzed": os.path.exists(os.path.join(_ddir(did), "analysis.json"))})
    out.sort(key=lambda x: x.get("created", 0), reverse=True)
    return out


@app.post("/api/devices")
def create_device(payload: dict = Body(...)):
    name = (payload.get("name") or "").strip()
    if not name:
        raise HTTPException(400, "Device name is required")
    did = uuid.uuid4().hex[:10]
    reg = _load_reg()
    reg[did] = {"name": name, "manufacturer": (payload.get("manufacturer") or "").strip(),
                "model": (payload.get("model") or "").strip(),
                "keywords": (payload.get("keywords") or "").strip(),
                "created": int(time.time())}
    _save_reg(reg)
    return {**reg[did], "id": did}


@app.delete("/api/devices/{did}")
def delete_device(did: str):
    reg = _load_reg()
    reg.pop(did, None)
    _save_reg(reg)
    import shutil
    shutil.rmtree(_ddir(did), ignore_errors=True)
    return {"ok": True}


@app.get("/api/devices/{did}")
def get_device(did: str):
    dev = _device_or_404(did)
    return {**dev, "id": did,
            "analysis": _read(did, "analysis.json"),
            "cves": _read(did, "cves.json"),
            "bom": _read(did, "bom.json"),
            "exposure": _read(did, "exposure.json"),
            "paper_meta": _read(did, "paper_meta.json"),
            "has_paper": _index(did, "paper") is not None,
            "has_cves": _index(did, "cve") is not None}


# --------------------------------------------------------------- ingest paper
@app.post("/api/devices/{did}/paper")
async def ingest_paper(did: str, file: UploadFile = File(None), text: str = Form(None)):
    _device_or_404(did)
    content = ""
    fname = None
    if file is not None:
        raw = await file.read()
        fname = file.filename
        if (fname or "").lower().endswith(".pdf"):
            try:
                from pypdf import PdfReader
                reader = PdfReader(io.BytesIO(raw))
                content = "\n".join((p.extract_text() or "") for p in reader.pages)
            except Exception as e:
                raise HTTPException(400, f"Could not read PDF: {e}")
        else:
            content = raw.decode("utf-8", "ignore")
    elif text:
        content = text
    if not content.strip():
        raise HTTPException(400, "No readable text found in the upload.")

    chunks = rag.chunk_text(content)
    ix = rag.Index().build(chunks, use_ollama=agent.ollama_up())
    _write(did, "index_paper.json", ix.to_dict())
    # keep raw text for re-analysis without re-upload
    _write(did, "paper_text.json", {"text": content})
    meta = {"filename": fname, "chars": len(content), "chunks": len(chunks),
            "retrieval": ix.mode, "ingested": int(time.time())}
    _write(did, "paper_meta.json", meta)
    return {"ok": True, **meta}


# --------------------------------------------------------------- analyze (re-run on demand)
@app.post("/api/devices/{did}/analyze")
def analyze_device(did: str, payload: dict = Body(default={})):
    _device_or_404(did)
    txt = _read(did, "paper_text.json")
    ix = _index(did, "paper")
    if not txt or not ix:
        raise HTTPException(400, "Ingest a white paper first.")
    use_ollama = payload.get("engine", "auto") != "deterministic"
    result = agent.analyze(txt["text"], ix, use_ollama=use_ollama)
    result["generated"] = int(time.time())
    _write(did, "analysis.json", result)
    return result


# --------------------------------------------------------------- CVEs (second RAG)
@app.post("/api/devices/{did}/cves")
def fetch_cves(did: str, payload: dict = Body(default={})):
    dev = _device_or_404(did)
    kw = (payload.get("keyword") or _keywords(dev)).strip()
    if not kw:
        raise HTTPException(400, "No keyword to search. Add a manufacturer/model or keywords.")
    srcs = payload.get("sources") or ["nvd", "kev", "cisa", "fda"]
    limit = int(payload.get("limit", 20))
    res = sources.fetch_all(kw, srcs, limit)
    res["trust_center"] = sources.trust_center_for(kw + " " + dev.get("manufacturer", "")) or res.get("trust_center", {})
    res["keyword"] = kw
    res["fetched"] = int(time.time())
    _write(did, "cves.json", res)
    # build / refresh the CVE corpus index (CVEs + recalls)
    corpus = sources.cve_corpus_text(res["records"], res.get("recalls"))
    if corpus:
        ix = rag.Index().build(corpus, use_ollama=agent.ollama_up())
        _write(did, "index_cve.json", ix.to_dict())
    return res


# --------------------------------------------------------------- ask (paper | cve | both)
@app.post("/api/devices/{did}/ask")
def ask(did: str, payload: dict = Body(...)):
    _device_or_404(did)
    q = (payload.get("question") or "").strip()
    if not q:
        raise HTTPException(400, "Ask a question.")
    corpus = payload.get("corpus", "paper")
    use_ollama = payload.get("engine", "auto") != "deterministic"

    if corpus == "both":
        pa, cv = _index(did, "paper"), _index(did, "cve")
        chunks = (pa.chunks if pa else []) + (cv.chunks if cv else [])
        if not chunks:
            raise HTTPException(400, "Nothing to search yet.")
        ix = rag.Index().build(chunks, use_ollama=False)  # transient combined index
    else:
        ix = _index(did, corpus)
        if not ix:
            raise HTTPException(400, f"No '{corpus}' corpus yet. Ingest a paper or fetch CVEs first.")
    out = agent.ask(q, ix, use_ollama=use_ollama)
    out["corpus"] = corpus
    return out


# --------------------------------------------------------------- seed examples
EXAMPLES = [
    {"name": "Omnipod 5 Automated Insulin Delivery System", "manufacturer": "Insulet",
     "model": "Omnipod 5", "keywords": "Insulet Omnipod insulin pump", "file": "insulet_omnipod5.txt"},
    {"name": "BD Alaris Infusion System", "manufacturer": "BD (Becton Dickinson)",
     "model": "Alaris", "keywords": "BD Alaris infusion pump", "file": "bd_alaris.txt"},
    {"name": "Monarch Platform (Robotic Bronchoscopy)", "manufacturer": "Johnson & Johnson MedTech",
     "model": "Monarch", "keywords": "Monarch robotic bronchoscopy", "file": "jnj_monarch.txt"},
    {"name": "IntelliVue MX750 Patient Monitor", "manufacturer": "Philips",
     "model": "MX750", "keywords": "Philips IntelliVue patient monitor", "file": "philips_intellivue.txt"},
    {"name": "Gallant ICD (myMerlinPulse / Merlin.net)", "manufacturer": "Abbott",
     "model": "Gallant", "keywords": "Abbott implantable defibrillator Merlin", "file": "abbott_gallant.txt"},
    {"name": "Mako SmartRobotics System", "manufacturer": "Stryker",
     "model": "Mako", "keywords": "Stryker Mako robotic surgery", "file": "stryker_mako.txt"},
]
EXAMPLE_DIR = os.path.join(os.path.dirname(__file__), "sample", "examples")


@app.post("/api/seed")
def seed_examples():
    reg = _load_reg()
    existing = {d.get("name") for d in reg.values()}
    created = []
    for ex in EXAMPLES:
        if ex["name"] in existing:
            continue
        path = os.path.join(EXAMPLE_DIR, ex["file"])
        if not os.path.exists(path):
            continue
        text = open(path, encoding="utf-8").read()
        if text.lstrip().lower().startswith("illustrative"):
            text = "\n".join(text.split("\n")[2:]).strip() or text
        did = uuid.uuid4().hex[:10]
        reg[did] = {"name": ex["name"], "manufacturer": ex["manufacturer"], "model": ex["model"],
                    "keywords": ex["keywords"], "created": int(time.time()), "example": True}
        _save_reg(reg)
        # ingest paper
        chunks = rag.chunk_text(text)
        ix = rag.Index().build(chunks, use_ollama=agent.ollama_up())
        _write(did, "index_paper.json", ix.to_dict())
        _write(did, "paper_text.json", {"text": text})
        _write(did, "paper_meta.json", {"filename": ex["file"], "chars": len(text),
                                        "chunks": len(chunks), "retrieval": ix.mode,
                                        "ingested": int(time.time())})
        # pre-run analysis (deterministic for speed; user can re-run with Ollama)
        result = agent.analyze(text, ix, use_ollama=False)
        result["generated"] = int(time.time())
        _write(did, "analysis.json", result)
        # pre-populate candidate SBOM/HBOM from the paper
        b = bom.extract_bom(text); b["generated"] = int(time.time())
        _write(did, "bom.json", b)
        created.append(ex["name"])
    return {"created": created, "count": len(created)}


# --------------------------------------------------------------- BOM (SBOM / HBOM)
@app.post("/api/devices/{did}/bom")
async def device_bom(did: str, file: UploadFile = File(None)):
    _device_or_404(did)
    if file is not None:
        raw = await file.read()
        result = bom.parse_sbom(raw, file.filename)
    else:
        txt = _read(did, "paper_text.json")
        if not txt:
            raise HTTPException(400, "Upload an SBOM file or ingest a white paper first.")
        result = bom.extract_bom(txt["text"])
    result["generated"] = int(time.time())
    _write(did, "bom.json", result)
    return result


# --------------------------------------------------------------- network exposure + FDA records
@app.post("/api/devices/{did}/exposure")
def device_exposure(did: str, payload: dict = Body(default={})):
    dev = _device_or_404(did)
    kw = (payload.get("keyword") or _keywords(dev)).strip()
    out = {"keyword": kw, "notes": [], "fetched": int(time.time())}

    k510, n = sources.fetch_510k(kw); out["fda_510k"] = k510; out["notes"].append(n)
    maude, n = sources.fetch_maude(kw); out["maude"] = maude; out["notes"].append(n)
    out["soc2"] = {"status": "Not public",
                   "note": "SOC 2 reports are confidential — request via the vendor trust center.",
                   "trust_center": sources.trust_center_for(kw + " " + dev.get("manufacturer", ""))}

    if payload.get("shodan_query") is not None or payload.get("shodan_key"):
        sh, n = sources.shodan_search(payload.get("shodan_query") or kw,
                                      payload.get("shodan_key", ""))
        out["shodan"] = sh; out["notes"].append(n)
    if payload.get("ip"):
        idb, n = sources.shodan_internetdb(payload["ip"]); out["internetdb"] = idb; out["notes"].append(n)

    _write(did, "exposure.json", out)
    return out


# --------------------------------------------------------------- static
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/")
def root():
    return FileResponse(os.path.join(STATIC, "index.html"))
