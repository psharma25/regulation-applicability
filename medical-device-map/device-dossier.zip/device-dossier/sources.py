"""
sources.py — pull published vulnerabilities/advisories for a device.

Sources:
  * NVD 2.0 keyword search   (services.nvd.nist.gov) — structured CVE records.
  * CISA KEV catalog         (www.cisa.gov)          — known-exploited filter.
  * CISA ICS Medical RSS     (best effort)           — medical-device advisories.
  * HHS HC3                  — noted as a manual source (no public query API).

Every fetch is defensive: network/parse failures return an empty list plus a
human-readable note, so the app degrades gracefully (and works offline).
Records are normalized to:
  {id, title, description, published, severity, source, url}
"""
from __future__ import annotations
import os, re, json
from typing import List, Dict, Tuple
from xml.etree import ElementTree as ET

import requests

NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"
KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
ICS_MED_RSS = "https://www.cisa.gov/cybersecurity-advisories/ics-medical-advisories.xml"
FDA_ENFORCE = "https://api.fda.gov/device/enforcement.json"
HEADERS = {"User-Agent": "MedDeviceRAG/1.0"}
TIMEOUT = 20

# vendor product-security / trust-center starting points (verify; pages change)
TRUST_CENTERS = {
    "bd": ("BD Product Security", "https://www.bd.com/en-us/about-bd/cybersecurity"),
    "becton": ("BD Product Security", "https://www.bd.com/en-us/about-bd/cybersecurity"),
    "philips": ("Philips Product Security", "https://www.philips.com/productsecurity"),
    "abbott": ("Abbott Product & Device Security", "https://www.abbott.com/policies/product-and-device-security.html"),
    "insulet": ("Insulet Product Security", "https://www.insulet.com/"),
    "johnson": ("J&J MedTech Product Security", "https://www.jnjmedtech.com/"),
    "stryker": ("Stryker Product Security", "https://www.stryker.com/us/en/about/governance/product-security.html"),
}
CYBER_WORDS = ["cyber", "security", "vulnerab", "software", "network", "authentication",
               "encryption", "password", "firmware", "hacker", "unauthorized", "patch", "malware"]


def _norm(id_, title, desc, pub, sev, source, url, remediation="", status="") -> Dict:
    return {"id": id_ or "", "title": title or "", "description": desc or "",
            "published": (pub or "")[:10], "severity": sev or "UNKNOWN",
            "source": source, "url": url or "",
            "remediation": remediation or "", "status": status or ""}


def trust_center_for(keyword: str) -> Dict:
    kw = keyword.lower()
    for k, (name, url) in TRUST_CENTERS.items():
        if k in kw:
            return {"name": name, "url": url}
    return {}


# ------------------------------------------------------------------ NVD
def fetch_nvd(keyword: str, limit: int = 20) -> Tuple[List[Dict], str]:
    try:
        r = requests.get(NVD_API, headers=HEADERS, timeout=TIMEOUT,
                         params={"keywordSearch": keyword, "resultsPerPage": min(limit, 50)})
        r.raise_for_status()
        out = []
        for item in r.json().get("vulnerabilities", [])[:limit]:
            cve = item.get("cve", {})
            cid = cve.get("id")
            descs = cve.get("descriptions", [])
            desc = next((d["value"] for d in descs if d.get("lang") == "en"), "")
            sev = "UNKNOWN"
            metrics = cve.get("metrics", {})
            for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
                if metrics.get(key):
                    cd = metrics[key][0].get("cvssData", {})
                    sev = cd.get("baseSeverity") or (f"{cd.get('baseScore')}" if cd.get("baseScore") else "UNKNOWN")
                    break
            out.append(_norm(cid, cid, desc, cve.get("published"), sev, "NVD",
                             f"https://nvd.nist.gov/vuln/detail/{cid}",
                             remediation="See linked NVD references for vendor advisory / patch.",
                             status="Published (CVE)"))
        return out, f"NVD: {len(out)} record(s) for '{keyword}'."
    except Exception as e:
        return [], f"NVD unavailable ({type(e).__name__}). Check network / rate limits."


# ------------------------------------------------------------------ CISA KEV
def fetch_kev(keyword: str, limit: int = 20) -> Tuple[List[Dict], str]:
    try:
        r = requests.get(KEV_URL, headers=HEADERS, timeout=TIMEOUT)
        r.raise_for_status()
        kw = keyword.lower()
        out = []
        for v in r.json().get("vulnerabilities", []):
            blob = " ".join(str(v.get(k, "")) for k in
                            ("vendorProject", "product", "vulnerabilityName", "shortDescription")).lower()
            if kw in blob:
                out.append(_norm(v.get("cveID"),
                                 f"{v.get('vendorProject','')} {v.get('product','')} — {v.get('vulnerabilityName','')}".strip(),
                                 v.get("shortDescription", ""), v.get("dateAdded"),
                                 "KNOWN-EXPLOITED", "CISA KEV",
                                 f"https://nvd.nist.gov/vuln/detail/{v.get('cveID')}",
                                 remediation=v.get("requiredAction", "Apply vendor updates per CISA KEV."),
                                 status=f"Known-exploited; remediate by {v.get('dueDate','')}".strip("; ")))
            if len(out) >= limit:
                break
        return out, f"CISA KEV: {len(out)} known-exploited match(es)."
    except Exception as e:
        return [], f"CISA KEV unavailable ({type(e).__name__})."


# ------------------------------------------------------------------ CISA ICS medical (RSS, best effort)
def fetch_ics_medical(keyword: str, limit: int = 15) -> Tuple[List[Dict], str]:
    try:
        r = requests.get(ICS_MED_RSS, headers=HEADERS, timeout=TIMEOUT)
        r.raise_for_status()
        root = ET.fromstring(r.content)
        kw = keyword.lower()
        out = []
        for it in root.iter("item"):
            title = (it.findtext("title") or "")
            desc = (it.findtext("description") or "")
            link = (it.findtext("link") or "")
            pub = (it.findtext("pubDate") or "")
            if kw in (title + " " + desc).lower():
                out.append(_norm(title.split(":")[0].strip(), title, re.sub("<[^>]+>", "", desc),
                                 pub, "ADVISORY", "CISA ICS Medical", link,
                                 remediation="See CISA advisory for mitigations.",
                                 status="ICS-Medical advisory"))
            if len(out) >= limit:
                break
        return out, f"CISA ICS Medical: {len(out)} advisory match(es)."
    except Exception as e:
        return [], f"CISA ICS Medical feed unavailable ({type(e).__name__})."


HHS_NOTE = ("HHS HC3 publishes threat briefs as PDFs without a public query API — "
            "review manually at hhs.gov/hc3 for device-specific briefs.")


# ------------------------------------------------------------------ FDA recalls (openFDA)
def fetch_recalls(keyword: str, limit: int = 25, cyber_only: bool = True) -> Tuple[List[Dict], str]:
    """FDA device recalls/enforcement, optionally filtered to cybersecurity-related reasons."""
    try:
        q = f'product_description:"{keyword}"'
        r = requests.get(FDA_ENFORCE, headers=HEADERS, timeout=TIMEOUT,
                         params={"search": q, "limit": min(limit, 50)})
        if r.status_code == 404:
            return [], f"FDA recalls: none found for '{keyword}'."
        r.raise_for_status()
        out = []
        for it in r.json().get("results", []):
            reason = it.get("reason_for_recall", "") or ""
            is_cyber = any(w in reason.lower() for w in CYBER_WORDS)
            if cyber_only and not is_cyber:
                continue
            out.append({
                "id": it.get("recall_number", ""),
                "reason": reason,
                "status": it.get("status", "Unknown"),               # Ongoing / Completed / Terminated
                "classification": it.get("classification", ""),       # Class I/II/III
                "date": (it.get("recall_initiation_date", "") or "")[:10],
                "product": it.get("product_description", "")[:160],
                "firm": it.get("recalling_firm", ""),
                "cyber": is_cyber,
            })
        msg = f"FDA recalls: {len(out)} cybersecurity-related recall(s) for '{keyword}'." if cyber_only \
              else f"FDA recalls: {len(out)} recall(s) for '{keyword}'."
        return out, msg
    except Exception as e:
        return [], f"FDA recalls unavailable ({type(e).__name__})."


def fetch_all(keyword: str, sources: List[str], limit: int = 20) -> Dict:
    records, notes = [], []
    if "nvd" in sources:
        recs, note = fetch_nvd(keyword, limit); records += recs; notes.append(note)
    if "kev" in sources:
        recs, note = fetch_kev(keyword, limit); records += recs; notes.append(note)
    if "cisa" in sources:
        recs, note = fetch_ics_medical(keyword, limit); records += recs; notes.append(note)
    if "hhs" in sources:
        notes.append(HHS_NOTE)
    # dedupe CVEs/advisories by id
    seen, deduped = set(), []
    for r in records:
        key = r["id"] or r["title"]
        if key in seen:
            continue
        seen.add(key); deduped.append(r)
    # cybersecurity recalls (FDA) — included unless explicitly disabled
    recalls, recall_note = ([], "")
    if "fda" in sources or "recalls" in sources or not sources:
        recalls, recall_note = fetch_recalls(keyword)
        notes.append(recall_note)
    return {"records": deduped, "recalls": recalls, "notes": notes,
            "trust_center": trust_center_for(keyword)}


def cve_corpus_text(records: List[Dict], recalls: List[Dict] = None) -> List[str]:
    """One retrievable chunk per advisory/CVE/recall (so Ask covers them)."""
    out = [f"{r['id']} ({r['source']}, severity {r['severity']}, status {r.get('status','')}, {r['published']}): "
           f"{r['title']}. {r['description']} Remediation: {r.get('remediation','')}".strip()
           for r in records if (r['description'] or r['title'])]
    for rc in (recalls or []):
        out.append(f"FDA recall {rc['id']} ({rc.get('classification','')}, status {rc.get('status','')}, "
                   f"{rc.get('date','')}): {rc.get('reason','')} — {rc.get('product','')}".strip())
    return out


# ------------------------------------------------------------------ FDA 510(k) metadata
FDA_510K = "https://api.fda.gov/device/510k.json"
FDA_EVENT = "https://api.fda.gov/device/event.json"


def fetch_510k(keyword: str, limit: int = 10) -> Tuple[List[Dict], str]:
    try:
        r = requests.get(FDA_510K, headers=HEADERS, timeout=TIMEOUT,
                         params={"search": f'device_name:"{keyword}"', "limit": min(limit, 20)})
        if r.status_code == 404:
            return [], f"FDA 510(k): none found for '{keyword}'."
        r.raise_for_status()
        out = []
        for it in r.json().get("results", []):
            out.append({"k_number": it.get("k_number", ""), "device_name": it.get("device_name", ""),
                        "applicant": it.get("applicant", ""), "product_code": it.get("product_code", ""),
                        "decision_date": (it.get("decision_date", "") or "")[:10],
                        "clearance_type": it.get("clearance_type", "")})
        return out, f"FDA 510(k): {len(out)} clearance record(s) for '{keyword}'."
    except Exception as e:
        return [], f"FDA 510(k) unavailable ({type(e).__name__})."


# ------------------------------------------------------------------ MDR / MAUDE adverse events
def fetch_maude(keyword: str, limit: int = 25) -> Tuple[Dict, str]:
    """MAUDE adverse-event reports; flags software/cyber-related events."""
    try:
        r = requests.get(FDA_EVENT, headers=HEADERS, timeout=TIMEOUT,
                         params={"search": f'device.brand_name:"{keyword}"', "limit": min(limit, 50)})
        if r.status_code == 404:
            return {"total": 0, "cyber_related": [], "sample": []}, f"MAUDE: no MDR reports for '{keyword}'."
        r.raise_for_status()
        results = r.json().get("results", [])
        meta_total = r.json().get("meta", {}).get("results", {}).get("total", len(results))
        cyber, sample = [], []
        for ev in results:
            texts = []
            for mt in ev.get("mdr_text", []) or []:
                texts.append(mt.get("text", "") or "")
            blob = " ".join(texts).lower()
            problems = " ".join(ev.get("product_problems", []) or []).lower()
            rec = {"report_number": ev.get("report_number", "") or ev.get("mdr_report_key", ""),
                   "date": (ev.get("date_received", "") or "")[:10],
                   "event_type": ev.get("event_type", ""),
                   "problems": ev.get("product_problems", []) or [],
                   "snippet": (texts[0][:200] if texts else "")}
            if len(sample) < 5:
                sample.append(rec)
            if any(w in blob or w in problems for w in CYBER_WORDS):
                cyber.append(rec)
        return {"total": meta_total, "cyber_related": cyber, "sample": sample}, \
               f"MAUDE: {meta_total} total MDR report(s); {len(cyber)} software/cyber-related in sample."
    except Exception as e:
        return {"total": 0, "cyber_related": [], "sample": []}, f"MAUDE unavailable ({type(e).__name__})."


# ------------------------------------------------------------------ Shodan (network exposure)
def shodan_search(query: str, api_key: str, limit: int = 20) -> Tuple[Dict, str]:
    """Passive attack-surface lookup. Requires the caller's own Shodan API key.
    Authorized OSINT only — do not query assets you are not permitted to assess."""
    if not api_key:
        return {}, "Shodan: provide your own API key to query network exposure."
    try:
        r = requests.get("https://api.shodan.io/shodan/host/search",
                         params={"key": api_key, "query": query, "facets": "port,org,country,product"},
                         timeout=TIMEOUT)
        r.raise_for_status()
        j = r.json()
        facets = j.get("facets", {})
        sample = [{"ip": m.get("ip_str", ""), "port": m.get("port", ""),
                   "org": m.get("org", ""), "product": m.get("product", ""),
                   "country": (m.get("location", {}) or {}).get("country_name", "")}
                  for m in j.get("matches", [])[:limit]]
        return {"total": j.get("total", 0), "facets": facets, "sample": sample}, \
               f"Shodan: {j.get('total', 0)} exposed host(s) for query."
    except Exception as e:
        return {}, f"Shodan error ({type(e).__name__}) — check key/query/credits."


def shodan_internetdb(ip: str) -> Tuple[Dict, str]:
    """Free, keyless Shodan InternetDB: ports/CPEs/known vulns for one IP."""
    if not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", ip or ""):
        return {}, "InternetDB: enter a valid IPv4 address you are authorized to assess."
    try:
        r = requests.get(f"https://internetdb.shodan.io/{ip}", headers=HEADERS, timeout=TIMEOUT)
        r.raise_for_status()
        j = r.json()
        return {"ip": ip, "ports": j.get("ports", []), "hostnames": j.get("hostnames", []),
                "cpes": j.get("cpes", []), "vulns": j.get("vulns", []), "tags": j.get("tags", [])}, \
               f"InternetDB: {len(j.get('ports', []))} open port(s), {len(j.get('vulns', []))} known vuln(s)."
    except Exception as e:
        return {}, f"InternetDB error ({type(e).__name__})."
