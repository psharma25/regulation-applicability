#!/usr/bin/env bash
# MedDevice RAG — one-click local run.
set -e
PORT="${1:-8000}"
python3 -m venv .venv 2>/dev/null || true
. .venv/bin/activate 2>/dev/null || true
pip install -q --disable-pip-version-check -r requirements.txt
echo "MedDevice RAG → http://localhost:${PORT}   (Ctrl+C to stop)"
exec uvicorn app:app --host 0.0.0.0 --port "${PORT}"
