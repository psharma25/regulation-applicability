"""
rag.py — lightweight, dependency-free retrieval for device corpora.

A per-device/per-corpus index over text chunks. Retrieval uses a pure-Python
TF-IDF + cosine implementation so the app works with zero setup. If an Ollama
embedding model is available it is used instead for better recall; otherwise we
fall back to TF-IDF transparently.
"""
from __future__ import annotations
import re, math, json, os
from typing import List, Dict, Tuple, Optional

import requests

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")
EMBED_MODEL = os.environ.get("OLLAMA_EMBED_MODEL", "nomic-embed-text")

_STOP = set("""a an and are as at be by for from has have in into is it its of on or that the to was were will with this these those their they them then than over under between within using used use can may might also such not no but if we our your you device system data security""".split())
_WORD = re.compile(r"[a-z0-9](?:[a-z0-9\-\.]*[a-z0-9])?")
_SENT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9])")


# ---------------------------------------------------------------- chunking
def split_sentences(text: str) -> List[str]:
    text = re.sub(r"\s+", " ", text or "").strip()
    if not text:
        return []
    parts = _SENT.split(text)
    return [p.strip() for p in parts if p.strip()]


def chunk_text(text: str, target: int = 900, overlap: int = 150) -> List[str]:
    """Greedy sentence-packed chunks with character overlap."""
    sents = split_sentences(text)
    chunks, cur = [], ""
    for s in sents:
        if len(cur) + len(s) + 1 <= target:
            cur = (cur + " " + s).strip()
        else:
            if cur:
                chunks.append(cur)
            # start new chunk, carrying overlap tail of previous
            tail = cur[-overlap:] if overlap and cur else ""
            cur = (tail + " " + s).strip()
    if cur:
        chunks.append(cur)
    # guard against pathological single huge sentence
    out = []
    for c in chunks:
        while len(c) > target * 2:
            out.append(c[: target])
            c = c[target - overlap :]
        out.append(c)
    return [c for c in out if c.strip()]


def tokenize(text: str) -> List[str]:
    return [w for w in _WORD.findall((text or "").lower()) if w not in _STOP and len(w) > 1]


# ---------------------------------------------------------------- ollama embeddings (optional)
def _ollama_embed(texts: List[str]) -> Optional[List[List[float]]]:
    vecs = []
    try:
        for t in texts:
            r = requests.post(f"{OLLAMA_URL}/api/embeddings",
                              json={"model": EMBED_MODEL, "prompt": t}, timeout=20)
            r.raise_for_status()
            v = r.json().get("embedding")
            if not v:
                return None
            vecs.append(v)
        return vecs
    except Exception:
        return None


def _cos(a: List[float], b: List[float]) -> float:
    s = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1.0
    nb = math.sqrt(sum(y * y for y in b)) or 1.0
    return s / (na * nb)


# ---------------------------------------------------------------- index
class Index:
    """Holds chunks + either dense embeddings (ollama) or TF-IDF vectors."""

    def __init__(self):
        self.chunks: List[str] = []
        self.mode: str = "tfidf"        # or "embed"
        self.idf: Dict[str, float] = {}
        self.vecs: List[Dict[str, float]] = []   # tfidf sparse, normalized
        self.dense: List[List[float]] = []        # ollama dense

    # ---- build
    def build(self, chunks: List[str], use_ollama: bool = True) -> "Index":
        self.chunks = chunks
        dense = _ollama_embed(chunks) if use_ollama else None
        if dense:
            self.mode, self.dense = "embed", dense
        else:
            self.mode = "tfidf"
            self._build_tfidf(chunks)
        return self

    def _build_tfidf(self, chunks: List[str]):
        n = len(chunks) or 1
        df: Dict[str, int] = {}
        toks = [tokenize(c) for c in chunks]
        for t in toks:
            for w in set(t):
                df[w] = df.get(w, 0) + 1
        self.idf = {w: math.log((n + 1) / (c + 1)) + 1.0 for w, c in df.items()}
        self.vecs = [self._tfidf_vec(t) for t in toks]

    def _tfidf_vec(self, toks: List[str]) -> Dict[str, float]:
        tf: Dict[str, float] = {}
        for w in toks:
            tf[w] = tf.get(w, 0.0) + 1.0
        vec = {w: c * self.idf.get(w, math.log(2.0)) for w, c in tf.items()}
        norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
        return {w: v / norm for w, v in vec.items()}

    # ---- query
    def query(self, text: str, k: int = 5) -> List[Tuple[int, float]]:
        if not self.chunks:
            return []
        if self.mode == "embed" and self.dense:
            qv = _ollama_embed([text])
            if qv:
                scores = [(i, _cos(qv[0], d)) for i, d in enumerate(self.dense)]
                scores.sort(key=lambda x: -x[1])
                return scores[:k]
        # tfidf
        qv = self._tfidf_vec(tokenize(text))
        scores = []
        for i, v in enumerate(self.vecs):
            small, big = (qv, v) if len(qv) < len(v) else (v, qv)
            s = sum(val * big.get(w, 0.0) for w, val in small.items())
            scores.append((i, s))
        scores.sort(key=lambda x: -x[1])
        return scores[:k]

    def retrieve(self, text: str, k: int = 5) -> List[Dict]:
        return [{"i": i, "score": round(s, 4), "text": self.chunks[i]}
                for i, s in self.query(text, k) if s > 0]

    # ---- persistence
    def to_dict(self) -> Dict:
        return {"chunks": self.chunks, "mode": self.mode, "idf": self.idf,
                "vecs": self.vecs, "dense": self.dense}

    @classmethod
    def from_dict(cls, d: Dict) -> "Index":
        ix = cls()
        ix.chunks = d.get("chunks", [])
        ix.mode = d.get("mode", "tfidf")
        ix.idf = d.get("idf", {})
        ix.vecs = d.get("vecs", [])
        ix.dense = d.get("dense", [])
        return ix
