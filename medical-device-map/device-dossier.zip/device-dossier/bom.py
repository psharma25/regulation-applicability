"""
bom.py — Software/Hardware Bill of Materials helpers.

Two paths:
  1) extract_bom(text)        — pull *component mentions* (software + hardware)
                                from the ingested white paper. Lexicon-based
                                deterministic extraction, optional Ollama refine.
  2) parse_sbom(bytes, name)  — parse a real uploaded SBOM in CycloneDX (JSON)
                                or SPDX (JSON or tag-value) into components.

Note: full SBOMs are not published in public FDA data; they are submitted
confidentially. Use parse_sbom() with the manufacturer-provided SBOM for an
authoritative list; extract_bom() gives candidate components from the paper.
"""
from __future__ import annotations
import re, json
from typing import List, Dict, Optional

from rag import split_sentences

# common medical-device SOFTWARE stack components
SW_TERMS = ["linux", "embedded linux", "rtos", "freertos", "vxworks", "qnx",
    "windows", "windows embedded", "windows iot", ".net", "java", "openssl",
    "libssl", "boringssl", "mbedtls", "wolfssl", "busybox", "glibc", "musl",
    "sqlite", "curl", "libcurl", "python", "node.js", "nodejs", "mqtt", "dds",
    "dcmtk", "dicom toolkit", "hl7", "bluez", "wpa_supplicant", "openssh",
    "dropbear", "lighttpd", "apache", "nginx", "zlib", "libxml2", "log4j",
    "spring", "openjdk", "kernel", "u-boot", "tls", "grpc", "protobuf"]

# common HARDWARE components / modules
HW_TERMS = ["arm cortex", "cortex-m", "cortex-a", "stm32", "nrf52", "nrf51",
    "nordic", "cc2540", "esp32", "esp8266", "microcontroller", "mcu", "fpga",
    "soc", "system on chip", "ble module", "bluetooth module", "wi-fi module",
    "wifi module", "cellular modem", "lte modem", "nfc", "rfid", "sensor",
    "battery", "flash memory", "eeprom", "usb controller", "ethernet phy",
    "radio", "antenna", "accelerometer", "gyroscope", "transceiver", "som"]

_VER = re.compile(r"\b(\d+\.\d+(?:\.\d+)?[a-z]?)\b")


def _scan(text: str, terms: List[str], kind: str) -> List[Dict]:
    sents = split_sentences(text)
    found, seen = [], set()
    for s in sents:
        low = s.lower()
        for t in terms:
            if t in low:
                # try to grab a version token near the term
                idx = low.find(t)
                window = s[idx: idx + 60]
                ver = _VER.search(window)
                name = t.title() if t.islower() else t
                key = (t,)
                if key in seen:
                    continue
                seen.add(key)
                found.append({"name": name, "version": ver.group(1) if ver else "",
                              "type": kind, "evidence": s.strip()[:160]})
    return found


def extract_bom(text: str, index=None, use_ollama: bool = False) -> Dict:
    """Candidate SBOM/HBOM components mentioned in the device documentation."""
    return {
        "software": _scan(text, SW_TERMS, "software"),
        "hardware": _scan(text, HW_TERMS, "hardware"),
        "engine": "deterministic",
        "source": "paper-mentions",
    }


# ----------------------------------------------------------------- SBOM file parsing
def parse_sbom(raw: bytes, filename: str = "") -> Dict:
    text = raw.decode("utf-8", "ignore")
    fmt = "unknown"
    comps: List[Dict] = []
    data = None
    try:
        data = json.loads(text)
    except Exception:
        data = None

    if isinstance(data, dict) and ("components" in data or data.get("bomFormat") == "CycloneDX"):
        fmt = "CycloneDX"
        for c in data.get("components", []):
            comps.append({
                "name": c.get("name", ""),
                "version": c.get("version", ""),
                "type": c.get("type", "library"),
                "supplier": (c.get("supplier") or {}).get("name", "") if isinstance(c.get("supplier"), dict) else (c.get("publisher") or ""),
                "license": _cdx_license(c.get("licenses")),
                "purl": c.get("purl", ""),
            })
    elif isinstance(data, dict) and "packages" in data:
        fmt = "SPDX (JSON)"
        for p in data.get("packages", []):
            comps.append({
                "name": p.get("name", ""),
                "version": p.get("versionInfo", ""),
                "type": "package",
                "supplier": p.get("supplier", "") or p.get("originator", ""),
                "license": p.get("licenseConcluded", "") or p.get("licenseDeclared", ""),
                "purl": "",
            })
    elif "SPDXVersion" in text or "PackageName" in text:
        fmt = "SPDX (tag-value)"
        cur = {}
        for line in text.splitlines():
            if line.startswith("PackageName:"):
                if cur.get("name"):
                    comps.append(cur)
                cur = {"name": line.split(":", 1)[1].strip(), "version": "", "type": "package", "supplier": "", "license": "", "purl": ""}
            elif line.startswith("PackageVersion:") and cur:
                cur["version"] = line.split(":", 1)[1].strip()
            elif line.startswith("PackageSupplier:") and cur:
                cur["supplier"] = line.split(":", 1)[1].strip()
            elif line.startswith("PackageLicenseConcluded:") and cur:
                cur["license"] = line.split(":", 1)[1].strip()
        if cur.get("name"):
            comps.append(cur)

    sw = [c for c in comps if c.get("type") not in ("device", "firmware", "hardware")]
    hw = [c for c in comps if c.get("type") in ("device", "firmware", "hardware")]
    return {"format": fmt, "filename": filename, "count": len(comps),
            "software": sw or comps, "hardware": hw, "engine": "uploaded-sbom",
            "source": f"uploaded {fmt}"}


def _cdx_license(licenses) -> str:
    if not licenses:
        return ""
    try:
        out = []
        for l in licenses:
            lic = l.get("license") or {}
            out.append(lic.get("id") or lic.get("name") or l.get("expression", ""))
        return ", ".join(x for x in out if x)
    except Exception:
        return ""
