# AI Security Knowledge Graph — VS Code extension

Opens the workbench in an editor panel, keeps the model in the repository, and
turns every scan your build produces into a trigger.

## Install

**From source, no packaging:**

```bash
git clone <your repo> ai-security-knowledge-graph
code ai-security-knowledge-graph
# press F5 — an Extension Development Host opens with the extension loaded
```

**As a .vsix, for the team:**

```bash
npm i -g @vscode/vsce
vsce package          # produces ai-security-knowledge-graph-1.0.0.vsix
code --install-extension ai-security-knowledge-graph-1.0.0.vsix
```

There is no build step and no runtime dependency. `media/index.html` is the whole
application; replacing that one file upgrades the extension.

## Commands

Command palette, all under **AI Security Knowledge Graph**:

| Command | What it does |
|---|---|
| Open workbench | Opens the panel and sends the workspace file tree |
| Send workspace tree to the model | Re-reads the tree after a large refactor |
| Run the agent pipeline | Feeds, correlation, model update, register, compliance |
| Clean the threat model | Orphans, duplicates, dangling interfaces, stale advisories |
| Run a framework overlay | STRIDE, ATLAS, ATT&CK, ATT&CK for ICS |
| Ingest a scan result | Also on the right-click menu for `.sarif`, `.json`, `.csv`, `.xml` |
| Export the security package | Word report with every diagram |

## What lives in the repository

```
.threatforge/
  model.json          written on every save inside the panel — review it in PRs
  intake/             anything dropped here is sent to the agents automatically
```

`model.json` is a normal JSON file, so the threat model is diffable. A pull
request that adds a network interface shows up as a changed flow with a changed
risk score, next to the code that caused it.

## Wiring CI into it

Have the pipeline write its results into `.threatforge/intake/`. The file
watcher picks them up the moment the developer pulls.

```yaml
# .github/workflows/security.yml
name: security
on: [push, pull_request]
jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Static analysis
        run: semgrep --config auto --sarif -o .threatforge/intake/semgrep.sarif || true
      - name: Composition
        run: syft . -o cyclonedx-json > .threatforge/intake/sbom.cdx.json
      - name: Vulnerabilities
        run: grype sbom:.threatforge/intake/sbom.cdx.json -o cyclonedx-json > .threatforge/intake/grype.cdx.json || true
      - uses: actions/upload-artifact@v4
        with: { name: security-intake, path: .threatforge/intake }
```

For results that never touch the repository — a DAST run, a pentest report, a
CVE notification, a Vanta or Drata attestation — POST an envelope to a small
worker and point **Admin → Continuous feedback → Intake endpoint** at its GET
side:

```json
{
  "source": "dast",
  "tool": "ZAP nightly",
  "ts": "2026-07-27T02:00:00Z",
  "findings": [
    { "id": "zap-10202", "title": "Missing anti-CSRF token", "severity": "medium",
      "asset": "Clinician Portal", "path": "cloud/api/", "description": "…",
      "cve": null, "controls": ["SOC2:CC6.6"] }
  ]
}
```

`source` may be `sast`, `dast`, `sca`, `pentest`, `cve`, `zero-day`,
`compliance` or `test`. SARIF, CycloneDX, SPDX and a pentest CSV are understood
without an envelope.

## Where the outputs go

- Register entries, evidence and the outbox live with the project in `model.json`.
- The outbox POSTs to whatever you configure under **Admin → Continuous feedback**.
  Point it at a worker that holds the Jira, ServiceNow, Vanta or Drata credential
  and maps the payload; the browser never sees a token.
- Download the outbox instead if a scheduled job should deliver it.
