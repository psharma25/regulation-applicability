# SecIntel RAG — Threat & Breach Intelligence (single file)

`index.html` is a self-contained, offline-capable RAG threat tracker. Open in any browser.

## Corpus (188 records)
- **National (80):** curated, source-linked landmark + recent ransomware, nation-state, SEC 8-K, and HHS OCR incidents.
- **Massachusetts (108):**
  - 102 verbatim 2026 records from the **MA OCABR** breach-notification reports (M.G.L. c.93H), with data-type flags; official yearly totals 2019–2026 in the stats panel.
  - 6 curated **major MA-company incidents** from public threat intel: **MathWorks** (Natick — ransomware, May 2025), **Point32Health / Harvard Pilgrim** (Canton — ransomware, 2.86M, 2023), **Shields Health Care Group** (Quincy — 2.3M, 2022), **UKG / Kronos** (Lowell — ransomware, 2021), **TJX** (Framingham — 45.6M cards, 2007), and the FBI-thwarted Iranian attack on **Boston Children's Hospital** (2021).

## Features
- RAG analyst (client-side TF-IDF retrieval + stemming + entity boosting) grounded in retrieved records, with numbered citations. Connect a local **Ollama** model (⚙) for generative answers; offline retrieval planner otherwise.
- Scope switch (All / National / Massachusetts), domain/sector/entity/year filters, threat/year/entity search.
- Default Table view sorted 2026-first; Card/Compact views; sortable columns.
- Incident detail slide-over: what happened, vector, impact, attribution, tailored mitigations, and **Links & references** (primary source + auto SEC EDGAR / HHS OCR / MA OCABR / CISA / web lookups).
- Light/dark theme.

## Going live
`OLLAMA_ORIGINS='*' ollama serve` (browsers block file:// → Ollama by CORS otherwise).

## Disclaimer
National + MA-company records are source-linked but illustrative, not exhaustive. MA OCABR data is public government data. Mitigations are recommended controls keyed to threat type. Planning intelligence, not legal advice.
