# Patch Management Standard

## 1. Purpose & Scope
To define patch cadence and SLAs for deployment. Applies to all managed assets requiring patching.

## 2. Normative Requirements
1. Vendor patches **shall** be assessed within defined windows of release.
2. Standard patch cadence **shall** be at least monthly; out-of-band patching **shall** apply to actively exploited flaws.
3. Patches **shall** be tested before broad deployment, except emergency cases.
4. Patch deployment **shall** meet the remediation timelines in the Vulnerability Management Standard.
5. Patch compliance **shall** be measured and reported.
6. Unsupported/end-of-life software **shall** be remediated or risk-accepted with compensating controls.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Patch cadence & SLAs | ISO/IEC 27001:2022 A.8.8; NIST SP 800-40 |
| Testing & rollback | NIST SP 800-53 CM-3, SI-2 |

## 4. Metrics & Compliance
- Patch compliance percentage.
- EOL systems remaining.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.8.8
- NIST SP 800-40
- NIST SP 800-53 SI-2
