# Secure Configuration & Hardening Policy

## 1. Purpose
To mandate hardening of systems and platforms to reduce attack surface.

## 2. Scope
Applies to all operating systems, applications, databases, containers and cloud services.

## 3. Policy Statements
1. Systems **shall** be hardened to an approved baseline before production use.
2. Unused services, ports, accounts and features **shall** be disabled or removed.
3. Default credentials **shall** be changed and administrative interfaces protected.
4. Hardening **shall** be verified by automated configuration scanning.
5. Deviations **shall** be risk-assessed, documented and approved.
6. Baselines **shall** track recognized benchmarks (e.g., CIS) and be updated regularly.

## 4. Roles & Responsibilities
- **Platform/Engineering Teams** — apply hardening.
- **Security** — defines baselines and verifies compliance.
- **System Owners** — maintain hardened state.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.9
- CIS Benchmarks
- NIST SP 800-53 CM-6, CM-7
- DISA STIGs (where applicable)
