# Backup & Recovery Standard

## 1. Purpose & Scope
To define backup frequency, recovery objectives and restore-test requirements. Applies to all critical data and systems.

## 2. Normative Requirements
1. Each critical system **shall** have documented RPO and RTO.
2. Backup frequency **shall** meet the RPO; critical data RPO **shall not** exceed 24 hours unless risk-accepted.
3. At least one backup copy **shall** be immutable or offline to resist ransomware.
4. Restore tests **shall** be performed at least quarterly for critical systems.
5. Backups **shall** be encrypted and access-controlled.
6. Backup success/failure **shall** be monitored and remediated.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Backup & RPO/RTO | ISO/IEC 27001:2022 A.8.13; NIST SP 800-53 CP-9/CP-10 |
| Immutability & ransomware | NIST SP 800-209 |

## 4. Metrics & Compliance
- Restore-test success rate.
- Backup failure rate.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.8.13
- NIST SP 800-53 CP family
- NIST SP 800-209
