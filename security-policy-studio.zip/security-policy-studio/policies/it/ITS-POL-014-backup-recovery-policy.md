# Backup & Recovery Policy

## 1. Purpose
To ensure data and systems can be restored after loss, corruption or ransomware through reliable, tested backups.

## 2. Scope
Applies to all critical data and systems within scope.

## 3. Policy Statements
1. Backups **shall** be performed at frequencies meeting defined recovery-point objectives (**RPO**).
2. Backups **shall** follow a resilient strategy (e.g., 3-2-1) with at least one **immutable or offline** copy.
3. Backup data **shall** be encrypted and access-controlled.
4. Restore tests **shall** be performed at least quarterly for critical systems and recorded.
5. Recovery-time objectives (**RTO**) **shall** be defined and validated.
6. Backup infrastructure **shall** be segregated from production credentials to resist ransomware.
7. Backup failures **shall** alert and be remediated promptly.

## 4. Roles & Responsibilities
- **Backup/IT Operations** — operates and tests backups.
- **System Owners** — define RPO/RTO.
- **Security** — assures backup integrity and isolation.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.13
- NIST SP 800-53 CP-9, CP-10
- NIST SP 800-209
