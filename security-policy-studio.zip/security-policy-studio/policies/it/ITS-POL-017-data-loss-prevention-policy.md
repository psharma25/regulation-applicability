# Data Loss Prevention Policy

## 1. Purpose
To prevent unauthorized disclosure or exfiltration of sensitive data.

## 2. Scope
Applies to sensitive data in use, in motion and at rest across endpoints, email, web and cloud.

## 3. Policy Statements
1. DLP controls **shall** be deployed to detect and prevent unauthorized movement of Confidential and Restricted data.
2. DLP policies **shall** align to data classification and regulatory obligations.
3. High-risk egress channels (email, web upload, removable media, cloud sync) **shall** be monitored and controlled.
4. DLP alerts **shall** be triaged; confirmed exfiltration **shall** be handled as an incident.
5. Encryption and rights management **shall** support DLP for the most sensitive data.
6. DLP exceptions **shall** be documented and time-bound.

## 4. Roles & Responsibilities
- **Security/DLP Team** — operates and tunes DLP.
- **Data Owners** — define sensitive data and rules.
- **Incident Response** — handles confirmed exfiltration.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.12
- NIST SP 800-53 AC-4, SC-7
- Data Classification & Handling Policy (ENT-POL-005)
