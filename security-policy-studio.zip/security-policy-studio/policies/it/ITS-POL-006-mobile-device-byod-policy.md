# Mobile Device & BYOD Policy

## 1. Purpose
To secure mobile and personally-owned (BYOD) devices that access Organization data.

## 2. Scope
Applies to all mobile devices, including BYOD, used to access Organization information or services.

## 3. Policy Statements
1. Mobile access to Organization data **shall** require enrollment in mobile device management (MDM) or a managed container.
2. Devices **shall** enforce screen lock, encryption and minimum OS version; jailbroken/rooted devices **shall** be blocked.
3. Organization data on BYOD **shall** be containerized and remotely wipeable without affecting personal data where feasible.
4. Only approved apps **shall** access Organization data; sideloading of risky apps **shall** be restricted.
5. Lost or stolen devices **shall** be reported promptly and the Organization data wiped.
6. BYOD use **shall** be subject to user acknowledgment of monitoring and wipe terms.

## 4. Roles & Responsibilities
- **IT/MDM Team** — operates enrollment and policy enforcement.
- **Security** — sets device requirements.
- **Users** — maintain compliant devices and report loss.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.6.7, A.8.1
- NIST SP 800-124
- NIST SP 800-53 AC-19
