# Patch Management Procedure

## 1. Purpose
To operate the regular and emergency patching workflow.

## 2. Scope
Applies to patching of all managed assets.

## 3. Roles (RACI)
| Activity | System Owner | Patch/IT Ops | Security | Change Mgmt |
| --- | --- | --- | --- | --- |
| Identify applicable patches | I | R | A | I |
| Risk-assess & schedule | C | R | A | C |
| Test patches | C | R | C | I |
| Approve change | C | C | C | A |
| Deploy & verify | A | R | C | I |

## 4. Process Steps
1. **Identify** — collect applicable patches from vendor feeds and vulnerability data. Outputs: patch list.
2. **Assess** — prioritize by severity/exploitability and schedule within SLA. Outputs: schedule.
3. **Test** — validate in non-production; prepare rollback. Outputs: test results.
4. **Approve** — obtain change approval (expedited for emergencies). Outputs: change record.
5. **Deploy** — roll out in waves and verify success. Outputs: deployment report.
6. **Confirm** — rescan to confirm remediation and update compliance. Outputs: updated status.

## 5. Records & Evidence
- Patch lists, test results, change records, deployment and compliance reports.

## 6. Related Documents & References
- Patch Management Standard (ITS-STD-009)
- Vulnerability & Patch Management Policy (ITS-POL-012)
- Change Management Policy (ITS-POL-015)
