# Logging & Audit Standard

## 1. Purpose & Scope
To define required log events, fields, retention and integrity. Applies to all in-scope log sources.

## 2. Normative Requirements
1. Logs **shall** capture authentication, authorization, privileged actions, configuration changes and security events.
2. Each event **shall** include timestamp (synchronized), source, actor, action and outcome.
3. Logs **shall** be centralized, access-controlled and protected against tampering.
4. Security logs **shall** be retained for at least 12 months (or longer where required), with 90 days readily searchable.
5. Critical detections **shall** generate alerts to the SOC.
6. Log source coverage **shall** be monitored for gaps.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Event coverage & fields | ISO/IEC 27001:2022 A.8.15; NIST SP 800-92 |
| Integrity & access | NIST SP 800-53 AU-9 |
| Retention | NIST SP 800-53 AU-11; sector regulation |

## 4. Metrics & Compliance
- Log-source coverage percentage.
- Alert triage time.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.8.15-A.8.17
- NIST SP 800-92
- NIST SP 800-53 AU family
