# Cloud Security Policy

## 1. Purpose
To secure the Organization's use of cloud services under the shared-responsibility model.

## 2. Scope
Applies to all IaaS, PaaS and SaaS services and cloud accounts used by the Organization.

## 3. Policy Statements
1. Cloud accounts/subscriptions **shall** be governed centrally with enforced guardrails and baselines.
2. The shared-responsibility split **shall** be documented for each service.
3. Identity **shall** be federated; root/owner accounts **shall** be protected with MFA and seldom used.
4. Cloud resources **shall** be deployed via reviewed infrastructure-as-code with secure defaults.
5. Data **shall** be classified, encrypted and access-controlled; public exposure **shall** be prevented by default.
6. Cloud security posture **shall** be continuously monitored (CSPM) and misconfigurations remediated.
7. Logging **shall** be enabled across cloud accounts and centralized for monitoring.

## 4. Roles & Responsibilities
- **Cloud Platform/Engineering** — operates landing zones and guardrails.
- **Security** — defines baselines and monitors posture.
- **Workload Owners** — secure their cloud workloads.
- **CISO** — owns cloud risk.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.23, A.8.x
- ISO/IEC 27017 / 27018
- CIS Benchmarks (cloud)
- NIST SP 800-53; CSA CCM
