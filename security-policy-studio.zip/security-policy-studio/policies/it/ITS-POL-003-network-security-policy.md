# Network Security Policy

## 1. Purpose
To protect Organization networks through segmentation, controlled connectivity and monitoring.

## 2. Scope
Applies to all wired, wireless, virtual and cloud networks and remote-access services.

## 3. Policy Statements
1. Networks **shall** be segmented into trust zones; sensitive and OT environments **shall** be isolated from general networks.
2. Traffic between zones **shall** be controlled by default-deny rules and inspected where appropriate.
3. Remote access **shall** use encrypted, MFA-protected channels (VPN or zero-trust access).
4. Network devices **shall** be hardened, patched and centrally managed.
5. Network changes **shall** follow change management; rule bases **shall** be reviewed periodically.
6. Network activity **shall** be logged and monitored for anomalies.
7. Wireless networks **shall** use strong authentication and encryption; guest access **shall** be isolated.

## 4. Roles & Responsibilities
- **Network Engineering** — designs and operates the network securely.
- **Security** — sets requirements and monitors traffic.
- **Change Management** — governs network changes.
- **OT/Plant teams** — coordinate segmentation for industrial systems.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.20-A.8.22
- NIST SP 800-53 SC-7
- IEC 62443-3-3 (zones & conduits)
- NIST SP 800-82 (OT)
