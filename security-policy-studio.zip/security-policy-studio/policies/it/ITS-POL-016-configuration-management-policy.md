# Configuration Management Policy

## 1. Purpose
To establish and maintain secure baseline configurations and control configuration drift.

## 2. Scope
Applies to all managed systems, devices and cloud resources.

## 3. Policy Statements
1. Approved baseline configurations **shall** be defined for each platform (see Hardening Standard).
2. Systems **shall** be deployed from approved baselines or images.
3. Configuration **shall** be managed as code or via configuration-management tooling where feasible.
4. Drift from baseline **shall** be detected and remediated.
5. Unauthorized configuration changes **shall** be prevented or alerted.
6. A configuration inventory/CMDB **shall** be maintained.
7. Baselines **shall** be reviewed and updated for new threats and versions.

## 4. Roles & Responsibilities
- **Configuration/Platform Team** — maintains baselines and CMDB.
- **System Owners** — keep systems compliant.
- **Security** — defines and audits baselines.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.9
- NIST SP 800-53 CM family
- CIS Benchmarks
