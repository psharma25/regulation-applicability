# Cloud Security Baseline Standard

## 1. Purpose & Scope
To define mandatory guardrails for cloud accounts and workloads. Applies to all IaaS/PaaS accounts and subscriptions.

## 2. Normative Requirements
1. Root/owner accounts **shall** have MFA and be used only for break-glass.
2. Centralized logging and a security-monitoring baseline **shall** be enabled in every account.
3. Public exposure of storage and databases **shall** be blocked by default; exceptions require approval.
4. Encryption at rest **shall** be enabled using managed keys; customer-managed keys for Restricted data.
5. Infrastructure **shall** be provisioned via reviewed IaC; manual changes **shall** be minimized.
6. Posture management (CSPM) **shall** continuously check against the baseline.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Account guardrails | ISO/IEC 27017; CIS cloud benchmarks |
| Data protection | ISO/IEC 27018; NIST SP 800-53 SC-28 |
| Posture monitoring | CSA CCM; NIST SP 800-53 CA-7 |

## 4. Metrics & Compliance
- CSPM compliance score.
- Number of public-exposure exceptions.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27017 / 27018
- CIS cloud benchmarks
- CSA CCM
- NIST SP 800-53
