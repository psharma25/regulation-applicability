# Certificate Management Policy

## 1. Purpose
To manage the lifecycle of digital certificates to prevent outages and trust failures.

## 2. Scope
Applies to all TLS, code-signing, client and device certificates used by the Organization.

## 3. Policy Statements
1. Certificates **shall** be issued only from approved certificate authorities.
2. A complete **certificate inventory** with expiry tracking **shall** be maintained.
3. Certificates **shall** be renewed before expiry; automated renewal **shall** be used where feasible.
4. Private keys **shall** be protected and **shall not** be shared across unrelated systems.
5. Weak keys, algorithms and short validity violations **shall** be prohibited (see Certificate & PKI Standard).
6. Compromised or mis-issued certificates **shall** be revoked promptly.
7. Internal CA infrastructure **shall** be hardened and access-controlled.

## 4. Roles & Responsibilities
- **PKI/Certificate Team** — operates issuance and renewal.
- **Service Owners** — track and renew their certificates.
- **Security** — sets PKI requirements and monitors expiry.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.24
- NIST SP 800-57
- CA/Browser Forum Baseline Requirements
