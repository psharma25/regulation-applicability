# Change Management Policy

## 1. Purpose
To ensure changes to systems and configurations are controlled, assessed and reversible.

## 2. Scope
Applies to changes to production systems, applications, infrastructure and configurations across the ISMS and QMS.

## 3. Policy Statements
1. All changes **shall** be requested, risk-assessed and authorized before implementation.
2. Changes **shall** be classified (standard, normal, emergency) with appropriate approval paths.
3. Security impact **shall** be assessed for each change.
4. Changes **shall** be tested and have a documented rollback plan.
5. Emergency changes **shall** follow an expedited path and be reviewed retrospectively.
6. Change records **shall** be retained and traceable.
7. Segregation of duties **shall** apply between request, approval and implementation where feasible.

## 4. Roles & Responsibilities
- **Change Manager / CAB** — governs and approves changes.
- **Requestors/Implementers** — submit and execute changes.
- **Security** — assesses security impact.
- **QA** — validates changes affecting regulated product.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.32
- ISO 13485:2016 Cl. 7.5
- NIST SP 800-53 CM-3
