# Privileged Access Management Procedure

## 1. Purpose
To request, approve, check out and review privileged access.

## 2. Scope
Applies to all privileged access via the PAM solution.

## 3. Roles (RACI)
| Activity | Requestor | System Owner | PAM/IAM | Security |
| --- | --- | --- | --- | --- |
| Request access | R | A | C | I |
| Approve | I | A | C | C |
| Check out / elevate | R | I | A | I |
| Monitor session | I | I | C | A |
| Review & revoke | I | A | R | C |

## 4. Process Steps
1. **Request** — submit a privileged-access request with justification and duration. Outputs: request.
2. **Approve** — system owner approves; security reviews high-risk requests. Outputs: approval.
3. **Elevate** — retrieve credentials or elevate just-in-time through the vault. Outputs: session.
4. **Monitor** — log/record the session. Outputs: session log.
5. **Revoke & review** — expire access and include in quarterly recertification. Outputs: review record.

## 5. Records & Evidence
- Access requests, approvals, session logs and recertifications.

## 6. Related Documents & References
- Privileged Access Management Policy (ITS-POL-002)
- IAM & MFA Standard (ITS-STD-004)
