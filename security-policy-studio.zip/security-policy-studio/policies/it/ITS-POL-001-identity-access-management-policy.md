# Identity & Access Management Policy

## 1. Purpose
To govern the full lifecycle of digital identities and their entitlements, ensuring authenticated, authorized and accountable access, per **ISO/IEC 27001:2022 A.5.15-A.5.18, A.8.2-A.8.5**.

## 2. Scope
Applies to all identity types — workforce, privileged, service/machine and third-party — across all systems within scope.

## 3. Policy Statements
1. Identities **shall** be **uniquely** assigned and traceable to an accountable owner; shared interactive identities are prohibited.
2. **Role-based access control (RBAC)** with documented role definitions **shall** be the default authorization model.
3. **Multi-factor authentication shall** be enforced for all remote, privileged and sensitive access, using phishing-resistant methods where feasible.
4. **Privileged accounts shall** be vaulted, individually attributable, just-in-time where practical, and session-logged.
5. **Service and machine identities shall** be inventoried, owned, and credential-rotated; secrets **shall not** be hard-coded.
6. Joiner/mover/leaver changes **shall** be executed promptly; termination access removal **shall** complete the same business day.
7. **Access recertification shall** occur at least every six months (privileged quarterly).
8. Federation and SSO **shall** be preferred; directory integrations **shall** enforce centralized policy.

## 4. Roles & Responsibilities
- **IAM Team** — operates the identity platform and lifecycle automation.
- **System Owners** — define roles and authorize/recertify access.
- **Security** — monitors privileged activity and policy conformance.
- **Managers / HR** — trigger lifecycle events.

## 5. Compliance & Enforcement
Verified through access reviews, privileged-session monitoring and audit. Orphaned, excessive or unauthorized access is a reportable nonconformity.

## 6. Exceptions
Break-glass and standing exceptions **shall** be documented, monitored and CISO-approved.

## 7. Review & Maintenance
Reviewed at least annually.

## 8. References
ISO/IEC 27001:2022 A.5.15-A.5.18, A.8.2-A.8.5; NIST SP 800-63; NIST SP 800-53 AC/IA families; NIST SP 800-171 3.1.x / 3.5.x; CMMC AC & IA.
