# IAM & MFA Standard

## 1. Purpose & Scope
To define authenticator assurance, MFA and session requirements. Applies to authentication to all Organization systems.

## 2. Normative Requirements
1. Remote, privileged and sensitive access **shall** require MFA at AAL2 or higher.
2. Phishing-resistant authenticators (FIDO2/WebAuthn, PIV/CAC) **shall** be used for privileged and high-risk access where feasible.
3. SMS-based OTP **shall** be avoided for privileged access.
4. Identity federation/SSO **shall** be preferred over local credentials.
5. Sessions **shall** expire after defined idle and absolute lifetimes.
6. Step-up authentication **shall** be required for sensitive transactions.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| MFA & assurance | NIST SP 800-63B (AAL2+); ISO/IEC 27001:2022 A.8.5 |
| Phishing resistance | FIDO2/WebAuthn; NIST 800-171 3.5.3 |
| Session management | NIST SP 800-53 AC-12 |

## 4. Metrics & Compliance
- MFA coverage by access type.
- Percentage of privileged access using phishing-resistant MFA.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NIST SP 800-63B
- ISO/IEC 27001:2022 A.5.17, A.8.5
- NIST SP 800-171 3.5.x
