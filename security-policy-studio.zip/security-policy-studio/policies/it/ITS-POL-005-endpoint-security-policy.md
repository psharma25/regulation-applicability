# Endpoint Security Policy

## 1. Purpose
To protect endpoints against compromise through hardening, detection, encryption and control.

## 2. Scope
Applies to all servers, workstations, laptops and managed mobile endpoints.

## 3. Policy Statements
1. Endpoints **shall** be deployed from a hardened baseline and centrally managed.
2. Endpoint detection and response (**EDR**) **shall** be installed, active and monitored on all supported endpoints.
3. Disk encryption **shall** be enabled on all portable endpoints.
4. Only approved software **shall** run; application allow-listing **shall** be used on high-risk endpoints.
5. Endpoints **shall** be patched within the timelines of the Patch Management Standard.
6. Local administrative rights **shall** be restricted and managed.
7. Lost or compromised endpoints **shall** be remotely locked or wiped and reported.

## 4. Roles & Responsibilities
- **Endpoint/IT Operations** — deploys and maintains endpoints.
- **Security/SOC** — monitors EDR and responds.
- **Users** — keep devices managed and report issues.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.1, A.8.7, A.8.24
- NIST SP 800-53 SI-3, SC-28
- CIS Controls v8 4 & 10
