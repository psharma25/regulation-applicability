# Server Hardening WI

## 1. Purpose
To apply and verify the hardening baseline on a server.

## 2. Prerequisites
- Approved baseline for the OS/platform.
- Configuration scanning tool.
- Change approval for production.

## 3. Step-by-Step Instructions
1. Deploy from the approved hardened image or apply the baseline configuration.
2. Disable unused services, ports and accounts; change default credentials.
3. Enable logging, time sync and EDR.
4. Run the configuration scan against the baseline.
5. Remediate deviations or record approved exceptions.
6. Record the hardened state in the CMDB.

## 4. Verification
- Configuration scan passes the baseline (or deviations are approved).
- EDR and logging active.
- CMDB updated.

## 5. Escalation
If hardening breaks a required function, document, risk-assess and seek an approved exception before exposing the system.

## 6. Related Documents
- Secure Configuration & Hardening Policy (ITS-POL-018)
- System Hardening & Configuration Standard (ITS-STD-001)
