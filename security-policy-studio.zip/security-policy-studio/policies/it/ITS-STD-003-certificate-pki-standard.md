# Certificate & PKI Standard

## 1. Purpose & Scope
To define PKI and certificate profile requirements. Applies to all certificates and certificate authorities used by the Organization.

## 2. Normative Requirements
1. Public-facing certificates **shall** have validity not exceeding the CA/Browser Forum maximum.
2. Keys **shall** meet the minimum sizes in the Encryption Standard.
3. Certificates **shall** be issued only from approved CAs with documented trust chains.
4. Wildcard and long-lived certificates **shall** be minimized and justified.
5. Revocation (CRL/OCSP) **shall** be available and monitored.
6. Internal CA keys **shall** be protected in HSMs with split control.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Certificate profiles & validity | CA/Browser Forum Baseline Requirements |
| Key protection | NIST SP 800-57; FIPS 140-3 |
| Lifecycle & revocation | ISO/IEC 27001:2022 A.8.24 |

## 4. Metrics & Compliance
- Certificates expiring without renewal.
- Percentage of CA keys in HSMs.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- CA/Browser Forum BR
- NIST SP 800-57
- ISO/IEC 27001:2022 A.8.24
