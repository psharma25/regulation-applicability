# MFA Enrollment WI

## 1. Purpose
To enroll strong (phishing-resistant where feasible) authentication for a user or admin.

## 2. Prerequisites
- Verified identity of the enrollee.
- Approved authenticator type per the IAM & MFA Standard.
- Access to the identity platform.

## 3. Step-by-Step Instructions
1. Confirm the enrollee's identity through an approved method.
2. Register the approved authenticator (FIDO2 key, authenticator app, PIV) — prefer phishing-resistant for admins.
3. Test authentication with the new factor.
4. Register a backup factor and record recovery options.
5. For admins, associate the factor with privileged access in the PAM solution.
6. Record completion.

## 4. Verification
- User can authenticate with MFA.
- Backup factor registered.
- Admin MFA bound to privileged access.

## 5. Escalation
If identity cannot be verified or enrollment fails repeatedly, halt and escalate to the IAM team and Security.

## 6. Related Documents
- IAM & MFA Standard (ITS-STD-004)
- Identity & Access Management Policy (ITS-POL-001)
