# Logging, Monitoring & SIEM Policy

## 1. Purpose
To ensure security-relevant events are logged, protected, retained and monitored to enable detection and investigation.

## 2. Scope
Applies to all in-scope systems, applications, network and cloud services.

## 3. Policy Statements
1. Security-relevant events **shall** be logged with sufficient detail (who, what, when, where, outcome).
2. Logs **shall** be forwarded to a central, time-synchronized platform (SIEM) and protected from alteration.
3. Log retention **shall** meet the Logging & Audit Standard and applicable regulation.
4. Detection use cases/alerts **shall** be defined, tuned and monitored.
5. Privileged and authentication events **shall** be logged and reviewed.
6. Clocks **shall** be synchronized to an authoritative time source.
7. Access to logs **shall** be restricted and itself logged.

## 4. Roles & Responsibilities
- **SOC/Monitoring Team** — operates the SIEM and triages alerts.
- **System Owners** — ensure log sources are onboarded.
- **Security** — defines detection use cases.
- **Incident Response** — uses logs for investigation.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.15, A.8.16, A.8.17
- NIST SP 800-92
- NIST SP 800-53 AU family
