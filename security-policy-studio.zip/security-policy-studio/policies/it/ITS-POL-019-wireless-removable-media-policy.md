# Wireless & Removable Media Policy

## 1. Purpose
To control the security risks of wireless networks and removable media.

## 2. Scope
Applies to all Organization wireless networks and use of removable media.

## 3. Policy Statements
1. Corporate wireless **shall** use strong authentication (e.g., 802.1X/WPA3-Enterprise) and encryption.
2. Guest wireless **shall** be isolated from corporate and OT networks.
3. Rogue access points **shall** be detected and removed.
4. Use of removable media **shall** be restricted by default and require business justification.
5. Permitted removable media **shall** be encrypted and malware-scanned on connection.
6. Sensitive data on removable media **shall** be encrypted and tracked; loss **shall** be reported.
7. Auto-run of removable media **shall** be disabled.

## 4. Roles & Responsibilities
- **Network/Endpoint Teams** — enforce wireless and media controls.
- **Security** — sets requirements and monitors.
- **Users** — follow media-handling rules.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.7.10, A.8.1, A.8.20
- NIST SP 800-53 MP-7, AC-18
- NIST SP 800-97 (wireless)
