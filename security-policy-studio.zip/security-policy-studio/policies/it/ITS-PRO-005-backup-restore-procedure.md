# Backup & Restore Procedure

## 1. Purpose
To operate and validate backup and restore.

## 2. Scope
Applies to backup and recovery of critical data and systems.

## 3. Roles (RACI)
| Activity | Backup/IT Ops | System Owner | Security |
| --- | --- | --- | --- |
| Configure backups | R | A | C |
| Monitor jobs | R | I | C |
| Perform restore test | R | A | C |
| Report results | A | C | I |

## 4. Process Steps
1. **Configure** — set backup scope, schedule and immutability to meet RPO. Outputs: backup config.
2. **Monitor** — track job success and remediate failures. Outputs: job status.
3. **Restore test** — perform scheduled restore to validate recoverability and RTO. Outputs: test record.
4. **Report** — record results and feed metrics. Outputs: report.

## 5. Records & Evidence
- Backup configurations, job logs, restore-test records.

## 6. Related Documents & References
- Backup & Recovery Policy (ITS-POL-014)
- Backup & Recovery Standard (ITS-STD-010)
