# System Hardening & Configuration Standard

## 1. Purpose & Scope
To define baseline configuration requirements by platform. Applies to operating systems, databases, containers, network devices and cloud services.

## 2. Normative Requirements
1. Each platform **shall** have a documented baseline derived from a recognized benchmark (e.g., CIS Level 1+).
2. Administrative interfaces **shall** be restricted, authenticated with MFA and not exposed publicly.
3. Only required services and ports **shall** be enabled.
4. Logging and time synchronization **shall** be enabled per the Logging & Audit Standard.
5. Baseline compliance **shall** be scanned at least monthly with deviations remediated or risk-accepted.
6. Images and templates **shall** be patched and re-baselined on a defined cadence.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Hardened baselines | ISO/IEC 27001:2022 A.8.9; CIS Benchmarks |
| Least functionality | NIST SP 800-53 CM-7 |
| Configuration monitoring | NIST SP 800-53 CM-6, SI-7 |

## 4. Metrics & Compliance
- Baseline compliance percentage by platform.
- Mean time to remediate configuration drift.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.8.9
- CIS Benchmarks
- NIST SP 800-53 CM family
