# Certificate Lifecycle Procedure

## 1. Purpose
To request, issue, renew and revoke certificates.

## 2. Scope
Applies to all managed certificates.

## 3. Roles (RACI)
| Activity | Service Owner | PKI Team | Security |
| --- | --- | --- | --- |
| Request certificate | R | A | C |
| Validate & issue | C | A | C |
| Deploy | R | C | I |
| Renew before expiry | A | R | I |
| Revoke if compromised | C | R | A |

## 4. Process Steps
1. **Request** — submit CSR with required attributes to an approved CA. Outputs: request.
2. **Issue** — validate and issue per the Certificate & PKI Standard. Outputs: certificate.
3. **Deploy** — install and verify the certificate and chain. Outputs: deployment confirmation.
4. **Track & renew** — monitor expiry and renew (automate where feasible). Outputs: renewal.
5. **Revoke** — revoke compromised or superseded certificates and replace. Outputs: revocation.

## 5. Records & Evidence
- Certificate inventory, requests, renewals and revocations.

## 6. Related Documents & References
- Certificate Management Policy (ITS-POL-008)
- Certificate & PKI Standard (ITS-STD-003)
