# Firewall Rule Change WI

## 1. Purpose
To request, review and apply a firewall rule change.

## 2. Prerequisites
- Approved change request with business justification.
- Access to firewall management.
- Current rule base export.

## 3. Step-by-Step Instructions
1. Capture the requested flow (source, destination, port, protocol, justification, owner).
2. Review against least-connectivity; reject 'any-any' requests.
3. Risk-assess and obtain change approval.
4. Implement the rule with description and review date.
5. Test the flow and confirm no unintended access.
6. Document the change and update the rule base record.

## 4. Verification
- Requested flow works; no broader access than approved.
- Rule has owner, justification and review date.
- Change record completed.

## 5. Escalation
If the change causes an outage or unexpected exposure, roll back and notify Security and the change manager.

## 6. Related Documents
- Firewall & Perimeter Policy (ITS-POL-004)
- Network Segmentation Standard (ITS-STD-008)
- Change Management Policy (ITS-POL-015)
