# Encryption Standard

## 1. Purpose & Scope
To define minimum cryptographic algorithms, protocols and data-protection requirements. Applies to all encryption of data in transit and at rest across Organization systems.

## 2. Normative Requirements
1. Data in transit **shall** use TLS 1.2 or higher; TLS 1.0/1.1 and SSL are prohibited.
2. Symmetric encryption **shall** use AES-128 or stronger (AES-256 for Restricted).
3. Asymmetric keys **shall** be RSA-3072+ or ECC P-256+; hashing **shall** use SHA-256 or stronger.
4. Data classified Confidential/Restricted **shall** be encrypted at rest.
5. Deprecated algorithms (MD5, SHA-1, DES, 3DES, RC4) **shall not** be used.
6. Cryptographic modules **shall** be FIPS 140-3 validated where required by contract or regulation.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Transit encryption | ISO/IEC 27001:2022 A.8.24; NIST SP 800-52 (TLS) |
| At-rest encryption | NIST SP 800-53 SC-28 |
| Algorithm selection | NIST SP 800-57; FIPS 140-3 |

## 4. Metrics & Compliance
- Percentage of services enforcing TLS 1.2+.
- Findings of deprecated algorithm use.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.8.24
- NIST SP 800-52, 800-57
- FIPS 140-3
