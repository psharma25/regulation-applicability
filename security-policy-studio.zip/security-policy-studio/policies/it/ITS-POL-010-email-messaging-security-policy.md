# Email & Messaging Security Policy

## 1. Purpose
To protect against email- and messaging-borne threats and data exposure.

## 2. Scope
Applies to all Organization email and messaging services.

## 3. Policy Statements
1. Inbound mail **shall** be filtered for spam, malware and phishing; sandboxing of attachments **shall** be used where feasible.
2. Email authentication (**SPF, DKIM, DMARC**) **shall** be enforced for Organization domains.
3. Sensitive information **shall not** be sent through unapproved messaging channels; encryption **shall** be available for sensitive email.
4. External email **shall** be visibly tagged to reduce impersonation risk.
5. Suspected phishing **shall** be reportable with a one-click mechanism and triaged by Security.
6. Auto-forwarding to external domains **shall** be restricted.
7. Messaging platforms **shall** enforce retention and DLP consistent with policy.

## 4. Roles & Responsibilities
- **Messaging/IT Team** — operates filtering and authentication.
- **Security/SOC** — triages reported phishing.
- **Users** — report suspicious messages.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.20, A.8.23
- NIST SP 800-177 (Trustworthy Email)
- DMARC/DKIM/SPF (RFC 7489, 6376, 7208)
