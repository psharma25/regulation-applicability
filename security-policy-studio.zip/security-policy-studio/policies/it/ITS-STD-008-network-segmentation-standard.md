# Network Segmentation Standard

## 1. Purpose & Scope
To define network zoning, trust boundaries and flow control requirements. Applies to all network environments, including OT and cloud.

## 2. Normative Requirements
1. Networks **shall** be divided into trust zones with documented allowed flows (default-deny).
2. OT/ICS environments **shall** be segmented from IT per a defensible architecture (e.g., zones & conduits).
3. Management interfaces **shall** reside on dedicated management networks.
4. East-west traffic in sensitive zones **shall** be controlled and inspected where feasible.
5. Inter-zone flows **shall** be reviewed at least every six months.
6. Remote access **shall** terminate into a controlled zone, not directly into sensitive segments.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Segmentation & flows | ISO/IEC 27001:2022 A.8.20-A.8.22; NIST SP 800-53 SC-7 |
| OT zones & conduits | IEC 62443-3-3; NIST SP 800-82 |

## 4. Metrics & Compliance
- Percentage of zones with documented flow policy.
- Stale inter-zone rules removed per review.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.8.20-A.8.22
- IEC 62443-3-3
- NIST SP 800-82
- NIST SP 800-53 SC-7
