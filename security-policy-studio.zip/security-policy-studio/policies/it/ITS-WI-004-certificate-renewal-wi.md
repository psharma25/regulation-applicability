# Certificate Renewal WI

## 1. Purpose
To renew and deploy an expiring certificate.

## 2. Prerequisites
- Certificate expiry alert.
- Access to the CA and target service.
- Service owner availability.

## 3. Step-by-Step Instructions
1. Identify the expiring certificate and its dependencies.
2. Generate a new CSR meeting the Certificate & PKI Standard.
3. Obtain the certificate from the approved CA.
4. Deploy to the service and verify the full chain.
5. Confirm services operate and old certificate is retired.
6. Update the certificate inventory and expiry tracker.

## 4. Verification
- New certificate served with valid chain.
- No expiry/trust errors.
- Inventory updated.

## 5. Escalation
If renewal cannot complete before expiry, escalate to the service owner and PKI team; plan a maintenance window to avoid outage.

## 6. Related Documents
- Certificate Management Policy (ITS-POL-008)
- Certificate & PKI Standard (ITS-STD-003)
