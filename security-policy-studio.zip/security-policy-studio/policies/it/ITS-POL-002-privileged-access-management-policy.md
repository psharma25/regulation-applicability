# Privileged Access Management Policy

## 1. Purpose
To control administrative and elevated access so privileged actions are minimized, authorized, attributable and monitored.

## 2. Scope
Applies to all privileged accounts and elevated entitlements across systems, applications, infrastructure and cloud.

## 3. Policy Statements
1. Privileged access **shall** be granted only on documented need and approved by the system owner.
2. Privileged accounts **shall** be individually attributable; shared admin accounts are prohibited except vaulted break-glass.
3. Privileged credentials **shall** be vaulted, rotated and retrieved through a privileged-access management (PAM) solution.
4. **Just-in-time** elevation with time limits **shall** be used where technically feasible.
5. Privileged sessions **shall** be logged and, for the most sensitive systems, recorded.
6. Multi-factor authentication **shall** be enforced for all privileged access.
7. Privileged entitlements **shall** be recertified at least quarterly.
8. Break-glass accounts **shall** be sealed, monitored and reviewed after every use.

## 4. Roles & Responsibilities
- **System Owners** — authorize and recertify privileged access.
- **PAM/IAM Team** — operates the vault and elevation workflows.
- **Security** — monitors privileged sessions.
- **Privileged Users** — comply with elevation and logging requirements.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.2, A.8.5, A.8.18
- NIST SP 800-53 AC-2(7), AC-6
- NIST SP 800-171 3.1.5-3.1.7
- CMMC AC.L2
