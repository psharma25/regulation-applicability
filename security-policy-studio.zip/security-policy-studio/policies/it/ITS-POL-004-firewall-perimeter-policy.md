# Firewall & Perimeter Policy

## 1. Purpose
To govern firewall and boundary-protection rule management to enforce least-connectivity.

## 2. Scope
Applies to all firewalls, security groups, ACLs and boundary-protection devices.

## 3. Policy Statements
1. Rule bases **shall** operate on default-deny; only justified, documented flows **shall** be permitted.
2. Each rule **shall** record owner, business justification and review date.
3. Rule changes **shall** be requested, risk-reviewed and approved through change management.
4. Overly permissive ('any-any') rules **shall** be prohibited and remediated.
5. Rule bases **shall** be reviewed at least every six months and stale rules removed.
6. Boundary devices **shall** be hardened, patched and logged centrally.

## 4. Roles & Responsibilities
- **Firewall/Network Team** — implements and reviews rules.
- **Rule Owners** — justify and re-certify their rules.
- **Security** — risk-reviews changes.
- **Change Management** — approves changes.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.20, A.8.21
- NIST SP 800-41
- NIST SP 800-53 SC-7, CM-7
