# Cryptography & Key Management Policy

## 1. Purpose
To ensure cryptography is used appropriately and that keys are managed securely throughout their lifecycle.

## 2. Scope
Applies to all use of cryptography and all cryptographic keys across Organization systems and products.

## 3. Policy Statements
1. Only approved, current algorithms and key lengths **shall** be used (see Encryption Standard); deprecated algorithms are prohibited.
2. Data classified Confidential or Restricted **shall** be encrypted at rest and in transit.
3. Keys **shall** be generated, stored, distributed, rotated, archived and destroyed under documented procedures.
4. Private and secret keys **shall** be protected in hardware security modules or equivalent where feasible.
5. Key access **shall** follow least privilege with separation of duties for key-management functions.
6. Compromised keys **shall** be revoked and replaced under the incident process.
7. Cryptographic agility **shall** be considered, including readiness for post-quantum migration.

## 4. Roles & Responsibilities
- **Cryptography/Key Custodians** — manage the key lifecycle.
- **Security Architecture** — approves algorithms and standards.
- **System Owners** — apply approved cryptography.
- **Security** — assures compliance.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.8.24
- NIST SP 800-57 (key management)
- NIST SP 800-53 SC-12, SC-13
- FIPS 140-3
