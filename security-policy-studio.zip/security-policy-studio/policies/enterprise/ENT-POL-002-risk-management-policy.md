# Risk Management Policy

## 1. Purpose
To define how the Organization identifies, analyzes, evaluates, treats, monitors and accepts information-security risk, satisfying **ISO/IEC 27001:2022 Cl. 6.1 and 8.2-8.3** and aligning to ISO 31000 and the NIST CSF (GOVERN/IDENTIFY) functions.

## 2. Scope
Applies to risks affecting the confidentiality, integrity and availability of information assets within the ISMS scope, including risks introduced by suppliers, projects, change and new technologies such as AI.

## 3. Policy Statements
1. A documented risk-assessment methodology with defined likelihood and impact scales **shall** be maintained and applied consistently.
2. Risk assessments **shall** be performed at least annually and upon significant change, new systems, or major incidents.
3. Each risk **shall** have a named **risk owner** accountable for treatment decisions.
4. Risks **shall** be evaluated against the Organization's documented **risk acceptance criteria** (risk appetite) approved by top management.
5. One of four treatment options **shall** be selected for every risk above tolerance: modify (control), avoid, share/transfer, or retain.
6. A **risk treatment plan** and a **Statement of Applicability** (Cl. 6.1.3) **shall** be maintained and approved.
7. Residual risk **shall** be formally accepted in writing by the risk owner; risks exceeding appetite require executive acceptance.
8. The risk register **shall** be reviewed by management at planned intervals and reported to leadership.

## 4. Roles & Responsibilities
- **Risk Owners** — accept residual risk and own treatment in their area.
- **Risk & Compliance** — maintains the methodology, register and reporting.
- **CISO** — assures the process and escalates risks beyond appetite.
- **Top Management** — sets risk appetite and accepts enterprise-level risk.

## 5. Compliance & Enforcement
Adherence is verified via internal audit and management review. Unmanaged risks identified outside the process are treated as nonconformities.

## 6. Exceptions
Deviations from the methodology **shall** be approved by the CISO and recorded with justification and expiry.

## 7. Review & Maintenance
Reviewed at least annually and after major incidents or organizational change.

## 8. References
ISO/IEC 27001:2022 Cl. 6.1, 8.2, 8.3; ISO 31000:2018; ISO/IEC 27005; NIST SP 800-30; NIST CSF 2.0. Where applicable, product safety risk per ISO 14971 is integrated with security risk for medical devices.
