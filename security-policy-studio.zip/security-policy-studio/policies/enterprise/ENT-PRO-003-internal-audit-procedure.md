# Internal Audit Procedure

## 1. Purpose
To conduct internal audits of the ISMS and QMS against defined criteria.

## 2. Scope
Applies to all internal management-system audits.

## 3. Roles (RACI)
| Activity | Programme Mgr | Lead Auditor | Auditee | Management |
| --- | --- | --- | --- | --- |
| Plan programme | A | C | I | C |
| Prepare audit | C | A | I | I |
| Conduct audit | I | A | R | I |
| Report findings | C | A | C | I |
| Remediate & verify | I | C | A | C |

## 4. Process Steps
1. **Plan** — schedule audits by risk and importance; assign independent auditors. Outputs: audit programme.
2. **Prepare** — define criteria, scope and checklist; notify auditee. Outputs: audit plan.
3. **Conduct** — gather objective evidence via interview, observation and sampling. Outputs: evidence notes.
4. **Report** — document conformities and nonconformities with classification. Outputs: audit report.
5. **Follow up** — agree corrective actions, verify effectiveness and close. Outputs: closed findings.

## 5. Records & Evidence
- Audit programme, plans, reports, nonconformities and closures.

## 6. Related Documents & References
- ISO/IEC 27001:2022 Cl. 9.2
- ISO 13485:2016 Cl. 8.2.4
- ISO 19011
- Internal Audit Policy (ENT-POL-019)
