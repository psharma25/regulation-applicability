# Data Retention & Disposal Policy

## 1. Purpose
To define how long records and data are retained and how they are securely disposed of, balancing operational, legal and regulatory obligations.

## 2. Scope
Applies to all information and quality records across all repositories and formats, within both the ISMS and the QMS.

## 3. Policy Statements
1. Records **shall** be retained for the periods defined in the Data Retention Schedule Standard and no longer than necessary.
2. Quality records required by ISO 13485 and applicable device regulation **shall** be retained for at least the lifetime of the device or the regulatory minimum, whichever is longer.
3. Legal holds **shall** suspend disposal of affected records until released by Legal.
4. Disposal **shall** render information unrecoverable using methods appropriate to the media and classification.
5. Disposal of Confidential and Restricted information **shall** be evidenced by a certificate or destruction log.
6. Personal data **shall** be deleted or anonymized at end of its retention period unless a lawful basis to retain remains.
7. Retention and disposal **shall** be applied consistently across backups and archives.

## 4. Roles & Responsibilities
- **Records / Information Owners** — apply retention and authorize disposal.
- **Legal** — issues and releases legal holds.
- **IT / Security** — execute secure disposal and maintain logs.
- **Quality** — assures retention of QMS records.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.33, A.8.10
- ISO 13485:2016 Cl. 4.2.5
- 21 CFR 820 / FDA QMSR
- NIST SP 800-88 (media sanitization)
