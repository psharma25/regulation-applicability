# Incident Response Procedure

## 1. Purpose
To provide a repeatable workflow for detecting, triaging, containing, eradicating, recovering from and learning from security incidents.

## 2. Scope
Applies to all suspected and confirmed information-security incidents within the ISMS scope.

## 3. Roles (RACI)
| Activity | Incident Mgr | SecOps | CISO | Legal/Privacy | Comms |
| --- | --- | --- | --- | --- | --- |
| Detect & report | A | R | I | I | I |
| Triage & classify | A | R | C | I | I |
| Declare major incident | R | C | A | C | I |
| Contain & eradicate | A | R | C | I | I |
| Assess reportability | C | C | A | R | I |
| Communicate | C | I | C | C | A |
| Recover & verify | A | R | C | I | I |
| Post-incident review | R | C | A | C | C |

## 4. Process Steps
1. **Detect & report** — capture events from monitoring and user reports into the incident queue. Outputs: incident ticket.
2. **Triage & classify** — validate, assign severity and engage the on-call structure. Outputs: severity, owner.
3. **Contain** — isolate affected systems while preserving evidence. Outputs: containment actions log.
4. **Eradicate** — remove root cause (malware, credentials, vulnerability). Outputs: eradication record.
5. **Assess obligations** — Legal/Privacy determine breach and regulatory notification needs. Outputs: notification decision.
6. **Recover** — restore services from trusted state and verify integrity. Outputs: recovery confirmation.
7. **Review** — conduct post-incident review and raise CAPA. Outputs: lessons learned, actions.

## 5. Records & Evidence
- Incident tickets, timelines, evidence, notifications, post-incident reports.

## 6. Related Documents & References
- ISO/IEC 27001:2022 A.5.24-A.5.28
- NIST SP 800-61
- Security Incident Management Policy (ENT-POL-015)
