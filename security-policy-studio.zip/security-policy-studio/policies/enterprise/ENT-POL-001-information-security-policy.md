# Information Security Policy

## 1. Purpose
This Policy establishes the Organization's commitment to protecting the confidentiality, integrity and availability of information and information systems, and defines the apex requirements of the Information Security Management System (ISMS) maintained in conformance with **ISO/IEC 27001:2022**.

## 2. Scope
This Policy applies to all employees, contractors, temporary staff and third parties who access Organization information or systems, and to all information assets regardless of format, location or ownership. It governs every other document within the ISMS; subordinate policies, standards, procedures and work instructions shall align with it.

## 3. Policy Statements
1. The Organization **shall** establish, implement, maintain and continually improve an ISMS aligned to ISO/IEC 27001:2022, including the Statement of Applicability (Cl. 6.1.3).
2. Top management **shall** demonstrate leadership and commitment (Cl. 5.1), approve this Policy, and ensure resources are available for the ISMS.
3. Information security objectives **shall** be established, measurable, monitored and reviewed at planned intervals (Cl. 6.2).
4. Information **shall** be classified and handled according to the Data Classification & Handling Policy.
5. Access to information **shall** be granted on a least-privilege, need-to-know basis (A.5.15).
6. Risks to information **shall** be assessed and treated through the Risk Management Policy; residual risk **shall** be formally accepted by an accountable owner.
7. All personnel **shall** complete security awareness training appropriate to their role (A.6.3) and **shall** report suspected incidents without delay.
8. Security requirements **shall** be embedded into projects, changes, supplier relationships and the development lifecycle.
9. The Organization **shall** comply with all applicable legal, regulatory and contractual obligations (A.5.31).
10. Breaches of this Policy **shall** be subject to the disciplinary process.

## 4. Roles & Responsibilities
- **Top Management** — owns the ISMS, approves policy and risk appetite, conducts management review.
- **Chief Information Security Officer (CISO)** — accountable for design, operation and continual improvement of the ISMS.
- **Information / Asset Owners** — accountable for classification, risk and control of assets in their remit.
- **All Users** — responsible for complying with this Policy and reporting incidents.

## 5. Compliance & Enforcement
Compliance is monitored through internal audit, management review and control metrics. Non-compliance may result in removal of access and disciplinary action up to termination, and for third parties, contractual remedies.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the CISO. A register of active exceptions **shall** be maintained.

## 7. Review & Maintenance
This Policy **shall** be reviewed at least annually and upon significant change to the business, technology or threat landscape, and re-approved by top management.

## 8. References
ISO/IEC 27001:2022 Cl. 4-10 and Annex A; ISO/IEC 27002:2022; NIST CSF 2.0 (GOVERN). For regulated product environments, this Policy operates alongside the Quality Management System (ISO 13485 / FDA QMSR).
