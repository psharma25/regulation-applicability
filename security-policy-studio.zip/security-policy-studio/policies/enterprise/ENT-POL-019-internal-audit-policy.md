# Internal Audit Policy

## 1. Purpose
To verify, through planned internal audits, that the management systems conform to requirements and are effectively implemented and maintained.

## 2. Scope
Applies to internal audits of the ISMS (ISO 27001) and QMS (ISO 13485).

## 3. Policy Statements
1. An **audit programme shall** be planned on the basis of process importance and prior results.
2. Auditors **shall** be competent and **shall not** audit their own work (independence).
3. Audit criteria, scope and method **shall** be defined for each audit.
4. Findings **shall** be recorded with objective evidence and classified by significance.
5. Nonconformities **shall** be addressed through correction and corrective action within agreed timeframes.
6. Audit results **shall** be reported to relevant management and feed management review.
7. Records of the programme and results **shall** be retained.

## 4. Roles & Responsibilities
- **Audit Programme Manager** — plans and coordinates audits.
- **Internal Auditors** — conduct audits independently.
- **Auditees / Process Owners** — provide evidence and remediate.
- **Management** — acts on results.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 Cl. 9.2
- ISO 13485:2016 Cl. 8.2.4
- ISO 19011 (auditing guidance)
