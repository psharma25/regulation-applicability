# Management Review Procedure

## 1. Purpose
To plan and conduct management review of the management systems and capture decisions and actions.

## 2. Scope
Applies to periodic management review of the ISMS and QMS.

## 3. Roles (RACI)
| Activity | MS Owner | CISO/Quality | Top Mgmt | Process Owners |
| --- | --- | --- | --- | --- |
| Compile inputs | A | R | I | C |
| Hold review | C | C | A | C |
| Record decisions | A | R | C | I |
| Track actions | A | R | I | C |

## 4. Process Steps
1. **Compile inputs** — gather audit results, risk status, metrics, incidents, supplier and regulatory changes, prior actions. Outputs: review pack.
2. **Conduct review** — top management evaluates suitability, adequacy and effectiveness. Outputs: meeting minutes.
3. **Decide** — record decisions on improvement, resources and changes to policy/objectives. Outputs: decisions list.
4. **Track** — assign and follow actions to closure. Outputs: action tracker.

## 5. Records & Evidence
- Management-review inputs, minutes, decisions and action tracker.

## 6. Related Documents & References
- ISO/IEC 27001:2022 Cl. 9.3
- ISO 13485:2016 Cl. 5.6
- Internal Audit Policy (ENT-POL-019)
