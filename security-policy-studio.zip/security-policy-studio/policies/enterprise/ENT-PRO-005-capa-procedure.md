# CAPA Procedure

## 1. Purpose
To raise, investigate, implement and close corrective and preventive actions (CAPA).

## 2. Scope
Applies to CAPAs arising from nonconformities, audits, complaints and risk within the QMS.

## 3. Roles (RACI)
| Activity | CAPA Owner | Quality | Investigator | Management |
| --- | --- | --- | --- | --- |
| Raise & assess | R | A | C | I |
| Investigate root cause | A | C | R | I |
| Implement actions | A | C | R | I |
| Verify effectiveness | C | A | R | I |
| Close & review | C | A | I | C |

## 4. Process Steps
1. **Raise** — document the problem, source and immediate correction; assess CAPA need by risk. Outputs: CAPA record.
2. **Investigate** — determine root cause using a structured method (e.g., 5-Whys, fishbone). Outputs: root-cause analysis.
3. **Plan & implement** — define corrective/preventive actions with owners and dates. Outputs: action plan.
4. **Verify** — confirm actions are effective and recurrence is prevented. Outputs: effectiveness check.
5. **Close** — review and close; feed results into management review. Outputs: closed CAPA.

## 5. Records & Evidence
- CAPA records, investigations, action plans and effectiveness checks.

## 6. Related Documents & References
- ISO 13485:2016 Cl. 8.5.2-8.5.3
- 21 CFR 820.100 / FDA QMSR
- Nonconformity & CAPA Policy (ENT-POL-018)
