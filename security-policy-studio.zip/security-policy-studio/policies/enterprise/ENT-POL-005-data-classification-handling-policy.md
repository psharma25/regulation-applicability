# Data Classification & Handling Policy

## 1. Purpose
To ensure information receives protection commensurate with its sensitivity throughout its lifecycle, per **ISO/IEC 27001:2022 A.5.12-A.5.14 and A.8.10-A.8.12**.

## 2. Scope
Applies to all information created, received, stored, processed or transmitted by the Organization, in any format.

## 3. Policy Statements
1. All information **shall** be assigned one of four classifications by its owner: **Public, Internal, Confidential, Restricted**.
2. Information **shall** be **labelled** according to its classification where technically feasible.
3. Handling rules for storage, transmission, sharing, printing and disposal **shall** follow the matrix below.
4. **Restricted** and **Confidential** data **shall** be encrypted in transit and at rest.
5. Reclassification and declassification **shall** be performed only by the information owner.
6. Personal and regulated data **shall** additionally follow the Data Protection & Privacy Policy.
7. Disposal **shall** render information unrecoverable per the Data Retention & Disposal Policy.

### Handling Matrix

| Classification | Storage | Transmission | Sharing | Disposal |
|---|---|---|---|---|
| Public | Any approved location | No restriction | Freely | Standard |
| Internal | Org-managed systems | Within Org / approved channels | Internal need-to-know | Standard deletion |
| Confidential | Encrypted, access-controlled | Encrypted channels only | Owner-approved, NDA | Secure wipe / shred |
| Restricted | Encrypted, segregated, logged | Encrypted + MFA | Named-individual approval | Certified destruction |

## 4. Roles & Responsibilities
- **Information Owners** — classify, label and authorize handling.
- **All Users** — apply handling rules to data they touch.
- **IT / Security** — provide and enforce technical controls.

## 5. Compliance & Enforcement
Verified through DLP, access reviews and audit. Mishandling of Confidential/Restricted data is a reportable incident.

## 6. Exceptions
Approved by the information owner and CISO; documented with expiry.

## 7. Review & Maintenance
Reviewed at least annually.

## 8. References
ISO/IEC 27001:2022 A.5.12-A.5.14, A.8.10-A.8.12; NIST SP 800-60; GDPR Art. 5, 32 (where applicable).
