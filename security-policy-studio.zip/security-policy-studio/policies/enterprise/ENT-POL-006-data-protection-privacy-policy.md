# Data Protection & Privacy Policy

## 1. Purpose
To ensure personal and otherwise regulated data is processed lawfully, fairly, transparently and securely throughout its lifecycle.

## 2. Scope
Applies to all processing of personal data and regulated data by the Organization and its processors, in any format.

## 3. Policy Statements
1. Personal data **shall** be processed only on a documented lawful basis and for specified, legitimate purposes (purpose limitation).
2. Only the minimum personal data necessary **shall** be collected and retained (data minimization and storage limitation).
3. Data subjects' rights (access, rectification, erasure, portability, objection) **shall** be honored within statutory timeframes.
4. Privacy-by-design and by-default **shall** be applied to new systems and changes; a **Data Protection Impact Assessment shall** be performed for high-risk processing.
5. Personal data **shall** be protected with encryption, access control and the controls defined in the ISMS.
6. Processors and sub-processors **shall** be bound by a data-processing agreement and assessed for adequacy.
7. International transfers **shall** rely on an approved transfer mechanism.
8. Personal-data breaches **shall** be assessed and notified to authorities and data subjects within applicable deadlines.

## 4. Roles & Responsibilities
- **Data Protection Officer / Privacy Lead** — oversees compliance and advises the business.
- **Data / Process Owners** — maintain lawful basis and records of processing.
- **Security** — implements technical and organizational measures.
- **Legal** — assesses obligations and transfer mechanisms.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.34, A.8.11 (de-identification)
- ISO/IEC 27701
- GDPR Art. 5, 6, 25, 32, 33-34 (where applicable)
- NIST Privacy Framework
