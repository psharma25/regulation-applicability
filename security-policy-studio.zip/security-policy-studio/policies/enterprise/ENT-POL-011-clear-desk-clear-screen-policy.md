# Clear Desk & Clear Screen Policy

## 1. Purpose
To prevent unauthorized access to, and loss of, information left exposed on desks, screens and shared spaces.

## 2. Scope
Applies to all personnel and all work locations, including remote and shared environments.

## 3. Policy Statements
1. Confidential and Restricted information **shall not** be left unattended on desks, printers or screens.
2. Sessions **shall** lock automatically after a defined idle period and on leaving a workstation.
3. Printing of sensitive information **shall** use secure/pull printing where available and be collected promptly.
4. Whiteboards and notes containing sensitive information **shall** be cleared after use.
5. Removable media and documents **shall** be stored in locked storage when not in use.
6. Sensitive information **shall not** be displayed where it can be observed by unauthorized persons.

## 4. Roles & Responsibilities
- **All Users** — apply clear-desk and clear-screen practices.
- **Line Managers** — reinforce compliance.
- **Security** — defines screen-lock and printing standards.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.7.7, A.8.1
- NIST SP 800-53 AC-11, MP family
