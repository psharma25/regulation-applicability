# Nonconformity & CAPA Policy

## 1. Purpose
To ensure nonconformities are controlled and that corrective and preventive actions (CAPA) address root causes and prevent recurrence.

## 2. Scope
Applies to nonconformities affecting the quality management system, products and processes.

## 3. Policy Statements
1. Nonconforming product and process outputs **shall** be identified, documented and controlled to prevent unintended use.
2. Each nonconformity **shall** be evaluated for disposition (correction, concession, rework, scrap) and recorded.
3. A **CAPA shall** be initiated where warranted by risk, recurrence or regulatory impact.
4. Root-cause analysis **shall** be performed and corrective actions verified for effectiveness.
5. Preventive actions **shall** address potential nonconformities proportionate to risk.
6. CAPA records **shall** be maintained and reviewed in management review.
7. Regulatory reporting obligations arising from nonconformities **shall** be assessed and met.

## 4. Roles & Responsibilities
- **Quality** — owns the nonconformity and CAPA process.
- **Process / Product Owners** — investigate and implement actions.
- **Management** — reviews CAPA status and effectiveness.
- **Regulatory** — assesses reportability.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO 13485:2016 Cl. 8.3, 8.5.2, 8.5.3
- 21 CFR 820.90, 820.100 / FDA QMSR
- ISO/IEC 27001:2022 Cl. 10.1 (nonconformity & corrective action)
