# Acceptable Use Policy

## 1. Purpose
To define the acceptable and prohibited use of the Organization's information, systems, devices and network services, protecting their confidentiality, integrity and availability.

## 2. Scope
Applies to all employees, contractors and third parties using Organization information assets or services, on any device, in any location.

## 3. Policy Statements
1. Information and systems **shall** be used only for authorized business purposes; limited, reasonable incidental personal use is permitted provided it does not impair security, performance or compliance.
2. Users **shall not** attempt to bypass, disable or weaken any security control.
3. Users **shall** protect authentication credentials, **shall not** share them, and **shall** lock unattended sessions.
4. Only approved, licensed software and services **shall** be installed or used; unsanctioned ('shadow IT') services **shall not** process Organization data.
5. Users **shall** handle information according to its classification and **shall not** transmit Confidential or Restricted data through unapproved channels.
6. Users **shall not** create, store or transmit unlawful, harassing or infringing material using Organization assets.
7. Users **shall** report suspected security incidents, lost devices and phishing without delay.
8. Users acknowledge that use of Organization systems may be monitored and logged for security and compliance purposes, subject to applicable law.

## 4. Roles & Responsibilities
- **All Users** — comply with this Policy and report violations.
- **Line Managers** — reinforce acceptable use and address breaches.
- **IT / Security** — provide approved tools and monitor for misuse.
- **Human Resources** — administer the disciplinary process.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.10, A.6.2, A.8.1
- ISO/IEC 27002:2022
- NIST SP 800-53 AC-8, PL-4
