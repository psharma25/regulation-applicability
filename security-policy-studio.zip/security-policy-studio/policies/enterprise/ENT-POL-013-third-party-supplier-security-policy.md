# Third-Party & Supplier Security Policy

## 1. Purpose
To manage information-security risk across the supplier and third-party lifecycle, from selection through termination.

## 2. Scope
Applies to all suppliers, vendors, service providers and partners that access, process, store or could affect Organization information or systems.

## 3. Policy Statements
1. Suppliers **shall** be risk-tiered; due-diligence depth **shall** scale with tier and data sensitivity.
2. Security and, where applicable, data-processing requirements **shall** be defined in contracts before access is granted.
3. Suppliers handling Confidential or Restricted data **shall** evidence appropriate controls (e.g., ISO 27001 certification or SOC 2 report).
4. Supplier access **shall** follow least privilege and be removed promptly when no longer required.
5. Higher-risk suppliers **shall** be reassessed at least annually and on material change.
6. Subcontracting (the supply chain) **shall** be disclosed and flow down equivalent obligations.
7. Supplier security incidents **shall** be reported to the Organization within contractually defined timeframes.
8. Offboarding **shall** ensure return or destruction of data and revocation of access.

## 4. Roles & Responsibilities
- **Business Sponsors** — own the relationship and risk acceptance.
- **Procurement** — embeds security terms in contracts.
- **Security / TPRM** — performs due diligence and reassessment.
- **Legal** — negotiates security and data-processing terms.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.19-A.5.23
- NIST SP 800-161 (C-SCRM)
- NIST SP 800-53 SR family
- SOC 2 / ISO 27001 evidence
