# Records Management Standard

## 1. Purpose & Scope
To define requirements for the format, storage, integrity and retrieval of records. Applies to all controlled records across the ISMS and QMS.

## 2. Normative Requirements
1. Records **shall** be legible, identifiable and traceable to the activity they evidence.
2. Electronic records **shall** be protected against unauthorized alteration; integrity controls (e.g., access control, audit trails) **shall** apply.
3. Where electronic signatures are used for regulated records, they **shall** meet applicable requirements (e.g., 21 CFR Part 11).
4. Records **shall** be retrievable within defined timeframes for audit and regulatory request.
5. Backups of records **shall** be maintained and recoverability tested.
6. Retention and disposal **shall** follow the Data Retention Schedule Standard.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Record integrity & control | ISO 13485 Cl. 4.2.5; ISO/IEC 27001:2022 A.5.33 |
| Electronic records & signatures | 21 CFR Part 11 (where applicable) |
| Retrieval & backup | ISO/IEC 27001:2022 A.8.13, A.8.14 |

## 4. Metrics & Compliance
- Record retrieval time during audits.
- Backup restore-test success rate for records.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO 13485:2016 Cl. 4.2.5
- 21 CFR Part 11
- ISO/IEC 27001:2022 A.5.33, A.8.13-A.8.14
