# Access Control Policy

## 1. Purpose
To ensure access to information and systems is authorized, least-privilege and accountable, in line with **ISO/IEC 27001:2022 A.5.15-A.5.18 and A.8.2-A.8.5**.

## 2. Scope
Applies to all user, administrative, service and third-party accounts across all systems, applications and data within the ISMS scope.

## 3. Policy Statements
1. Access **shall** be granted on the principles of **least privilege** and **need-to-know**, based on defined roles.
2. Every account **shall** be uniquely attributable to an individual or a registered service; shared interactive accounts are prohibited.
3. Access **shall** be authorized by the relevant **system or data owner** before provisioning.
4. **Multi-factor authentication shall** be enforced for remote access, privileged access and access to sensitive data.
5. **Privileged access shall** be minimized, time-bound where practical, individually attributable, and logged.
6. Access rights **shall** be modified on role change and **revoked promptly on termination** (same business day).
7. Access **shall** be **recertified** by owners at least every six months (privileged: quarterly).
8. Authentication credentials **shall** meet the Password & Authentication Standard.
9. Segregation of duties **shall** be enforced for sensitive functions; conflicts require compensating controls.

## 4. Roles & Responsibilities
- **System / Data Owners** — authorize and recertify access.
- **IAM / IT Operations** — provision, modify and revoke per authorized requests.
- **Managers** — initiate joiner/mover/leaver changes.
- **Security** — monitors privileged use and recertification compliance.

## 5. Compliance & Enforcement
Verified through access reviews, log monitoring and audit. Unauthorized or orphaned access is a reportable nonconformity.

## 6. Exceptions
Standing exceptions (e.g., emergency break-glass) **shall** be documented, monitored and approved by the CISO.

## 7. Review & Maintenance
Reviewed at least annually.

## 8. References
ISO/IEC 27001:2022 A.5.15-A.5.18, A.8.2-A.8.5; NIST SP 800-53 AC family; NIST SP 800-171 3.1.x; CMMC AC practices.
