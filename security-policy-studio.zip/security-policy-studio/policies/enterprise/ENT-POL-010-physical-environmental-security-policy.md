# Physical & Environmental Security Policy

## 1. Purpose
To protect facilities, equipment and information from physical and environmental threats and unauthorized physical access.

## 2. Scope
Applies to all Organization premises, secure areas, equipment and supporting utilities.

## 3. Policy Statements
1. Secure areas **shall** be defined and protected by physical entry controls; access **shall** be authorized, logged and reviewed.
2. Visitors **shall** be registered, escorted in secure areas and identifiable.
3. Equipment **shall** be sited and protected against environmental threats and power/utility failure.
4. Cabling carrying data or power **shall** be protected from interception and damage.
5. Equipment maintenance and off-site use **shall** be authorized and controlled.
6. Media and equipment leaving the premises **shall** be authorized; storage media **shall** be sanitized before disposal or reuse.
7. Delivery and loading areas **shall** be controlled and isolated from information-processing areas.

## 4. Roles & Responsibilities
- **Facilities / Physical Security** — operates physical controls.
- **Asset Owners** — protect equipment in their remit.
- **Security** — sets requirements and reviews access.
- **All Users** — comply with physical-security rules.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.7.1-A.7.14
- NIST SP 800-53 PE family
- IEC 62443 (OT physical zones, where applicable)
