# Document & Records Control Policy

## 1. Purpose
To control documented information and quality records so that approved, current versions are available and integrity is preserved.

## 2. Scope
Applies to all controlled documents and records within the ISMS and QMS.

## 3. Policy Statements
1. Documents **shall** be approved for adequacy before issue and uniquely identified with version and status.
2. Changes **shall** be reviewed and re-approved; revision history **shall** be maintained.
3. Current versions **shall** be available at points of use; obsolete versions **shall** be withdrawn or marked.
4. Documents of external origin **shall** be identified and their distribution controlled.
5. Records **shall** be legible, retrievable, protected from alteration and retained per the retention schedule.
6. Access to documents and records **shall** follow least privilege.
7. Deterioration, loss and unauthorized change of records **shall** be prevented.

## 4. Roles & Responsibilities
- **Document Control / Quality** — administers the document system.
- **Document Owners** — author, review and maintain content.
- **Approvers** — authorize issue and changes.
- **All Users** — use only controlled, current versions.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 Cl. 7.5, A.5.33
- ISO 13485:2016 Cl. 4.2.4-4.2.5
- 21 CFR 820 / FDA QMSR (document & record controls)
