# Compliance & Legal Policy

## 1. Purpose
To identify, track and comply with legal, statutory, regulatory and contractual obligations relevant to information security and the quality system.

## 2. Scope
Applies to all Organization activities, information assets and management systems (ISMS and QMS).

## 3. Policy Statements
1. Applicable legal, regulatory and contractual requirements **shall** be identified, documented and kept current in a compliance register.
2. Controls **shall** be mapped to obligations to demonstrate compliance.
3. Intellectual-property rights and licensing terms **shall** be respected.
4. Records **shall** be protected and retained to meet legal and regulatory requirements.
5. Privacy and protection of personal data **shall** comply with applicable law.
6. Compliance **shall** be reviewed independently at planned intervals.
7. Significant compliance gaps **shall** be escalated and remediated through corrective action.

## 4. Roles & Responsibilities
- **Legal / Compliance** — maintains the obligations register.
- **Management-System Owners** — implement controls to meet obligations.
- **Internal Audit** — independently verifies compliance.
- **Executive Management** — accountable for the compliance posture.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.31-A.5.36
- ISO 13485:2016 Cl. 4.1, 8.2
- 21 CFR 820 / FDA QMSR
- Applicable privacy and sector regulation
