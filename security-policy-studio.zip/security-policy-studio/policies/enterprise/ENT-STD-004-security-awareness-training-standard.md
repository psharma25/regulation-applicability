# Security Awareness & Training Standard

## 1. Purpose & Scope
To define the minimum curriculum, cadence and assurance for security awareness and training. Applies to all personnel and, where contractually required, third parties.

## 2. Normative Requirements
1. All personnel **shall** complete baseline security awareness on joining and at least annually.
2. Simulated phishing **shall** be conducted at least quarterly with remedial training for repeat clickers.
3. Role-based training **shall** be provided for privileged users, developers, PSIRT and auditors.
4. Completion **shall** be tracked; non-completion **shall** be escalated to management.
5. Content **shall** be refreshed to reflect current threats and lessons learned.
6. Awareness effectiveness **shall** be measured (e.g., phishing failure rate, assessment scores).

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Awareness programme | ISO/IEC 27001:2022 A.6.3; ISO 13485 Cl. 6.2 |
| Role-based competence | ISO/IEC 27001:2022 Cl. 7.2 |
| Phishing simulation | NIST SP 800-50; NIST SP 800-53 AT family |

## 4. Metrics & Compliance
- Training completion rate.
- Phishing simulation failure rate trend.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.6.3, Cl. 7.2-7.3
- NIST SP 800-50 / 800-16
- ISO 13485:2016 Cl. 6.2
