# Asset Management Policy

## 1. Purpose
To ensure information assets are identified, inventoried, owned and managed securely throughout their lifecycle.

## 2. Scope
Applies to all information assets — hardware, software, data, services and supporting facilities — within the ISMS scope.

## 3. Policy Statements
1. A complete, accurate **asset inventory shall** be maintained and reconciled at least quarterly.
2. Every asset **shall** have a designated **owner** accountable for its protection and classification.
3. Assets **shall** be classified and handled per the Data Classification & Handling Policy.
4. Acceptable use of assets **shall** follow the Acceptable Use Policy.
5. Assets **shall** be tracked through acquisition, deployment, maintenance and secure decommissioning.
6. Media and equipment **shall** be sanitized before reuse or disposal (NIST SP 800-88).
7. Assets removed from premises **shall** be authorized and protected.

## 4. Roles & Responsibilities
- **Asset Owners** — accountable for assigned assets.
- **IT Asset Management** — maintains the inventory and lifecycle.
- **Security** — assures classification and protection.
- **All Users** — protect assets in their custody.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.9-A.5.11, A.7.10, A.7.14, A.8.1
- NIST SP 800-88
- CIS Controls v8 1 & 2
