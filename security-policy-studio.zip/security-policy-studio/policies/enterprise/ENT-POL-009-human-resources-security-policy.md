# Human Resources Security Policy

## 1. Purpose
To reduce information-security risk arising from personnel before, during and after employment.

## 2. Scope
Applies to all employees and contractors throughout the employment lifecycle.

## 3. Policy Statements
1. Background verification **shall** be performed prior to employment proportionate to role sensitivity and applicable law.
2. Terms of employment **shall** include information-security responsibilities and confidentiality obligations.
3. Personnel **shall** complete security awareness training on joining and at defined intervals.
4. A disciplinary process **shall** address information-security breaches.
5. Access and assets **shall** be revoked or returned upon termination or role change, completed promptly.
6. Confidentiality obligations **shall** continue after termination as defined contractually.

## 4. Roles & Responsibilities
- **Human Resources** — performs screening, terms and offboarding.
- **Line Managers** — initiate joiner/mover/leaver actions.
- **Security** — defines awareness and access requirements.
- **IT** — provisions and revokes access and assets.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.6.1-A.6.6
- NIST SP 800-53 PS family
- NIST SP 800-171 3.9.x
