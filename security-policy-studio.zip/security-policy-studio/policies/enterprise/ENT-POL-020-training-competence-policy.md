# Training & Competence Policy

## 1. Purpose
To ensure personnel are competent and aware of their information-security and quality responsibilities.

## 2. Scope
Applies to all personnel whose work affects information security or product quality.

## 3. Policy Statements
1. Competence requirements **shall** be defined for security- and quality-relevant roles.
2. Personnel **shall** be provided training or other actions to achieve required competence; effectiveness **shall** be evaluated.
3. All personnel **shall** complete security awareness on joining and at defined intervals.
4. Role-specific training (e.g., secure development, PSIRT, auditing) **shall** be provided where applicable.
5. Records of competence, training and awareness **shall** be retained.
6. Awareness content **shall** be updated to reflect current threats and lessons learned.

## 4. Roles & Responsibilities
- **Human Resources / L&D** — administers training and records.
- **Managers** — identify competence needs.
- **Security / Quality** — define curricula and assess effectiveness.
- **All Personnel** — complete required training.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 Cl. 7.2, 7.3, A.6.3
- ISO 13485:2016 Cl. 6.2
- NIST SP 800-50 / 800-16
