# AI Governance & Acceptable Use Policy

## 1. Purpose
To govern the responsible, secure and compliant adoption and use of artificial-intelligence systems, including generative AI.

## 2. Scope
Applies to all use, development, procurement and integration of AI/ML systems and AI-enabled services within the Organization.

## 3. Policy Statements
1. AI use cases **shall** be inventoried and risk-assessed before deployment, considering safety, security, privacy, bias and legal impact.
2. Confidential, Restricted or personal data **shall not** be entered into unapproved or public AI services.
3. AI systems **shall** have a designated owner accountable for their behavior, monitoring and compliance.
4. Human oversight **shall** be maintained for decisions with significant impact; fully automated high-impact decisions are prohibited without approved safeguards.
5. AI outputs **shall** be validated before reliance; AI-generated content used externally **shall** be reviewed.
6. Third-party AI providers **shall** be assessed for security, data handling and model governance.
7. AI systems **shall** comply with applicable regulation (e.g., EU AI Act risk obligations) and the AI management system where adopted.
8. Prohibited and high-risk AI practices **shall** be defined and enforced.

## 4. Roles & Responsibilities
- **AI Governance Owner / Committee** — sets policy and approves high-risk uses.
- **Use-Case / System Owners** — accountable for specific AI systems.
- **Security & Privacy** — assess and monitor AI risk.
- **All Users** — use AI within approved guardrails.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 42001:2023
- NIST AI RMF 1.0
- EU AI Act (risk-based obligations)
- ISO/IEC 27001:2022 A.5.1, A.8.25-A.8.31
