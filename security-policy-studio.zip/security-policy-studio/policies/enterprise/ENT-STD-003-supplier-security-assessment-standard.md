# Supplier Security Assessment Standard

## 1. Purpose & Scope
To define tiered due-diligence requirements for assessing supplier security risk. Applies to all suppliers subject to security assessment under the Third-Party & Supplier Security Policy.

## 2. Normative Requirements
1. Suppliers **shall** be tiered (Critical / High / Moderate / Low) by data sensitivity, access and business criticality.
2. Critical and High suppliers **shall** provide independent assurance (ISO 27001 certificate or SOC 2 Type II) or complete a full security questionnaire.
3. Moderate suppliers **shall** complete a standard questionnaire; Low suppliers **shall** complete a lightweight attestation.
4. Findings **shall** be risk-rated and remediation or compensating controls agreed before onboarding for Critical/High tiers.
5. Reassessment cadence **shall** be: Critical annually, High annually, Moderate every two years, Low at renewal.
6. Right-to-audit and breach-notification clauses **shall** be required for Critical and High suppliers.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Tiering & due diligence | ISO/IEC 27001:2022 A.5.19-A.5.22 |
| Assurance evidence | SOC 2 (TSC); ISO/IEC 27001 certification |
| Supply-chain risk | NIST SP 800-161; NIST SP 800-53 SR family |

## 4. Metrics & Compliance
- Percentage of Critical/High suppliers assessed within cadence.
- Open supplier findings by age.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.5.19-A.5.23
- NIST SP 800-161
- SOC 2 (TSC)
