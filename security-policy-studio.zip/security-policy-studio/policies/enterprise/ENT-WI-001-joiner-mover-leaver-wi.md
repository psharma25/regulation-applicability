# Joiner / Mover / Leaver WI

## 1. Purpose
To provision, modify and de-provision access and assets for personnel joiner, mover and leaver events.

## 2. Prerequisites
- Approved HR trigger (offer, transfer or termination notice).
- Defined role-based access profiles.
- Access to the IAM/HR systems and asset register.

## 3. Step-by-Step Instructions
1. On a **joiner**, create the unique identity and assign the role-based access profile approved by the manager.
2. Issue and record assigned assets (laptop, tokens, phone).
3. Enforce MFA enrollment and deliver day-one security awareness.
4. On a **mover**, add new entitlements and **remove** those no longer needed for the new role.
5. On a **leaver**, disable accounts and revoke access on the effective date (same business day for involuntary departures).
6. Recover assets and securely wipe/reassign devices; forward or archive mailboxes per policy.
7. Record completion of each action with timestamps.

## 4. Verification
- Account status reflects the change in the IAM system.
- No residual access remains for leavers (checked against the directory).
- Asset register reconciled.

## 5. Escalation
If access cannot be revoked within SLA or assets are unrecovered, escalate to the manager and Security immediately and raise an incident if compromise is suspected.

## 6. Related Documents
- Identity & Access Management Policy (ITS-POL-001)
- Human Resources Security Policy (ENT-POL-009)
- Access Recertification WI (ENT-WI-002)
