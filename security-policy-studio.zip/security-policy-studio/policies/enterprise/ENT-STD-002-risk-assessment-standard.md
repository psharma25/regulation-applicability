# Risk Assessment Standard

## 1. Purpose & Scope
To define the normative method, scales and criteria for assessing information-security risk. Applies to all risk assessments performed within the ISMS.

## 2. Normative Requirements
1. Likelihood and impact **shall** each be rated on a defined 1-5 scale with documented descriptors.
2. Risk level **shall** be computed as likelihood × impact and mapped to a tolerance band (Low/Medium/High/Critical).
3. Assets, threats, vulnerabilities and existing controls **shall** be identified for each in-scope item.
4. Risk owners **shall** be assigned and residual risk recorded after treatment.
5. Risks rated High or Critical **shall** require a treatment plan; acceptance above appetite **shall** require executive sign-off.
6. Assessments **shall** be repeated at least annually and on significant change.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Defined scales & criteria | ISO/IEC 27001:2022 Cl. 6.1.2; ISO/IEC 27005 |
| Risk identification | ISO/IEC 27005; NIST SP 800-30 |
| Treatment & acceptance | ISO/IEC 27001:2022 Cl. 6.1.3, 8.3 |
| Residual-risk recording | ISO/IEC 27001:2022 Cl. 6.1.3 (SoA) |

## 4. Metrics & Compliance
- Number of risks by band over time.
- Percentage of High/Critical risks with current treatment plans.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 Cl. 6.1, 8.2-8.3
- ISO/IEC 27005
- NIST SP 800-30
- ISO 31000
