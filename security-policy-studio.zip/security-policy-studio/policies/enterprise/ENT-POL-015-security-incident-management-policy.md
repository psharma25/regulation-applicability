# Security Incident Management Policy

## 1. Purpose
To ensure information-security events and incidents are detected, reported, assessed and responded to consistently and effectively, per **ISO/IEC 27001:2022 A.5.24-A.5.28** and NIST SP 800-61.

## 2. Scope
Applies to all information-security events affecting the Organization's information, systems, personnel or third parties within the ISMS scope, including product/PSIRT incidents that intersect with enterprise response.

## 3. Policy Statements
1. A documented **incident response plan** and on-call structure **shall** be maintained and tested.
2. All personnel **shall** report suspected events promptly through the defined channel; failure to report is itself a violation.
3. Incidents **shall** be **classified by severity** using defined criteria, with timeframes for triage and escalation.
4. A designated **Incident Manager shall** coordinate response; the **CISO** holds authority to declare a major incident.
5. **Containment, eradication and recovery shall** be performed under documented procedures preserving forensic evidence.
6. **Legal and Privacy shall** assess regulatory and breach-notification obligations; notifications **shall** meet applicable deadlines (e.g., GDPR 72h where applicable).
7. External and customer communications **shall** be approved by the designated authority.
8. Every major incident **shall** undergo a **post-incident review** producing lessons learned and CAPA actions.
9. Incident records and evidence **shall** be retained per the retention schedule.

## 4. Roles & Responsibilities
- **Incident Manager** — coordinates the response lifecycle.
- **CISO** — declares major incidents, owns the program.
- **SecOps / Analysts** — detect, triage, contain and remediate.
- **Legal / Privacy** — assess reportability and obligations.
- **Communications / Executives** — approve external messaging.

## 5. Compliance & Enforcement
Verified through exercises, metrics and audit. Concealment or delayed reporting is subject to disciplinary action.

## 6. Exceptions
None to the duty to report. Procedural exceptions require CISO approval.

## 7. Review & Maintenance
Reviewed at least annually and after every major incident.

## 8. References
ISO/IEC 27001:2022 A.5.24-A.5.28; NIST SP 800-61; ISO/IEC 27035. For regulated devices, coordinate with FDA postmarket cybersecurity reporting and the PSIRT process.
