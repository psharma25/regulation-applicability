# Information Classification & Handling Standard

## 1. Purpose & Scope
To define the classification scheme, labelling and handling rules applied to Organization information. Applies to all information in all formats across its lifecycle.

## 2. Normative Requirements
1. Information **shall** be classified into exactly one of: Public, Internal, Confidential, Restricted.
2. Labels **shall** be applied in document properties, headers/footers and email subject tags where technically feasible.
3. Confidential and Restricted data **shall** be encrypted at rest (AES-256 or stronger) and in transit (TLS 1.2+).
4. Restricted data **shall** require MFA and access logging; sharing **shall** require named-individual authorization.
5. Default classification for unlabelled internal information **shall** be Internal.
6. Reclassification **shall** be performed only by the information owner and recorded.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Classification scheme & labelling | ISO/IEC 27001:2022 A.5.12, A.5.13 |
| Encryption of sensitive data | ISO/IEC 27001:2022 A.8.24; NIST SP 800-53 SC-13, SC-28 |
| Access & logging for Restricted | ISO/IEC 27001:2022 A.8.2, A.8.15; NIST 800-171 3.1/3.3 |
| Handling & transfer rules | ISO/IEC 27001:2022 A.5.14, A.8.10-A.8.12 |

## 4. Metrics & Compliance
- Percentage of repositories with enforced labelling.
- Sampled handling-rule conformance from audits.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.5.12-A.5.14, A.8.10-A.8.12, A.8.24
- NIST SP 800-60
