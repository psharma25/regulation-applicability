# Document Change Control WI

## 1. Purpose
To version, review, approve and issue a controlled document.

## 2. Prerequisites
- Draft in the controlled-document template.
- Identified owner and approver.
- Access to the document-management system.

## 3. Step-by-Step Instructions
1. Create or check out the document and record the proposed change.
2. Increment the version (minor for editorial, major for substantive change).
3. Route to reviewer(s) and the approver for sign-off.
4. On approval, publish the new version and set status to Effective.
5. Withdraw or mark the previous version Obsolete and remove from points of use.
6. Update the revision history and notify affected users.

## 4. Verification
- Only the current approved version is available at points of use.
- Revision history and approvals are complete.
- Obsolete versions are not in active circulation.

## 5. Escalation
If approval is not obtained, keep the document in Draft; do not issue. Escalate blocking reviews to the document owner.

## 6. Related Documents
- Document & Records Control Policy (ENT-POL-017)
- Records Management Standard (ENT-STD-007)
