# Remote Work & Teleworking Policy

## 1. Purpose
To define security expectations for working away from Organization premises, including home and hybrid working.

## 2. Scope
Applies to all personnel who access Organization information or systems from off-site locations.

## 3. Policy Statements
1. Remote access **shall** require strong, multi-factor authentication over encrypted channels.
2. Only managed or approved devices meeting the endpoint baseline **shall** access Organization data.
3. Sensitive information **shall** be protected from observation, theft and unauthorized household access.
4. Public or untrusted networks **shall** be used only via approved VPN or zero-trust access.
5. Physical security of devices and printed materials off-site **shall** be maintained.
6. Lost or stolen devices and suspected compromise **shall** be reported immediately.
7. Personal use of work devices **shall** comply with the Acceptable Use Policy.

## 4. Roles & Responsibilities
- **Remote Workers** — apply controls at their location.
- **Line Managers** — authorize remote-work arrangements.
- **IT / Security** — provide secure access and managed devices.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.6.7, A.8.1
- NIST SP 800-46
- NIST SP 800-53 AC-17
