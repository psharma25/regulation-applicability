# Risk Assessment & Treatment Procedure

## 1. Purpose
To operationalize the identification, analysis, evaluation and treatment of information-security risk.

## 2. Scope
Applies to all risk assessments within the ISMS, including new systems, projects and significant changes.

## 3. Roles (RACI)
| Activity | Risk Owner | Risk & Compliance | CISO | Asset Owner |
| --- | --- | --- | --- | --- |
| Define scope & context | A | R | C | C |
| Identify & analyze risk | R | A | C | C |
| Evaluate against criteria | A | R | C | I |
| Select & plan treatment | A | R | C | C |
| Accept residual risk | R | C | A | I |
| Track to closure | A | R | C | I |

## 4. Process Steps
1. **Scope & context** — define the assessment boundary, assets and stakeholders. Inputs: asset inventory, business context. Outputs: scope statement.
2. **Identify risks** — determine threats, vulnerabilities and existing controls per asset. Inputs: threat intel, prior assessments. Outputs: risk list.
3. **Analyze** — rate likelihood and impact using the Risk Assessment Standard. Inputs: rating scales. Outputs: scored risks.
4. **Evaluate** — compare to risk-acceptance criteria and prioritize. Outputs: prioritized register.
5. **Treat** — select modify/avoid/share/retain and document a treatment plan and SoA update. Outputs: treatment plan.
6. **Accept & record** — risk owner accepts residual risk; executive sign-off above appetite. Outputs: signed acceptance.
7. **Monitor** — track treatment actions to closure and report posture. Outputs: status reports.

## 5. Records & Evidence
- Risk register, treatment plans, Statement of Applicability, residual-risk acceptances.

## 6. Related Documents & References
- ISO/IEC 27001:2022 Cl. 6.1, 8.2-8.3
- Risk Assessment Standard (ENT-STD-002)
- Risk Management Policy (ENT-POL-002)
