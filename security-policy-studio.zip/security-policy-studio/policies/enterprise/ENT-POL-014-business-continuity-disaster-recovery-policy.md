# Business Continuity & Disaster Recovery Policy

## 1. Purpose
To ensure the Organization can continue critical operations and recover information systems during and after disruptive events.

## 2. Scope
Applies to critical business processes and the information systems and suppliers that support them.

## 3. Policy Statements
1. A **business impact analysis shall** identify critical processes and set recovery objectives (**RTO/RPO**).
2. Business continuity and disaster-recovery plans **shall** be documented, owned and maintained.
3. ICT readiness for continuity **shall** be implemented, including resilient architecture and tested backups.
4. Continuity and recovery plans **shall** be **tested** at least annually and after major change.
5. Roles, escalation and communication during disruption **shall** be defined in advance.
6. Dependencies on key suppliers **shall** be addressed in continuity arrangements.
7. Lessons from tests and incidents **shall** drive plan improvements.

## 4. Roles & Responsibilities
- **Business Continuity Lead** — owns the program and exercises.
- **Process Owners** — define impact and recovery requirements.
- **IT / DR Team** — implements and tests technical recovery.
- **Executive Management** — invokes plans and allocates resources.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.29, A.5.30, A.8.13, A.8.14
- ISO 22301
- NIST SP 800-34
