# Data Retention Schedule Standard

## 1. Purpose & Scope
To define record categories and their mandated minimum retention periods. Applies to records across the ISMS and QMS, including regulated device records.

## 2. Normative Requirements
1. Each record category **shall** be assigned a retention period and disposition action.
2. Retention **shall** meet the longest of legal, regulatory and contractual requirements.
3. Device-related quality records **shall** be retained per the table below or the regulatory minimum, whichever is longer.
4. Records under legal hold **shall** be exempt from scheduled disposal until released.
5. Disposal **shall** be evidenced for Confidential and Restricted records.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Information-security records | Per category below; ISO/IEC 27001:2022 A.5.33 |
| Device design & quality records | Device lifetime or regulatory minimum; ISO 13485 Cl. 4.2.5 |

## 4. Metrics & Compliance
- Percentage of categories with assigned retention.
- Disposal certificates on file for sensitive records.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.5.33
- ISO 13485:2016 Cl. 4.2.5
- 21 CFR 820 / FDA QMSR
- NIST SP 800-88
