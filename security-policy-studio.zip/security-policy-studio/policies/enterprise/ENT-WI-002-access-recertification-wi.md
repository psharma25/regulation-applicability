# Access Recertification WI

## 1. Purpose
To run a periodic access-review (recertification) campaign so entitlements remain least-privilege.

## 2. Prerequisites
- Current entitlement export per system/application.
- Defined reviewers (system/data owners).
- Access-review tooling or tracker.

## 3. Step-by-Step Instructions
1. Generate the entitlement report for the in-scope systems and the review period.
2. Distribute review tasks to the accountable owners with a due date.
3. Owners **certify** (keep), **modify** or **revoke** each entitlement, recording justification.
4. Process all revocations and modifications through the access-change workflow.
5. Follow up overdue reviews and escalate to management.
6. Record campaign completion and retain evidence.

## 4. Verification
- 100% of in-scope entitlements have a recorded decision.
- Revocations are confirmed in the target systems.
- Evidence retained for audit.

## 5. Escalation
Escalate non-responding reviewers to their management; treat unreviewed privileged access as a finding.

## 6. Related Documents
- Access Control Policy (ENT-POL-004)
- Identity & Access Management Policy (ITS-POL-001)
