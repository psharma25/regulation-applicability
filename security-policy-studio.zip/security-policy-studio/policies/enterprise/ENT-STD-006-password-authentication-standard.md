# Password & Authentication Standard

## 1. Purpose & Scope
To define minimum requirements for credentials, authentication and session management. Applies to all human and service authentication to Organization systems.

## 2. Normative Requirements
1. Passwords **shall** be at least 12 characters; passphrases are encouraged; complexity-only rules **shall not** replace length.
2. Credentials **shall** be checked against known-breached password lists and **shall not** be reused across systems.
3. **Multi-factor authentication shall** be enforced for remote, privileged and sensitive access, using phishing-resistant factors where feasible.
4. Accounts **shall** lock after a defined number of failed attempts; brute-force protection **shall** be in place.
5. Sessions **shall** time out after a defined idle period and require re-authentication for sensitive actions.
6. Default and vendor credentials **shall** be changed before production use; secrets **shall not** be hard-coded.
7. Service-account credentials **shall** be vaulted and rotated.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Credential strength | NIST SP 800-63B; ISO/IEC 27001:2022 A.5.17 |
| MFA | NIST SP 800-63B AAL2+; NIST 800-171 3.5.3 |
| Session management | NIST SP 800-53 AC-11, AC-12 |

## 4. Metrics & Compliance
- MFA coverage of privileged accounts.
- Number of accounts failing the credential standard.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- ISO/IEC 27001:2022 A.5.17, A.8.5
- NIST SP 800-63B
- NIST SP 800-171 3.5.x
