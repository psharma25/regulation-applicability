# Threat Modeling Procedure

## 1. Purpose
To produce and review a product threat model.

## 2. Scope
Applies to threat modeling for new products and major changes.

## 3. Roles (RACI)
| Activity | Architect/Dev | Product Security | Product Mgmt |
| --- | --- | --- | --- |
| Build DFD & boundaries | R | A | I |
| Enumerate threats (STRIDE) | R | A | C |
| Rate & define mitigations | R | A | C |
| Review & sign off | C | A | C |
| Feed requirements/tests | R | A | I |

## 4. Process Steps
1. **Model the system** — create a data-flow diagram with trust boundaries. Outputs: DFD.
2. **Enumerate threats** — apply STRIDE to each element and flow. Outputs: threat list.
3. **Rate & mitigate** — score threats and define mitigations or accept risk. Outputs: rated threats.
4. **Review** — product security reviews and signs off. Outputs: approved threat model.
5. **Trace** — generate security requirements and test cases. Outputs: requirements/tests.

## 5. Records & Evidence
- Threat models, review sign-offs, derived requirements.

## 6. Related Documents & References
- Threat Modeling Standard (PRD-STD-002)
- Threat Modeling Policy (PRD-POL-004)
