# Security Requirements Standard

## 1. Purpose & Scope
To define the baseline security requirements catalog for products. Applies to all products as a starting baseline, tailored by threat model.

## 2. Normative Requirements
1. Products **shall** authenticate and authorize access to security-relevant functions.
2. Sensitive data **shall** be protected in transit and at rest.
3. Products **shall** log security-relevant events for forensics.
4. Products **shall** validate inputs and fail securely.
5. Products **shall** support secure update with signature verification.
6. Products **shall** avoid default credentials and support credential change.
7. Requirements **shall** be tailored using the threat model and applicable regulation.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Baseline requirements | NIST SP 800-218 PW.1-PW.2; OWASP ASVS |
| Device expectations | IEC 81001-5-1; FDA premarket |

## 4. Metrics & Compliance
- Requirement coverage per product.
- Traceability completeness to verification.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- OWASP ASVS
- NIST SP 800-218 PW.1-PW.2
- IEC 81001-5-1
