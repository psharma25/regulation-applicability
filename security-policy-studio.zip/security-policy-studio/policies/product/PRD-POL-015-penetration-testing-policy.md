# Penetration Testing Policy

## 1. Purpose
To govern penetration testing of products to validate security before and after release.

## 2. Scope
Applies to penetration testing of Organization products and supporting services.

## 3. Policy Statements
1. Products **shall** undergo penetration testing at defined milestones (e.g., major release) and periodically thereafter.
2. Testing scope and rules of engagement **shall** be defined and authorized in advance.
3. Testers **shall** be competent and independent of the development team for assurance value.
4. Findings **shall** be risk-rated and remediated within defined timelines; critical findings may block release.
5. Retesting **shall** confirm remediation.
6. Test reports **shall** be retained for audit and, for devices, submission.
7. Testing **shall** avoid impact to production and patient safety.

## 4. Roles & Responsibilities
- **Product Security** — commissions and oversees testing.
- **Testers (internal/external)** — execute within scope.
- **Engineering** — remediate findings.
- **Regulatory** — use evidence for submissions.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- NIST SP 800-115 (testing)
- OWASP Testing Guide
- FDA premarket cybersecurity (security testing)
- ISO/IEC 27001:2022 A.8.29
