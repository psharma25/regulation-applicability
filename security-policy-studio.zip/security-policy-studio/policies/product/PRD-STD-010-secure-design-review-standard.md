# Secure Design Review Standard

## 1. Purpose & Scope
To define criteria and gates for security design review. Applies to security design reviews at defined milestones.

## 2. Normative Requirements
1. A security design review **shall** occur before significant implementation begins and before release.
2. Reviews **shall** assess the threat model, security requirements coverage and architecture.
3. Reviews **shall** produce documented findings with owners and due dates.
4. Critical design findings **shall** be resolved or risk-accepted before proceeding.
5. Reviewers **shall** include product security and senior engineering.
6. Review records **shall** be retained.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Design review gate | NIST SP 800-218 PW.2 |
| Architecture & requirements | ISO/IEC 27001:2022 A.8.27 |

## 4. Metrics & Compliance
- Reviews completed on schedule.
- Critical design findings reopened.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NIST SP 800-218 PW.2
- Microsoft SDL design review
- OWASP SAMM
