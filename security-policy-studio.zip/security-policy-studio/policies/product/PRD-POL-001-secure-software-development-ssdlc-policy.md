# Secure Software Development (SSDLC) Policy

## 1. Purpose
To embed security throughout the software development lifecycle so that products are designed, built, tested and maintained securely, aligned to **NIST SP 800-218 (SSDF)**, **ISO/IEC 27001:2022 A.8.25-A.8.31**, and for regulated devices **IEC 62304** and **FDA premarket cybersecurity** expectations.

## 2. Scope
Applies to all software developed, integrated or maintained by the Organization, including firmware, embedded, cloud and AI/ML components.

## 3. Policy Statements
1. Security requirements **shall** be defined and reviewed at the start of each initiative (SSDF PO/PW.1).
2. **Threat modeling shall** be performed for new products and significant changes, with findings tracked to closure (PW.1).
3. Developers **shall** follow the Secure Coding Standard; code **shall** undergo peer review (PW.7).
4. **SAST, SCA and DAST shall** be integrated into CI/CD with defined pass/fail gates (PW.7-PW.8).
5. A **Software Bill of Materials shall** be generated for every release (PS.3, FDA 524B).
6. Third-party and open-source components **shall** be approved, inventoried and monitored for vulnerabilities (PW.4).
7. Build and release pipelines **shall** be integrity-protected; artifacts **shall** be **code-signed** and provenance recorded (PS.1-PS.2).
8. No release **shall** ship without passing the **security release gate** (RV).
9. Discovered vulnerabilities **shall** be handled through the PSIRT process, including postmarket for regulated devices.
10. For medical devices, security activities **shall** be integrated with the design controls and risk management (IEC 62304, ISO 14971).

## 4. Roles & Responsibilities
- **Product Security** — owns the SSDLC program, gates and tooling.
- **Engineering / Dev Leads** — implement secure design, coding and testing.
- **Release Management** — enforces the release gate.
- **Regulatory / Quality** — integrates security into design controls (regulated products).

## 5. Compliance & Enforcement
Verified through pipeline evidence, gate records and audit. Releases bypassing gates are nonconformities requiring CAPA.

## 6. Exceptions
Documented, risk-assessed, time-bound and approved by Product Security leadership.

## 7. Review & Maintenance
Reviewed at least annually and on major toolchain or regulatory change.

## 8. References
NIST SP 800-218 (PO/PS/PW/RV); ISO/IEC 27001:2022 A.8.25-A.8.31; IEC 62304; ISO 14971; FDA 524B premarket cybersecurity; EU MDR Annex I; OWASP SAMM.
