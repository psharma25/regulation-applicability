# Open-Source & Third-Party Component Policy

## 1. Purpose
To govern selection, approval, tracking and monitoring of open-source and third-party components.

## 2. Scope
Applies to all third-party and open-source components incorporated into products.

## 3. Policy Statements
1. Components **shall** be approved before use, considering security, maintenance status and license.
2. An inventory of components **shall** be maintained and reflected in the SBOM.
3. Components **shall** be continuously monitored for new vulnerabilities (SCA).
4. Vulnerable components **shall** be remediated within the timelines of the Vulnerability Scoring & Triage Standard.
5. License obligations **shall** be reviewed and complied with.
6. Abandoned or unmaintained components **shall** be replaced or risk-accepted.
7. Component provenance and integrity **shall** be verified.

## 4. Roles & Responsibilities
- **Engineering** — selects and maintains components.
- **Product Security** — approves and monitors components.
- **Legal** — reviews license obligations.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- NIST SP 800-218 PW.4
- ISO/IEC 27001:2022 A.8.28, A.8.30
- OWASP Dependency management
