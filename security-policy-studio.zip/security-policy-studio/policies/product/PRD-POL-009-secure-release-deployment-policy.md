# Secure Release & Deployment Policy

## 1. Purpose
To define the security gates that must be satisfied before a release is deployed or shipped.

## 2. Scope
Applies to all product releases and deployments.

## 3. Policy Statements
1. A release **shall not** proceed without passing the **security release gate**.
2. Required evidence **shall** include passing SAST/DAST/SCA, a current threat model, an SBOM and resolution or approved waiver of open findings.
3. Security sign-off **shall** be recorded prior to release.
4. Emergency releases **shall** follow an expedited gate with retrospective review.
5. Releases **shall** be built from protected pipelines and signed.
6. Gate evidence **shall** be retained for audit and, for devices, regulatory submission.

## 4. Roles & Responsibilities
- **Release Management** — enforces the gate.
- **Product Security** — provides sign-off.
- **Engineering** — supplies evidence and remediations.
- **Product Owner** — authorizes release.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- NIST SP 800-218 RV, PW.8
- ISO/IEC 27001:2022 A.8.29, A.8.31
- FDA premarket cybersecurity
