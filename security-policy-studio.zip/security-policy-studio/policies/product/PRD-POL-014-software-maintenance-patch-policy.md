# Software Maintenance & Patch Policy

## 1. Purpose
To maintain and patch released software in a controlled, validated manner.

## 2. Scope
Applies to maintenance and patching of released/regulated products.

## 3. Policy Statements
1. Maintenance releases and patches **shall** follow the secure development lifecycle and release gate.
2. Changes **shall** be assessed for safety, security and regulatory impact (impact/change analysis).
3. Patches **shall** be verified and validated proportionate to risk before distribution.
4. Patch distribution **shall** use signed, integrity-protected mechanisms.
5. Patch records and validation evidence **shall** be retained in the QMS.
6. Customer communication **shall** accompany security-relevant patches.
7. Legacy/unsupported versions **shall** have a defined support and risk position.

## 4. Roles & Responsibilities
- **Engineering** — develops and validates patches.
- **Quality/Regulatory** — assess impact and reportability.
- **Product Security** — confirms security adequacy.
- **Support** — communicates to customers.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- IEC 62304 (maintenance process)
- FDA postmarket cybersecurity
- ISO 13485:2016 Cl. 7.3, 7.5
- NIST SP 800-218 RV
