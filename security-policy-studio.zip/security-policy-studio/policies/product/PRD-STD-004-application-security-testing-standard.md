# Application Security Testing Standard

## 1. Purpose & Scope
To define SAST/DAST/SCA coverage and pass criteria. Applies to security testing in the product CI/CD pipeline.

## 2. Normative Requirements
1. SAST **shall** run on every build of in-scope code; high/critical findings **shall** block merge unless waived.
2. SCA **shall** run on every build to detect vulnerable/over-permissive dependencies.
3. DAST **shall** run against running applications at defined milestones.
4. Pass criteria and waiver authority **shall** be defined; waivers **shall** be time-bound.
5. Findings **shall** flow to tracking and remediation per the Vulnerability Scoring & Triage Standard.
6. Tooling **shall** be kept current.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| SAST/DAST/SCA gates | NIST SP 800-218 PW.7-PW.8 |
| Dependency analysis | NIST SP 800-218 PW.4 |
| Pass/waiver governance | ISO/IEC 27001:2022 A.8.29 |

## 4. Metrics & Compliance
- Gate pass rate.
- Open high/critical findings by age.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NIST SP 800-218 PW.4-PW.8
- OWASP testing standards
