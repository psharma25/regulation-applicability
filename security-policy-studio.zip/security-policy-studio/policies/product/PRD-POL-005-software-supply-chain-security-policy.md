# Software Supply Chain Security Policy

## 1. Purpose
To protect the integrity of the software supply chain from source to deployment.

## 2. Scope
Applies to source control, build systems, dependencies, artifacts and release pipelines.

## 3. Policy Statements
1. Build pipelines **shall** be hardened, access-controlled and produce reproducible, attestable builds where feasible.
2. Dependencies **shall** be obtained from trusted sources and verified for integrity.
3. Build and release artifacts **shall** be **signed** and their provenance recorded (e.g., SLSA-aligned attestations).
4. Access to source and CI/CD **shall** follow least privilege with MFA.
5. Secrets **shall not** be stored in source; secret scanning **shall** be enforced.
6. An SBOM **shall** accompany each release per the SBOM Policy.
7. Tampering or compromise of the pipeline **shall** be treated as a security incident.

## 4. Roles & Responsibilities
- **DevOps/Platform** — secures pipelines and provenance.
- **Product Security** — defines supply-chain controls.
- **Engineering** — manages dependencies securely.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- NIST SP 800-218 PS.1-PS.3, PW.4
- NIST SP 800-161 (C-SCRM)
- SLSA framework
- ISO/IEC 27001:2022 A.8.30, A.8.31
