# SBOM & VEX Standard

## 1. Purpose & Scope
To define required SBOM/VEX formats, fields and exchange. Applies to all released software and firmware.

## 2. Normative Requirements
1. SBOMs **shall** be produced in SPDX or CycloneDX in machine-readable form.
2. SBOMs **shall** include the NTIA minimum elements and transitive dependencies.
3. SBOMs **shall** be generated automatically in CI/CD per release.
4. VEX statements **shall** communicate exploitability status of known vulnerabilities.
5. SBOM/VEX **shall** be retained and provided to customers and, for devices, to FDA.
6. SBOM accuracy **shall** be validated before release.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Format & minimum elements | NTIA minimum elements; SPDX (ISO/IEC 5962); CycloneDX |
| Generation & retention | NIST SP 800-218 PS.3 |
| Regulatory exchange | FDA 524B |

## 4. Metrics & Compliance
- Percentage of releases with valid SBOM.
- SBOM accuracy findings.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NTIA SBOM minimum elements
- SPDX / CycloneDX
- NIST SP 800-218 PS.3
- FDA 524B
