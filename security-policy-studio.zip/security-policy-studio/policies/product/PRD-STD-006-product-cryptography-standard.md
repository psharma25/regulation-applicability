# Product Cryptography Standard

## 1. Purpose & Scope
To define approved cryptography for shipped products. Applies to cryptography embedded in or used by products.

## 2. Normative Requirements
1. Products **shall** use TLS 1.2+ for network communications.
2. Symmetric/asymmetric algorithms and key sizes **shall** meet the enterprise Encryption Standard minimums.
3. Random number generation **shall** use cryptographically secure sources.
4. Custom or deprecated cryptography **shall not** be used.
5. Keys/secrets **shall not** be hard-coded; secure storage **shall** be used.
6. Where required, cryptographic modules **shall** be FIPS 140-3 validated.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Algorithms & protocols | NIST SP 800-57; SP 800-52 |
| Module validation | FIPS 140-3 |
| Key handling in products | NIST SP 800-218 PS.2 |

## 4. Metrics & Compliance
- Products using deprecated crypto (target zero).
- FIPS-validated coverage where required.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NIST SP 800-52, 800-57
- FIPS 140-3
- ISO/IEC 27001:2022 A.8.24
