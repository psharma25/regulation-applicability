# Threat Modeling Standard

## 1. Purpose & Scope
To define the method, depth and review criteria for threat modeling. Applies to threat modeling across products and major changes.

## 2. Normative Requirements
1. Threat models **shall** include a data-flow diagram with trust boundaries.
2. STRIDE (or an approved method) **shall** be applied to each element/flow.
3. Threats **shall** be rated and linked to mitigations or accepted risks.
4. Threat models **shall** be reviewed and signed off by product security.
5. Models **shall** be updated on significant design change.
6. Outputs **shall** generate security requirements and test cases.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| DFD & boundaries | NIST SP 800-218 PW.1 |
| STRIDE coverage | Microsoft SDL; OWASP Threat Modeling |
| Traceability to mitigations | ISO/IEC 27001:2022 A.8.27 |

## 4. Metrics & Compliance
- Percentage of releases with current threat models.
- Threat-to-mitigation closure rate.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NIST SP 800-218 PW.1
- Microsoft SDL Threat Modeling
- OWASP Threat Modeling
