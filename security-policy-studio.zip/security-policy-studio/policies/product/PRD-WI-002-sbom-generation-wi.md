# SBOM Generation WI

## 1. Purpose
To produce and attach an SBOM to a build.

## 2. Prerequisites
- SBOM generation tool integrated in CI/CD.
- Defined output format (SPDX or CycloneDX).

## 3. Step-by-Step Instructions
1. Run the SBOM generator against the build, including transitive dependencies.
2. Validate the SBOM contains the NTIA minimum elements.
3. Attach the SBOM to the release artifact and store it as a controlled record.
4. Run SCA against the SBOM to identify known vulnerabilities.
5. Record any deviations for VEX authoring.

## 4. Verification
- SBOM present in standard format with required fields.
- SBOM attached to the release and retained.
- SCA results captured.

## 5. Escalation
If an SBOM cannot be generated or is incomplete, block the release gate and notify product security.

## 6. Related Documents
- SBOM Policy (PRD-POL-003)
- SBOM & VEX Standard (PRD-STD-003)
