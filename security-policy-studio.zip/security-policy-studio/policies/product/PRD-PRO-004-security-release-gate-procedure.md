# Security Release Gate Procedure

## 1. Purpose
To collect evidence and obtain sign-off required to release.

## 2. Scope
Applies to all product releases passing the security gate.

## 3. Roles (RACI)
| Activity | Dev Lead | Product Security | Release Mgr | Product Owner |
| --- | --- | --- | --- | --- |
| Assemble evidence | R | A | C | I |
| Verify gate criteria | C | A | C | I |
| Security sign-off | I | A | C | C |
| Authorize release | I | C | R | A |

## 4. Process Steps
1. **Assemble** — collect SAST/DAST/SCA results, threat model, SBOM and finding status. Outputs: evidence pack.
2. **Verify** — confirm gate criteria met or waivers approved. Outputs: gate checklist.
3. **Sign off** — product security records security sign-off. Outputs: sign-off.
4. **Release** — release management/product owner authorize deployment. Outputs: release record.

## 5. Records & Evidence
- Gate evidence packs, sign-offs and release records.

## 6. Related Documents & References
- Secure Release & Deployment Policy (PRD-POL-009)
- NIST SP 800-218 RV
