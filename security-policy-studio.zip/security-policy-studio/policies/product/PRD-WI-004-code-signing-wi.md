# Code Signing WI

## 1. Purpose
To sign and verify a release artifact.

## 2. Prerequisites
- Access to signing service/HSM.
- Approved signing key.
- Release artifact ready and gated.

## 3. Step-by-Step Instructions
1. Confirm the artifact passed the security release gate.
2. Submit the artifact to the signing service using the protected key.
3. Generate and attach build provenance/attestation where applicable.
4. Verify the signature and provenance on a clean system.
5. Publish the signed artifact and record the signing event.

## 4. Verification
- Signature verifies with the correct key.
- Provenance/attestation present and valid.
- Signing event logged.

## 5. Escalation
If signature verification fails or key misuse is suspected, stop distribution, revoke as needed and raise an incident.

## 6. Related Documents
- Product Cryptography & Code Signing Policy (PRD-POL-010)
- Code Signing & Artifact Integrity Standard (PRD-STD-007)
