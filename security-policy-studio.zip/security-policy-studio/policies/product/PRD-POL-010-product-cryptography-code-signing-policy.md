# Product Cryptography & Code Signing Policy

## 1. Purpose
To define approved cryptography for products and to ensure release artifacts are signed and verifiable.

## 2. Scope
Applies to cryptography embedded in products and to signing of product artifacts and updates.

## 3. Policy Statements
1. Products **shall** use only approved, current cryptographic algorithms and protocols (see Product Cryptography Standard).
2. Secrets and keys **shall not** be hard-coded in products or source.
3. Release artifacts and firmware updates **shall** be **digitally signed**; devices **shall** verify signatures before installation.
4. Signing keys **shall** be protected in HSMs with strict access control.
5. Cryptographic implementations **shall** avoid custom/unvetted algorithms.
6. Products **shall** support secure key provisioning and rotation where applicable.
7. Post-quantum readiness **shall** be considered for long-lived products.

## 4. Roles & Responsibilities
- **Product Security/Engineering** — implement approved crypto and signing.
- **Key Custodians** — protect signing keys.
- **Release Management** — enforce signing.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- NIST SP 800-218 PS.2
- NIST SP 800-57; FIPS 140-3
- ISO/IEC 27001:2022 A.8.24
- FDA premarket (cryptographic protection)
