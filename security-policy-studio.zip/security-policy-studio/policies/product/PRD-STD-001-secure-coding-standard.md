# Secure Coding Standard

## 1. Purpose & Scope
To define language-level secure coding controls against common weaknesses. Applies to all code developed or maintained by the Organization.

## 2. Normative Requirements
1. Input **shall** be validated and output **shall** be encoded to prevent injection and XSS.
2. Parameterized queries **shall** be used; dynamic query concatenation is prohibited.
3. Authentication, authorization and session handling **shall** use vetted frameworks, not custom schemes.
4. Secrets **shall not** be hard-coded; sensitive data **shall** be handled per the cryptography standards.
5. Error handling **shall** avoid leaking sensitive information; fail securely.
6. Memory-unsafe operations **shall** be avoided or mitigated in applicable languages.
7. Code **shall** be peer-reviewed and pass SAST before merge.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Injection/XSS prevention | OWASP ASVS V5; CWE-79/89 |
| Auth & session | OWASP ASVS V2-V3; NIST SP 800-218 PW.5 |
| Secrets & crypto | ISO/IEC 27001:2022 A.8.24; CWE-798 |

## 4. Metrics & Compliance
- SAST findings per KLOC trend.
- Percentage of merges with required review.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- OWASP ASVS
- CWE Top 25
- NIST SP 800-218 PW.5-PW.7
