# Threat Modeling Policy

## 1. Purpose
To require threat modeling so product security risks are identified and mitigated by design.

## 2. Scope
Applies to new products, major features and significant architectural changes.

## 3. Policy Statements
1. Threat models **shall** be created for new products and significant changes before implementation completes.
2. Threat modeling **shall** use a defined method (e.g., STRIDE) and consider the product's data flows and trust boundaries.
3. Identified threats **shall** be rated and tracked to mitigation or accepted with justification.
4. Threat models **shall** be reviewed by product security and updated as the design evolves.
5. For regulated devices, threat modeling **shall** support the security risk assessment and premarket submission.
6. Threat-model outputs **shall** inform security requirements and test cases.

## 4. Roles & Responsibilities
- **Engineering/Architects** — produce threat models.
- **Product Security** — reviews and approves.
- **Product Management** — accepts residual risk.
- **Regulatory** — incorporates outputs for devices.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- NIST SP 800-218 PW.1
- ISO/IEC 27001:2022 A.8.27
- FDA premarket cybersecurity (threat modeling)
- STRIDE / PASTA
