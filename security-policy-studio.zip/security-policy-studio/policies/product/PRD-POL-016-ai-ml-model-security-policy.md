# AI/ML Model Security Policy

## 1. Purpose
To secure AI/ML components within products against model-specific and supply-chain threats.

## 2. Scope
Applies to products that incorporate AI/ML models, including third-party and open models.

## 3. Policy Statements
1. AI/ML components **shall** be inventoried, threat-modeled and risk-assessed (including data poisoning, evasion, model extraction and prompt injection).
2. Training and inference data **shall** be governed for integrity, provenance and privacy.
3. Model and dataset provenance **shall** be recorded; third-party models **shall** be vetted.
4. Models **shall** be evaluated for robustness, bias and safety prior to release proportionate to risk.
5. Inputs/outputs **shall** be validated and constrained to mitigate misuse and injection.
6. Model artifacts **shall** be integrity-protected and access-controlled.
7. Postmarket monitoring **shall** cover model drift and emerging AI vulnerabilities.

## 4. Roles & Responsibilities
- **Product Security/ML Engineering** — secure AI components.
- **Data Governance** — manage data integrity and provenance.
- **Product Security** — threat-model and monitor AI risk.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- NIST AI RMF 1.0
- ISO/IEC 42001
- OWASP Top 10 for LLM Applications
- MITRE ATLAS
