# Software Bill of Materials (SBOM) Policy

## 1. Purpose
To require the generation, maintenance and exchange of accurate Software Bills of Materials so component risk and supply-chain integrity are transparent, aligned to **FDA 524B**, **NTIA minimum elements**, and **NIST SP 800-218 (PS.3)**.

## 2. Scope
Applies to all software and firmware released, distributed or deployed by the Organization, including third-party and open-source components.

## 3. Policy Statements
1. An SBOM **shall** be generated for **every release** in a machine-readable standard format (**SPDX** or **CycloneDX**).
2. Each SBOM **shall** include the NTIA minimum elements: supplier, component name, version, unique identifiers, dependency relationships, author and timestamp.
3. SBOMs **shall** capture **transitive dependencies**, not only direct ones.
4. Components **shall** be continuously mapped to known vulnerabilities; exploitability **shall** be communicated via **VEX** statements.
5. SBOMs and VEX **shall** be **maintained per release** and updated when components change.
6. For regulated medical devices, SBOMs **shall** be provided to FDA in premarket submissions and to customers postmarket per 524B.
7. SBOM generation **shall** be automated within CI/CD and the artifacts integrity-protected.

## 4. Roles & Responsibilities
- **Build / DevOps** — generates SBOMs in the pipeline.
- **Product Security** — validates accuracy, maps CVEs, authors VEX.
- **Compliance / Regulatory** — distributes to FDA and customers.
- **Engineering** — maintains accurate dependency declarations.

## 5. Compliance & Enforcement
Verified through release evidence and audit. A release without a valid SBOM **shall not** pass the security release gate.

## 6. Exceptions
Approved by Product Security leadership with documented justification and remediation timeline.

## 7. Review & Maintenance
Reviewed at least annually and on regulatory change.

## 8. References
FDA 524B; NTIA "Minimum Elements for an SBOM"; NIST SP 800-218 PS.3; SPDX (ISO/IEC 5962); CycloneDX; CISA SBOM guidance; IEC 81001-5-1.
