# Software Composition Analysis Standard

## 1. Purpose & Scope
To define dependency scanning and license/vulnerability gates (SCA). Applies to all third-party and open-source dependencies.

## 2. Normative Requirements
1. Dependencies **shall** be scanned for known vulnerabilities on each build.
2. Direct and transitive dependencies **shall** be included.
3. Vulnerable dependencies **shall** be remediated within Vulnerability Scoring & Triage timelines.
4. License compliance **shall** be checked; prohibited licenses **shall** be blocked.
5. Dependency provenance/integrity **shall** be verified (e.g., checksums, signatures).
6. Results **shall** feed the SBOM and component inventory.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Dependency scanning | NIST SP 800-218 PW.4 |
| License governance | Open-source policy; legal review |
| Provenance | NIST SP 800-161; SLSA |

## 4. Metrics & Compliance
- Vulnerable dependencies by severity.
- Blocked-license incidents.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NIST SP 800-218 PW.4
- NIST SP 800-161
- SLSA
