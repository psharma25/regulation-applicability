# Premarket Cybersecurity Submission Policy

## 1. Purpose
To define the cybersecurity content required in premarket submissions for regulated devices.

## 2. Scope
Applies to premarket submissions for cyber devices subject to FDA Section 524B and equivalent obligations.

## 3. Policy Statements
1. Premarket submissions **shall** include a security risk assessment, threat model and architecture views.
2. A **Software Bill of Materials shall** be provided with the submission.
3. Plans for monitoring, identifying and addressing postmarket vulnerabilities **shall** be documented.
4. Security testing evidence (e.g., SAST/DAST/SCA, penetration testing) **shall** be included.
5. Labelling **shall** communicate security-relevant information to users.
6. Submissions **shall** demonstrate a secure development lifecycle consistent with recognized frameworks.
7. Security documentation **shall** be controlled within the QMS design file.

## 4. Roles & Responsibilities
- **Regulatory Affairs** — compiles and submits.
- **Product Security** — provides security evidence.
- **Engineering/Quality** — supply design and test artifacts.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- FDA FD&C Act Section 524B
- FDA premarket cybersecurity guidance
- IEC 81001-5-1; IEC 62304
- NIST SP 800-218
