# Penetration Testing Procedure

## 1. Purpose
To scope, execute and remediate product penetration tests.

## 2. Scope
Applies to penetration testing of products and supporting services.

## 3. Roles (RACI)
| Activity | Product Security | Testers | Engineering |
| --- | --- | --- | --- |
| Define scope & RoE | A | C | C |
| Execute test | C | A | I |
| Report findings | C | A | I |
| Remediate | A | I | R |
| Retest & close | A | R | C |

## 4. Process Steps
1. **Scope** — define targets, rules of engagement and safety constraints. Outputs: scope/RoE.
2. **Execute** — perform testing per scope. Outputs: raw findings.
3. **Report** — risk-rate findings with reproduction. Outputs: report.
4. **Remediate** — fix findings within timelines (criticals may block release). Outputs: fixes.
5. **Retest** — verify remediation and close. Outputs: closure evidence.

## 5. Records & Evidence
- Scope/RoE, test reports, remediation and retest evidence.

## 6. Related Documents & References
- Penetration Testing Policy (PRD-POL-015)
- NIST SP 800-115
- OWASP Testing Guide
