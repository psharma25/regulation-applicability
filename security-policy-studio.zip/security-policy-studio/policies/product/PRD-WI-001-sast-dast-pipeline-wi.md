# SAST/DAST Pipeline WI

## 1. Purpose
To wire SAST/DAST/SCA into CI/CD with enforced gates.

## 2. Prerequisites
- Access to the CI/CD pipeline.
- Approved security tools and pass criteria.
- Defined waiver authority.

## 3. Step-by-Step Instructions
1. Add SAST and SCA steps to run on every build/PR.
2. Configure DAST to run against deployed test environments at milestones.
3. Set pass/fail thresholds; configure high/critical findings to block merge/release.
4. Route findings to the tracking system.
5. Configure time-bound waiver handling with approver.
6. Validate the pipeline blocks a seeded test finding.

## 4. Verification
- Pipeline runs SAST/SCA on each build and DAST at milestones.
- Seeded high finding blocks the gate.
- Findings appear in tracking.

## 5. Escalation
If gates cannot be enforced or are bypassed, halt releases of affected components and notify product security.

## 6. Related Documents
- Application Security Testing Standard (PRD-STD-004)
- Secure Software Development (SSDLC) Policy (PRD-POL-001)
