# Coordinated Disclosure & PSIRT Policy

## 1. Purpose
To establish a Product Security Incident Response Team (PSIRT) and a coordinated process for receiving, handling and disclosing product vulnerabilities.

## 2. Scope
Applies to security vulnerabilities affecting Organization products, from intake through remediation and disclosure.

## 3. Policy Statements
1. A **PSIRT shall** be established with defined membership, authority and escalation paths.
2. Vulnerabilities **shall** be handled under a documented process aligned to ISO/IEC 30111, regardless of source (research, internal, customer, monitoring).
3. Vulnerabilities **shall** be validated, scored and assigned remediation timelines per the Vulnerability Scoring & Triage Standard.
4. Coordinated disclosure **shall** balance user protection with timely transparency; disclosure timelines **shall** be defined.
5. Security advisories and, where applicable, **VEX** statements **shall** be issued to affected customers.
6. Regulatory reporting obligations (e.g., for devices) **shall** be assessed and met within required timeframes.
7. PSIRT **shall** coordinate with enterprise incident response when an issue spans products and infrastructure.
8. PSIRT performance and cases **shall** be tracked and reviewed for improvement.

## 4. Roles & Responsibilities
- **PSIRT Lead** — owns and coordinates the PSIRT process.
- **Engineering** — validates and remediates vulnerabilities.
- **Regulatory** — assesses reportability for regulated products.
- **Communications/Legal** — manage disclosure and safe harbor.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 30111 (handling)
- ISO/IEC 29147 (disclosure)
- FIRST PSIRT Services Framework
- FDA postmarket cybersecurity
