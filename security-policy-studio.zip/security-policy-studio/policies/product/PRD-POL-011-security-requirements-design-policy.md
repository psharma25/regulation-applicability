# Security Requirements & Design Policy

## 1. Purpose
To ensure security requirements are derived, documented and reviewed as part of product design.

## 2. Scope
Applies to all product development and significant changes.

## 3. Policy Statements
1. Security requirements **shall** be derived from threat models, regulation, customer obligations and a baseline requirements catalog.
2. Requirements **shall** be documented, testable and traceable to design and verification.
3. A **secure design review shall** be conducted at defined milestones.
4. Security requirements **shall** be maintained as the product evolves.
5. For devices, security requirements **shall** integrate with design controls and risk management.
6. Requirement deviations **shall** be risk-assessed and approved.

## 4. Roles & Responsibilities
- **Product Security** — owns the requirements baseline and reviews.
- **Engineering** — implements and traces requirements.
- **Regulatory/Quality** — integrate with design controls.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- NIST SP 800-218 PW.1-PW.2
- ISO/IEC 27001:2022 A.8.27
- IEC 62304; ISO 14971 (devices)
- FDA premarket cybersecurity
