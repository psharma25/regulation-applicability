# Code Signing & Artifact Integrity Standard

## 1. Purpose & Scope
To define signing keys, provenance and verification for artifacts. Applies to all build/release artifacts and firmware updates.

## 2. Normative Requirements
1. All release artifacts and updates **shall** be digitally signed.
2. Signing keys **shall** be protected in HSMs with access control and audit.
3. Build provenance/attestations **shall** be generated and verifiable (SLSA-aligned where feasible).
4. Consumers/devices **shall** verify signatures before execution/installation.
5. Key compromise **shall** trigger revocation and re-signing under the incident process.
6. Signing **shall** be enforced by the release gate.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Artifact signing | NIST SP 800-218 PS.2 |
| Provenance/attestation | SLSA; NIST SP 800-161 |
| Key protection | FIPS 140-3; NIST SP 800-57 |

## 4. Metrics & Compliance
- Percentage of artifacts signed.
- Signature-verification failures investigated.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NIST SP 800-218 PS.2
- SLSA
- FIPS 140-3
