# SBOM Review & VEX Issuance Procedure

## 1. Purpose
To review SBOMs and publish VEX statements.

## 2. Scope
Applies to SBOM validation and VEX issuance per release.

## 3. Roles (RACI)
| Activity | Product Security | Build/DevOps | Compliance |
| --- | --- | --- | --- |
| Validate SBOM | A | R | I |
| Map components to CVEs | A | R | I |
| Author VEX | A | C | C |
| Publish/distribute | A | I | R |

## 4. Process Steps
1. **Validate** — confirm SBOM completeness/accuracy (incl. transitive deps). Outputs: validated SBOM.
2. **Analyze** — map components to known CVEs. Outputs: vulnerability mapping.
3. **VEX** — determine exploitability and author VEX statements. Outputs: VEX.
4. **Distribute** — publish to customers and, for devices, to FDA. Outputs: distribution record.

## 5. Records & Evidence
- SBOMs, vulnerability mappings, VEX statements, distribution records.

## 6. Related Documents & References
- SBOM Policy (PRD-POL-003)
- SBOM & VEX Standard (PRD-STD-003)
