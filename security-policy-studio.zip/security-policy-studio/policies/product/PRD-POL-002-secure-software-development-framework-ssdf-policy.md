# Secure Software Development Framework (SSDF) Policy

## 1. Purpose
To adopt the NIST Secure Software Development Framework (SSDF, SP 800-218) practices across the product lifecycle.

## 2. Scope
Applies to all software and firmware developed or maintained by the Organization.

## 3. Policy Statements
1. The Organization **shall** implement SSDF practice groups: Prepare the Organization (PO), Protect the Software (PS), Produce Well-Secured Software (PW) and Respond to Vulnerabilities (RV).
2. Security roles, toolchains and training **shall** be established (PO).
3. Source, build and release artifacts **shall** be protected from tampering and unauthorized access (PS).
4. Software **shall** be designed, reviewed, coded and tested to minimize vulnerabilities (PW).
5. Released software **shall** have a process to identify, assess and remediate vulnerabilities (RV).
6. SSDF implementation **shall** be evidenced for attestation purposes (e.g., secure-software development attestation).
7. SSDF practices **shall** integrate with design controls for regulated products.

## 4. Roles & Responsibilities
- **Product Security** — owns SSDF adoption and evidence.
- **Engineering** — implements PW/PS practices.
- **PSIRT** — operates RV practices.
- **Leadership** — resources PO practices.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- NIST SP 800-218 (SSDF)
- NIST SSDF attestation guidance
- ISO/IEC 27001:2022 A.8.25-A.8.31
- EO 14028 (software supply chain)
