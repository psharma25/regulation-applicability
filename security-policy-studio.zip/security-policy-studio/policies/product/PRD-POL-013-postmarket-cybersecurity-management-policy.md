# Postmarket Cybersecurity Management Policy

## 1. Purpose
To manage cybersecurity of marketed devices through surveillance, patching and reporting.

## 2. Scope
Applies to released/regulated products throughout their supported lifecycle.

## 3. Policy Statements
1. Postmarket vulnerability monitoring (including component/SBOM monitoring) **shall** be performed continuously.
2. Vulnerabilities **shall** be assessed for patient-safety and security impact and remediated within risk-based timelines.
3. Security updates **shall** be delivered through validated, signed mechanisms.
4. Reportable events **shall** be reported to regulators within required timeframes.
5. Customers/users **shall** receive timely security advisories and, where relevant, VEX.
6. End-of-support **shall** be communicated with security implications.
7. Postmarket activities **shall** be evidenced within the QMS.

## 4. Roles & Responsibilities
- **PSIRT** — coordinates postmarket vulnerability handling.
- **Regulatory** — assesses and files reports.
- **Engineering** — develops and delivers updates.
- **Quality** — maintains records.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- FDA postmarket management of cybersecurity in medical devices
- FD&C Act 524B
- ISO/IEC 30111
- IEC 81001-5-1
