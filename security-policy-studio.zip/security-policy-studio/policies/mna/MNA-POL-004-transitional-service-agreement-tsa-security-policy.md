# Transitional Service Agreement (TSA) Security Policy

## 1. Purpose
To manage the security risks of transitional services provided between buyer and seller after close, where shared systems and access persist temporarily.

## 2. Scope
Applies to all Transitional Service Agreements (TSAs) involving access to information, systems or facilities.

## 3. Policy Statements
1. Each TSA **shall** document the services, the data and access involved, the security controls and an exit date.
2. Access under a TSA **shall** be least-privilege, individually attributable, MFA-protected and logged.
3. Cross-party access **shall** terminate automatically at TSA exit; extensions **shall** require re-approval.
4. Security responsibilities and incident-notification obligations between parties **shall** be defined in the TSA.
5. Shared environments **shall** be segmented and monitored for the TSA duration.
6. TSA exit **shall** trigger removal of access, return or deletion of data and confirmation of separation.
7. TSA security status **shall** be reviewed periodically until all services are exited.

## 4. Roles & Responsibilities
- **TSA / Separation Manager** — owns TSA operation and exit.
- **Security** — defines and monitors TSA security controls.
- **Both Parties' IT** — operate within agreed controls.
- **Legal** — defines TSA security and liability terms.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.19-A.5.22, A.8.15-A.8.16
- NIST SP 800-161
- NIST CSF 2.0 (GOVERN, PROTECT)
