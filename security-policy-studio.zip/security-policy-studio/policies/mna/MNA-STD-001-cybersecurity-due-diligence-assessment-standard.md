# Cybersecurity Due Diligence Assessment Standard

## 1. Purpose & Scope
To define the scope, depth and evidence required for cybersecurity due diligence of a target. Applies to all cybersecurity due-diligence assessments of acquisition or investment targets.

## 2. Normative Requirements
1. Diligence **shall** assess governance, IAM, infrastructure/network, endpoint, cloud, application/product security, data protection, third-party/supply chain, prior incidents and regulatory posture.
2. Evidence **shall** be requested (policies, certifications, audit/pentest reports, breach history, SBOMs where relevant) and validated rather than accepted at face value.
3. External attack-surface and breach-exposure checks **shall** be performed where permitted.
4. Findings **shall** be risk-rated and red flags (active compromise, undisclosed breach, critical exposure) **shall** be flagged immediately.
5. Remediation effort and cost **shall** be estimated for material findings.
6. A diligence report **shall** be produced for the deal team with an executive summary and risk register.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Assessment domains | NIST CSF 2.0; ISO/IEC 27001:2022 Annex A |
| Supply-chain & third party | NIST SP 800-161; ISO/IEC 27001 A.5.19-A.5.23 |
| Evidence validation | SOC 2 / ISO 27001 certification review |

## 4. Metrics & Compliance
- Coverage of diligence domains.
- Material findings identified vs. discovered post-close.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NIST CSF 2.0
- ISO/IEC 27001:2022 Annex A
- NIST SP 800-161
