# Post-Merger Integration Security Policy

## 1. Purpose
To integrate an acquired entity into the enterprise securely, raising it to Organization control baselines without importing unacceptable risk.

## 2. Scope
Applies to all post-close integration of acquired environments, systems, identities and data.

## 3. Policy Statements
1. Acquired environments **shall not** be interconnected with Organization networks until a security baseline assessment is completed and critical gaps are addressed or compensated.
2. An integration security plan **shall** define sequencing, interim controls and target end-state.
3. Acquired identities and privileged access **shall** be inventoried, rationalized and brought under Organization IAM and MFA.
4. Acquired endpoints and servers **shall** be brought to the Organization hardening, logging and EDR baselines.
5. Acquired internet-facing assets **shall** be discovered, assessed and remediated on a priority basis.
6. Interim interconnection **shall** use least-connectivity, monitored segmentation until full integration.
7. Integration milestones **shall** require security sign-off; residual risk **shall** be tracked to closure.
8. Data inherited from the target **shall** be classified and protected per Organization policy.

## 4. Roles & Responsibilities
- **Integration Manager** — owns the integration program.
- **Security Integration Lead** — defines and verifies security baselines and interconnection.
- **Enterprise & Acquired IT** — execute remediation and consolidation.
- **CISO** — approves interconnection and accepts residual risk.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.9, A.8.9, A.8.20-A.8.22
- NIST CSF 2.0
- CIS Controls v8 1-4
- NIST SP 800-161
