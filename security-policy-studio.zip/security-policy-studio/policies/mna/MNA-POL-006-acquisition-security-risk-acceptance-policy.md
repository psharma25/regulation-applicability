# Acquisition Security Risk Acceptance Policy

## 1. Purpose
To govern how inherited and transaction-related security risks are formally accepted, conditioned or remediated, with appropriate authority.

## 2. Scope
Applies to security risks identified in diligence, integration and separation that are not fully remediated before a decision point.

## 3. Policy Statements
1. Material unremediated risks **shall** be documented with impact, likelihood and remediation cost/time.
2. Risk acceptance **shall** be made by an authority commensurate with the risk level, with the CISO consulted for security-significant risks.
3. Accepted risks **shall** carry a remediation plan, owner and deadline, and **shall** be tracked in the risk register.
4. Deal terms (price adjustment, escrow, warranties, conditions) **shall** be considered as risk-treatment options.
5. Critical risks (e.g., active compromise, regulatory non-compliance) **shall** be escalated to executive sponsors before close.
6. Post-close, accepted risks **shall** be reviewed until remediated or formally re-accepted.
7. Risk-acceptance decisions and rationale **shall** be retained as records.

## 4. Roles & Responsibilities
- **Executive Sponsor / Deal Lead** — accepts risk within authority.
- **CISO** — advises on and co-signs security-significant acceptances.
- **Security DD/Integration Lead** — quantifies and tracks risk.
- **Risk & Compliance** — maintains the register.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 Cl. 6.1.3, 8.3; A.5.4
- NIST CSF 2.0 (GOVERN)
- ISO 31000
- Enterprise Risk Management Policy (ENT-POL-002)
