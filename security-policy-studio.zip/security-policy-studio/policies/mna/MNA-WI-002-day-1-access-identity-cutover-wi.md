# Day-1 Access & Identity Cutover WI

## 1. Purpose
To provision and restrict access at deal close (Day-1 cutover).

## 2. Prerequisites
- Approved Day-1 access plan.
- Identity sources for both entities.
- Change approval for cutover.

## 3. Step-by-Step Instructions
1. Confirm which accounts are provisioned, retained or disabled at close.
2. Provision Day-1 access for required personnel using least privilege and MFA.
3. Disable or restrict access that must not persist past close (both directions).
4. Apply interim segmentation for any interconnection.
5. Verify privileged access is vaulted and logged.
6. Record all cutover actions with timestamps.

## 4. Verification
- Required Day-1 access works; disallowed access is removed.
- MFA enforced; privileged access vaulted.
- Cutover actions logged.

## 5. Escalation
If access cannot be cut over or restricted as planned, hold interconnection and escalate to the integration/separation manager and Security.

## 6. Related Documents
- Post-Merger Integration Procedure (MNA-PRO-002)
- Identity & Access Management Policy (ITS-POL-001)
