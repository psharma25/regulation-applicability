# Data Separation & Migration Standard

## 1. Purpose & Scope
To define requirements for splitting, migrating and deleting data during integration or separation. Applies to data migration and separation in integrations, carve-outs and divestitures, including regulated records.

## 2. Normative Requirements
1. Data **shall** be inventoried and mapped to entitlement (transfer / retain / delete) before migration.
2. Migration **shall** preserve integrity and confidentiality, using encrypted transfer and verified completeness.
3. Commingled data **shall** be resolved so each party retains only entitled data.
4. Regulated quality/design records **shall** be transferred or copied and retained per ISO 13485 / applicable regulation.
5. Secure deletion **shall** meet recognized sanitization methods and be evidenced by certificates.
6. Personal-data migration **shall** confirm lawful basis and transfer mechanism.
7. Migration and deletion **shall** be reconciled and signed off.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Data mapping & entitlement | ISO/IEC 27001:2022 A.5.12, A.8.11 |
| Secure deletion | NIST SP 800-88; ISO/IEC 27001:2022 A.8.10 |
| Regulated record transfer | ISO 13485:2016 Cl. 4.2.5 |

## 4. Metrics & Compliance
- Records migrated vs. inventory.
- Deletion certificates obtained for separated data.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NIST SP 800-88
- ISO/IEC 27001:2022 A.8.10-A.8.12
- ISO 13485:2016 Cl. 4.2.5
