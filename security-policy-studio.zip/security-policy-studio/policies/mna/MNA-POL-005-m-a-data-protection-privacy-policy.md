# M&A Data Protection & Privacy Policy

## 1. Purpose
To ensure personal and regulated data is handled lawfully and securely throughout diligence, integration and separation.

## 2. Scope
Applies to all processing of personal and regulated data in connection with transactions.

## 3. Policy Statements
1. Personal data exchanged during diligence **shall** be minimized, pseudonymized or aggregated where possible, and shared through secure data rooms.
2. A lawful basis and, where required, transfer mechanism **shall** be confirmed before personal data is disclosed or transferred.
3. Data subjects' rights and notification obligations **shall** be assessed for the transaction.
4. A data-protection impact assessment **shall** be performed where the transaction presents high privacy risk.
5. Access to diligence data rooms **shall** be controlled, logged and revoked on completion.
6. On close, records of processing and data inventories **shall** be reconciled and updated.
7. Retention and deletion of transaction data **shall** follow the retention schedule and legal holds.

## 4. Roles & Responsibilities
- **Privacy / DPO** — oversees lawful processing and transfers.
- **Security** — protects diligence data and data rooms.
- **Legal / Corporate Development** — confirm lawful basis and terms.
- **Data Owners** — maintain inventories and entitlements.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27701
- ISO/IEC 27001:2022 A.5.34, A.8.10-A.8.12
- GDPR Art. 6, 25, 28, 44-49 (where applicable)
- NIST Privacy Framework
