# Post-Merger Integration Procedure

## 1. Purpose
To plan and execute secure integration of an acquired entity after close.

## 2. Scope
Applies to post-merger integration of acquired environments.

## 3. Roles (RACI)
| Activity | Integration Mgr | Security Integration Lead | Acquired IT | CISO |
| --- | --- | --- | --- | --- |
| Build integration plan | A | R | C | C |
| Baseline environment | C | A | R | I |
| Approve interconnection | C | R | I | A |
| Remediate & consolidate | A | C | R | I |
| Sign off integration | C | R | I | A |

## 4. Process Steps
1. **Plan** — define sequencing, interim controls and end-state. Outputs: integration security plan.
2. **Baseline** — assess the acquired environment against the Integration Security Baseline Standard. Outputs: baseline report.
3. **Interconnect** — approve least-connectivity segmentation once critical gaps are addressed. Outputs: interconnection approval.
4. **Remediate & consolidate** — fix gaps and consolidate identity, endpoints, logging and tooling. Outputs: remediation evidence.
5. **Sign off** — confirm end-state and track residual risk. Outputs: integration sign-off.

## 5. Records & Evidence
- Integration plan, baseline report, interconnection approval, remediation and sign-off.

## 6. Related Documents & References
- Integration Security Baseline Standard (MNA-STD-002)
- Post-Merger Integration Security Policy (MNA-POL-002)
