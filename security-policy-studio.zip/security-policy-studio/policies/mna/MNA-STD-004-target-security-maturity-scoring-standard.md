# Target Security Maturity Scoring Standard

## 1. Purpose & Scope
To provide a consistent scoring model for a target's security maturity and deal red flags. Applies to scoring outputs of cybersecurity due diligence.

## 2. Normative Requirements
1. Target maturity **shall** be scored per domain on a defined scale (e.g., 1-5) with descriptors.
2. A weighted overall score **shall** be derived, weighting critical-operation and data-sensitivity domains higher.
3. Defined red flags (active compromise, undisclosed breach, no MFA, unsupported critical systems, regulatory non-compliance) **shall** be recorded regardless of score.
4. Scores **shall** be accompanied by remediation cost/effort estimates.
5. Scoring criteria **shall** be applied consistently across deals to enable comparison.
6. Scores and red flags **shall** be reported to the deal team and inform terms.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Maturity model | NIST CSF 2.0 tiers; ISO/IEC 27001 Annex A coverage |
| Red-flag criteria | CISA KEV; breach disclosure review |

## 4. Metrics & Compliance
- Score consistency across assessors.
- Red-flag detection rate.

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- NIST CSF 2.0
- ISO/IEC 27001:2022 Annex A
- CVSS / CISA KEV (for exposure)
