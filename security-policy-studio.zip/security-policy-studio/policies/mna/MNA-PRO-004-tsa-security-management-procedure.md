# TSA Security Management Procedure

## 1. Purpose
To operate and exit transitional services securely.

## 2. Scope
Applies to services provided under a TSA after close.

## 3. Roles (RACI)
| Activity | TSA Mgr | Security | Both Parties IT | Legal |
| --- | --- | --- | --- | --- |
| Document TSA security | A | R | C | C |
| Provision controlled access | C | A | R | I |
| Monitor during TSA | C | A | R | I |
| Exit & remove access | A | R | C | C |

## 4. Process Steps
1. **Document** — capture services, data, access, controls and exit date. Outputs: TSA security schedule.
2. **Provision** — grant least-privilege, MFA, logged access; segment shared environments. Outputs: access config.
3. **Monitor** — review access and activity for the TSA duration. Outputs: monitoring records.
4. **Exit** — terminate access, return/delete data and confirm separation at exit. Outputs: exit confirmation.

## 5. Records & Evidence
- TSA security schedule, access configuration, monitoring records, exit confirmation.

## 6. Related Documents & References
- Transitional Service Agreement (TSA) Security Policy (MNA-POL-004)
- Data Separation & Migration Standard (MNA-STD-003)
