# Target Security Questionnaire WI

## 1. Purpose
To issue and evaluate the target security questionnaire during diligence.

## 2. Prerequisites
- Approved DD scope and NDA in place.
- Secure data room or transfer channel.
- Standard questionnaire template.

## 3. Step-by-Step Instructions
1. Tailor the questionnaire to the target's profile and deal type.
2. Issue it to the target through the secure data room with a due date.
3. Track responses and request supporting evidence (certifications, reports, breach history).
4. Validate responses against evidence; note gaps and inconsistencies.
5. Map responses to the assessment domains and scoring model.
6. Record findings and flag any red flags immediately to the DD lead.

## 4. Verification
- All domains have a response and supporting evidence or a noted gap.
- Red flags escalated.
- Findings recorded for scoring.

## 5. Escalation
If the target discloses (or evidence reveals) an active compromise or undisclosed breach, escalate to the DD lead and executive sponsor before proceeding.

## 6. Related Documents
- Cybersecurity Due Diligence Assessment Standard (MNA-STD-001)
- Cybersecurity Due Diligence Procedure (MNA-PRO-001)
