# Integration Security Baseline Standard

## 1. Purpose & Scope
To define the minimum security controls an acquired environment must meet before interconnection with Organization networks. Applies to acquired environments pending integration.

## 2. Normative Requirements
1. MFA **shall** be enforced on privileged and remote access before interconnection.
2. EDR and centralized logging **shall** be deployed to acquired endpoints/servers in scope.
3. Internet-facing assets **shall** be inventoried and critical/high vulnerabilities remediated or mitigated.
4. Default and shared credentials **shall** be eliminated; privileged accounts **shall** be vaulted.
5. Interconnection **shall** be through monitored, least-connectivity segmentation, not flat trust.
6. Backups of critical acquired data **shall** be confirmed before changes.
7. A baseline assessment **shall** be signed off before any production interconnection.

## 3. Control Mapping
| Requirement | Mapped Controls / Clauses |
| --- | --- |
| Pre-connection baseline | CIS Controls v8 1-6; ISO/IEC 27001:2022 A.8.9 |
| Segmentation | ISO/IEC 27001:2022 A.8.20-A.8.22; NIST SP 800-53 SC-7 |
| MFA & privileged access | NIST SP 800-63B; ISO/IEC 27001 A.8.2, A.8.5 |

## 4. Metrics & Compliance
- Baseline pass rate before interconnection.
- Critical exposures open at interconnection (target zero).

## 5. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 6. References
- CIS Controls v8
- ISO/IEC 27001:2022 A.8.9, A.8.20-A.8.22
- NIST SP 800-63B
