# Data Egress & Separation Verification WI

## 1. Purpose
To verify that data has been migrated, separated and deleted as planned.

## 2. Prerequisites
- Data inventory and entitlement map.
- Migration and deletion completed.
- Access to source and target systems.

## 3. Step-by-Step Instructions
1. Reconcile migrated data against the entitlement map for completeness and accuracy.
2. Confirm no commingled or out-of-scope data was transferred.
3. Run secure deletion on residual/source data per the sanitization method.
4. Obtain or generate deletion certificates for separated data.
5. Spot-check retained systems for absence of buyer/divested data.
6. Record verification results and sign off.

## 4. Verification
- Migrated data matches entitlement; no out-of-scope data transferred.
- Deletion certified for separated data.
- Verification recorded and signed off.

## 5. Escalation
If data is found commingled, mis-migrated, or not deleted, halt sign-off and escalate to the separation manager, Security and Legal.

## 6. Related Documents
- Data Separation & Migration Standard (MNA-STD-003)
- Carve-Out Separation Procedure (MNA-PRO-003)
