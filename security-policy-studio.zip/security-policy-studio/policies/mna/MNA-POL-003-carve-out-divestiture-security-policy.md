# Carve-Out & Divestiture Security Policy

## 1. Purpose
To securely separate a divested or carved-out business so that confidentiality, integrity and availability are preserved and only authorized data and access transfer to the buyer.

## 2. Scope
Applies to divestitures, spin-offs and carve-outs of business units, including associated QMS records for regulated products.

## 3. Policy Statements
1. A separation security plan **shall** define which identities, data, systems and access transfer, remain or are deleted.
2. Access of divested-unit personnel to retained Organization systems **shall** be removed on the agreed date; retained-personnel access to divested systems **shall** likewise be removed.
3. Data **shall** be partitioned by entitlement; only data the buyer is contractually entitled to **shall** be migrated, and commingled data **shall** be resolved before transfer.
4. Personal data transfer **shall** rely on an approved lawful basis and transfer mechanism.
5. For regulated products, the **device master record, design history and quality records shall** be transferred or copied to the buyer and retained as required by regulation.
6. Residual Organization data on transferred assets **shall** be securely removed; buyer data on retained assets **shall** be removed.
7. Secure deletion of separated data **shall** be verified and certified.
8. Transitional services, if any, **shall** be governed by the TSA Security Policy and time-bound.

## 4. Roles & Responsibilities
- **Separation Manager** — owns the carve-out program.
- **Security Separation Lead** — designs and verifies separation of identity, data and infrastructure.
- **Divesting Business Unit** — supports inventory and execution.
- **Legal** — defines entitlement, lawful basis and TSA terms.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.10, A.8.10 (deletion), A.8.11
- ISO 13485:2016 Cl. 4.2.5 (record retention/transfer)
- NIST SP 800-88 (sanitization)
- Applicable privacy/transfer law
