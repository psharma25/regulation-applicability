# M&A Cybersecurity Due Diligence Policy

## 1. Purpose
To ensure cybersecurity, privacy and technology risks of acquisition or investment targets are identified, quantified and reflected in deal decisions and post-close planning.

## 2. Scope
Applies to all mergers, acquisitions, investments and joint ventures evaluated by the Organization.

## 3. Policy Statements
1. A cybersecurity due-diligence assessment **shall** be performed for every material transaction before signing or, where not feasible, before close.
2. Diligence depth **shall** scale with deal value, data sensitivity and the target's role in critical operations.
3. The assessment **shall** cover governance, identity, infrastructure, application/product security, data protection, third parties, prior incidents/breaches and regulatory exposure.
4. Known breaches, active compromises and undisclosed incidents **shall** be treated as material findings and escalated to the deal team.
5. Identified risks **shall** be quantified (remediation cost and risk exposure) and provided as an input to valuation and deal terms.
6. Security representations, warranties and remediation conditions **shall** be recommended to Legal for the agreement.
7. A prioritized post-close remediation and integration security plan **shall** be produced for material risks.
8. Diligence findings **shall** be handled as Restricted and access limited to the deal team under confidentiality obligations.

## 4. Roles & Responsibilities
- **Executive Sponsor / Deal Lead** — accountable for the transaction and risk acceptance.
- **Security Due Diligence Lead** — plans and executes the assessment and reports findings.
- **Legal / Corporate Development** — translate findings into terms and conditions.
- **CISO** — sets diligence requirements and reviews material risk.

## 5. Compliance & Enforcement
Compliance with this document is monitored through internal audit, management review and control metrics. Non-conformities are recorded and remediated through corrective action. Non-compliance may result in removal of access and disciplinary action up to and including termination; for third parties, contractual remedies apply.

## 6. Exceptions
Exceptions **shall** be documented, risk-assessed, time-bound and approved by the document owner (and the CISO for security-significant exceptions). A register of active exceptions with expiry dates and compensating controls **shall** be maintained and reviewed at least quarterly.

## 7. Review & Maintenance
This document **shall** be reviewed at least annually and upon significant change to the business, technology, threat landscape or applicable regulation, and re-approved by its owner.

## 8. References
- ISO/IEC 27001:2022 A.5.7, A.5.19-A.5.23
- NIST SP 800-161 (C-SCRM)
- NIST CSF 2.0 (GOVERN)
- Acquirer M&A due-diligence good practice
