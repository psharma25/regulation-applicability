# Cybersecurity Due Diligence Procedure

## 1. Purpose
To execute cybersecurity due diligence from initiation through findings and valuation input.

## 2. Scope
Applies to security due diligence on targets.

## 3. Roles (RACI)
| Activity | Deal Lead | Security DD Lead | Target | CISO |
| --- | --- | --- | --- | --- |
| Initiate & scope DD | A | R | I | C |
| Request & collect evidence | I | A | R | I |
| Assess & score | I | A | C | C |
| Quantify & report | C | A | I | C |
| Feed terms & planning | A | R | I | C |

## 4. Process Steps
1. **Initiate & scope** — confirm deal context, scope and data-room access. Outputs: DD scope.
2. **Collect evidence** — issue the target questionnaire and request artifacts; validate. Outputs: evidence set.
3. **Assess & score** — evaluate domains, run permitted external checks, score maturity and flag red flags. Outputs: scored findings.
4. **Quantify & report** — estimate remediation cost/effort and produce the DD report. Outputs: DD report.
5. **Feed deal** — provide inputs to valuation, terms and the post-close security plan. Outputs: recommendations.

## 5. Records & Evidence
- DD scope, questionnaire responses, evidence, scored findings, DD report.

## 6. Related Documents & References
- Cybersecurity Due Diligence Assessment Standard (MNA-STD-001)
- M&A Cybersecurity Due Diligence Policy (MNA-POL-001)
