# Carve-Out Separation Procedure

## 1. Purpose
To separate identities, data and infrastructure for a divestiture or carve-out.

## 2. Scope
Applies to carve-out and divestiture separation, including regulated records.

## 3. Roles (RACI)
| Activity | Separation Mgr | Security Separation Lead | Divesting BU | Legal |
| --- | --- | --- | --- | --- |
| Plan separation & TSA | A | C | C | R |
| Separate identity & access | C | A | R | I |
| Split & migrate data | A | R | C | C |
| Verify & certify deletion | C | A | R | C |
| Exit & sign off | A | R | C | C |

## 4. Process Steps
1. **Plan** — define what transfers/retains/deletes and any TSA. Outputs: separation plan.
2. **Separate identity** — remove cross-entity access on the agreed date. Outputs: access changes.
3. **Split & migrate data** — partition by entitlement and migrate entitled data securely. Outputs: migration record.
4. **Verify deletion** — securely delete residual/commingled data and certify. Outputs: deletion certificates.
5. **Exit & sign off** — close transitional services and confirm separation. Outputs: separation sign-off.

## 5. Records & Evidence
- Separation plan, access changes, migration records, deletion certificates, sign-off.

## 6. Related Documents & References
- Data Separation & Migration Standard (MNA-STD-003)
- Carve-Out & Divestiture Security Policy (MNA-POL-003)
